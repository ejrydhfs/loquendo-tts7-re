{
  "deliverables": {
    "spec": "specs/SDE.md (501 lines; §12 = legacy generation, §13 = tool + verified-count table)",
    "tool": "tools/sde_parse.py (auto-detects generation + bit-7 mask; handles U/L/R/S/P and legacy U/D; prints header, first-N atoms with decoded records, counts vs N=, U= field distribution, max end)",
    "extra_dumps": [
      "jorge_re/decomp_util_jorge.txt",
      "jorge_re/decomp_loqtts_jorge.txt"
    ]
  },
  "followup_legacy_variant": {
    "file": "payload/Ludoviko.sde13 (186 290 B, bit-7 masked, decoded copy engine_re/Ludoviko.sde.txt)",
    "verified_counts": {
      "U=": 3482,
      "D=": 6577,
      "L/R": 0,
      "S=": 0,
      "P=": 0,
      "N": [
        3482,
        6953,
        6578
      ],
      "max_end": 15829000
    },
    "N_anchors": {
      "N[0]=3482": "= exact U= count",
      "N[1]=6953": "raw grammatical token count is 6962 (3480 atoms x2 + 2 atoms x1); engine counts strlen(id-byte buffer) and FUN_100190c0 returns the phonetic-table index with index 0 written as a 0 byte, truncating the rest of the line. Brute force over all 71 tokens: exactly two tokens ('Oe' and '`Oe', which never co-occur and appear in identical 6-line position patterns) reproduce a loss of exactly 9 -> 6962-9=6953, so exactly one of them is table index 0",
      "N[2]=6578": "#D + 1 (6577 records present); engine parses only the first two numbers (FUN_100493b0/FUN_10028b80 = two _atol calls into state+0x10/+0x18), so N[2] is a generator-side note"
    },
    "D_record_grammar": "D=<order>,<S|D>,<start>,<end>,<pitch>, PLAIN _atol decimal, comma separated. Parser: FUN_10028700 @0x10028700 (jorge FUN_10048f90 @0x10048f90). Enforced: order>=0 ('Error in phoneme order'), part in {S,D} ('Unknown phoneme part'), end>=start ('Negative duration'), pitch>=0 ('Pitch negative'). Engine stores pair(start, (end-start)<<10 | pitch&0xffff) = the SAME 8-byte half-slot pair as a Jorge L<n>/R<n> record, dur=end-start. order is a 0-based token index (slot = (atomStart+order)*2, +1 when part=='D'), because the legacy U= line has no context tokens; part S = L (left/Sinistra), D = R (right/Destra).",
    "observed_field_stats": {
      "orders": {
        "0": 3302,
        "1": 3275
      },
      "parts": {
        "D": 3300,
        "S": 3277
      },
      "pitch": "0 in all 6577 records",
      "D_per_atom": {
        "1": 3095,
        "2": 387
      },
      "violations_of_engine_invariants": 0
    },
    "stateful_generation_policy": "NOT derivable from the reader (as the parent said): the reader fixes the field semantics and the slot formula, but which (order,part) pairs the generator emits (1 or 2 per atom, sparse coverage of the 2*#tokens possible half-slots) is writer-side only. Documented as such in the spec.",
    "time_base": "Shared 10 us unit. Legacy max end 15 829 000 = 158.29 s; companion payload/Ludoviko.16000.linear.256000.10.bin12 (5 069 459 B, header 125+28=153 B, 16-bit mono) = (5069459-153)/2 = 2 534 653 samples @16 kHz = 158.42 s = 15 841 581 x 10us (parent-reported 2 534 667 samples = 158.417 s). Agreement 0.08 % -> same unit as the Jorge files.",
    "routing": {
      "markers": "VERSION=<n> (legacy, e.g. 7) vs LTTSComponentVersion=<ver> (Jorge, 7.0.0); both generations carry the same opaque <int>,<int> line 0 (14,1 vs 10,4)",
      "does_jorge_reader_handle_both": "YES, and there is NO version branch: the literal 'VERSION=' occurs 0 times in jorge and old LoqTTS7.dll, LTTS7Util.dll and LTTS7DB.dll (byte search). The reader (FUN_10049f10 jorge / FUN_1002a890 old) reacts in pass 1 only to 'N'/'U'/'P' and in pass 2 dispatches on tag chars {'A','D','L','R','F','S','U','P'} — 'D' is the case that parses the legacy part records and 'V' has no case (dropped). The only tag with explicit special handling is LTTSComponentVersion=, and that is merely 'skip one extra header line'. So route by header for OUR parsing only."
    }
  },
  "acceptance_rerun": {
    "Jorge.sde": "3647 U=, 82007 tokens, 149426 L/R, 146 S=, max end 529894060 (N=3647,82007)",
    "JorgeGildedPhrases.sde": "261 U=, 2960 tokens, 4876 L/R, 260 S=, max end 17776419 (N=261,2960)",
    "JorgeGildedParalinguistics.sde": "147 P=, no header, stored plain, max end 19915859",
    "Ludoviko.sde13": "3482 U=, 6577 D=, N[0]=3482, max end 15829000 (N=3482,6953,6578)"
  },
  "caveats": [
    "N[1] for the legacy file (6953) is 9 below the raw token count (6962); explained by the id-0 strlen truncation with the Oe/`Oe ambiguity left as stated (both candidates fit)",
    "the legacy generator's choice of which (order,part) records exist is not derivable from the reader and is documented as such"
  ]
}