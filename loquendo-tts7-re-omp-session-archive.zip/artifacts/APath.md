{
  "deliverable": "specs/APath.md (written, 232 lines)",
  "verdict": "The port's A path is exactly 2x too small because one of the two QMF level combines is missing; band_filter itself is amplitude-exact (factor 1/2 per call, corr 1.000000 on all 4 real calls).",
  "root_cause": "The 32 kHz A-filter input is NOT A16: it is out16 = 2*(A16 - B16), the 16 kHz level's reconstruction (the 16 kHz object's combine writes it straight into the 32 kHz object's ring 0x30002220, which is copied to +0x2c = 0x30014380). The port feeds A16 into the second band_filter, dropping the x2.",
  "measurements": {
    "chain": "two-level QMF tree, each level out = clamp(round(2*(A-B))): A16=bf(sig8,cf@0x100240a8,320), B16=bf(synth16,cf@0x100241a8,320), out16=2*(A16-B16)=320, A32=bf(out16,cfA,640), B32=bf(synth32,cfB,640), pcm=2*(A32-B32). Verified: 2*(A32-B32) vs oracle PCM max abs diff 0.",
    "filter_gain": "intrinsic amplitude response is FLAT at 1/2 (0.4979-0.5015 for f/fs=0.0005..0.4995; DC gain A=0.49998, B=0.00000; sum h_A=0.999967, sum|h_A|=1.982200). Real per-call rms(dst)/rms(src): A16 0.218/0.583/0.499, B16 0.404/0.865/0.500, A32 0.489/0.498/0.498, B32 0.458/0.647/0.558 (f37/38/39); frame-local ratios deviate only because the filter spreads in-frame transients across the frame boundary.",
    "a16_input": "A16's input (16k obj +0x2c) is bit-for-bit the 8 kHz core LPC-synthesis output (o8+0x30): corr +1.000000, equal rms on f37/38/39. The 16 kHz coded branch does NOT feed A16; it feeds B16 (its own synth buffer 0x30012f30, uncorrelated with A16's input).",
    "wiring_checks": [
      "corr(32k ring head, 2*(A16-B16)) = +1.00000000, rms ratio 1.000000 (all 3 frames)",
      "port bf replay of each real call (src+real tail): corr 1.000000, max abs diff 8e-5..3e-3",
      "combine out=2*(A-B) verified vs oracle PCM, maxdiff 0"
    ],
    "stage_rms_f37_38_39": {
      "sig8": [
        2775.82,
        4088,
        5111.09
      ],
      "A16": [
        605.85,
        2384.16,
        2549.55
      ],
      "B16": [
        178.79,
        159.41,
        92.3
      ],
      "out16": [
        1262.11,
        4779.32,
        5102.34
      ],
      "A32": [
        617.5,
        2381.98,
        2539.1
      ],
      "B32": [
        83.24,
        53.31,
        30.64
      ],
      "pcm": [
        1246.6,
        4765.15,
        5078.49
      ]
    }
  },
  "patch": {
    "file": "tools/codec210.py",
    "function": "Codec210.decode_frame",
    "change": "insert ONE line before the second band_filter: out16 = [2.0 * v for v in a16]; then a32 = band_filter(out16, self.cf_a, 640, 64, self.tail_a32, [0.0]*2048). Nothing else changes (final pcm = 2.0*a32 already supplies the second x2). Equivalent: a32 = band_filter([2.0*v for v in a16], ...).",
    "do_not": "do NOT fix this via exc_scale: the x2 is not in the excitation and scaling exc_scale corrupts the adaptive-codebook history. Keep exc_scale = 1.0.",
    "future": "when B16/B32 are ported: add cf_b = band_filters_qmf.bandB_64tap.f32 + tail_b16/tail_b32, then out16 = 2*(a16-b16) and pcm = clamp(round(2*(a32-b32)))."
  },
  "acceptance": {
    "stage_local_fed_real_8k_synth": {
      "a16 vs real A16": "corr +1.000000, rms ratio 1.000000 (f37/38/39)",
      "a32 patched (B16=0) vs real A32": "corr 0.9578/0.9963/0.9952, rms ratio 0.958/0.996/0.995",
      "a32 fed the real out16 vs real A32": "corr +1.00000000, rms ratio 1.000000 (so the residual is exactly the unported B16)",
      "rms(2*A32) patched": [
        1183.02,
        4745.85,
        5053.62
      ],
      "rms real pcm": [
        1246.6,
        4765.15,
        5078.49
      ],
      "rms ratio": [
        0.949,
        0.996,
        0.995
      ],
      "corr vs real pcm": [
        0.9493,
        0.9961,
        0.9951
      ]
    },
    "end_to_end_port_own_8k_synth_frames_0_39": {
      "old_pcm_rms": [
        675.92,
        1954.43,
        890.91
      ],
      "patched_pcm_rms": [
        1352.27,
        3909.15,
        1782.16
      ],
      "real_pcm_rms": [
        1246.6,
        4765.15,
        5078.49
      ],
      "real_over_old": [
        1.844,
        2.438,
        5.7
      ],
      "note": "real/old reproduces the ticket's 1.8/2.4/5.7 exactly; the remaining non-constant error is the port's own 8 kHz synthesis (corr(a16_port, A16_real)=0.746/0.709/0.330, rms(sig8_port)/rms(sig8_real)=0.922/0.808/0.338), not the A path."
    }
  },
  "repro_scripts": [
    "/tmp/measure3.py (8k-synth snapshot -> /tmp/snaps_apath.json)",
    "/tmp/measure4.py (heap snapshots + tail capture -> /tmp/snaps2.json)",
    "/tmp/analyze2.py, /tmp/analyze4.py (per-call replay, wiring, stage tables)",
    "/tmp/run_port.py (old vs patched port intermediates)",
    "/tmp/verify_combine.py (combine vs PCM)",
    "/tmp/probe1.py, /tmp/codec210_patched.py"
  ],
  "notes": [
    "FUN_10003960 is __cdecl (ESP at the call points at arg1: src,coef,dst,outcount,64,tail,work); FUN_1000c290 is __fastcall (ECX=out, EDX=A, [ESP]=B).",
    "FUN_1000e170 is invoked twice/frame (16 kHz object esi=0x30007fe0, then 32 kHz esi=0x300021a0) => 4 band-filter calls + 2 combines/frame. Call sites 0x1000e118/0x1000e300 groups never fire on frames 0-39.",
    "The ticket's framing 'A16 = the input to the 32k filter' is corrected: A16 = the 16k object's +0x38 = the low-band filter output; the 32k filter input is out16 = 2*(A16-B16)."
  ]
}