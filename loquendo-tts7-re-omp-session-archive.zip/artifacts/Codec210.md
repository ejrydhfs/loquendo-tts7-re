{
  "status": "partial; exc_scale removed, correlation 0.510, output factor localised to the A-path",
  "actions_taken": {
    "exc_scale": "set to 1.0 (fitted 3.5 removed) - the excitation now contains no fitted scale; the measured CB1/CB2 increments equal gain*codebook with gain = C(g8)*q[b3] = 1245.3 exactly at scale 1.0, confirming your measurement",
    "correlation_unchanged": "0.5102 over frames 0..119 (scale-invariant, as expected); per-20 0.39 / 0.55 / 0.47 / 0.59 / 0.48 / 0.47",
    "output_path_factor": "measured the real A32/B32 and the port: frame 37 rms(A32)=617.5, rms(B32)=83.2, rms(2*(A-B))=1246.6 (matches the reference 1259.7 => combine exact) vs port pcm 675.9; frame 38 2382.0/53.3/4765.1 vs 1954.4; frame 39 2539.1/30.6/5078.5 vs 890.9. The port is 1.8x / 2.4x / 5.7x too small and the ratio is NOT constant, so the A-path differs in content, not merely by a gain. Candidates: the 8k LPC synthesis absolute gain, a per-stage 1/2 polyphase gain in the two band_filter stages, or the 16k branch feeding A16 (the port currently feeds the 8k synthesis straight into the A16 filter)."
  },
  "excitation_validation": "port excitation vs golden vectors (jorge_re/exc_stages_frame38.json): corr 0.659/0.689/0.701/0.025, rms 1293 vs 1273, 524 vs 431, 3223 vs 3430. Codebook mapping and gain law are EXACT; the residual is LTP history propagation (my per-subframe state differs from the real one).",
  "state": "tools/codec210.py: full chain with zero fitted constants in the excitation; API unchanged (Codec210().decode_frame(raw_block,key=K) -> 640 int16); render_unit.py renders; CLI prints RMS per 10 frames. Output is ~4x quiet because the A-path factor is still open.",
  "remaining_in_order": [
    "A-path amplitude/content: dump the real A16 (16k obj+0x38) and the real 8k synthesis, compare with the port's, and check whether each band_filter stage carries a 1/2 gain",
    "LTP history propagation (per-subframe state) - isolate by seeding the port's buffer with the emulator's history at frame 38 and re-running the golden comparison",
    "B32 (32k noise branch) and the 16k coded branch, each stage-locally validated"
  ],
  "artifacts": {
    "specs/Codec210.md": "1085 lines; 10.6 now carries the golden-dataset codebook validation and the A32/B32 amplitude table",
    "tools/codec210.py": "511 lines",
    "tools/codec210_tables.json": "208 KB",
    "tools/codec210_extract.py / codec210_oracle.py": "table generator + reference PCM oracle"
  },
  "verdict": "Not >= 0.9 and not claimed. Both of your measurements were applied: the excitation carries no fitted scale, the codebook/gain are proven exact against the golden dataset, and the remaining amplitude factor is localised to the A-path (with numbers showing it is content, not a constant gain)."
}