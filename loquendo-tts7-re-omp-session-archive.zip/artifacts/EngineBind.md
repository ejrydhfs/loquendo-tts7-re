{
  "deliverable": "specs/EngineBinding.md (1314 lines) — engine↔voice binding for Loquendo TTS 7 / voice \"Jorge\", items 1-4 of the ticket, every claim tied to a VA + verbatim decompiled snippet.",
  "artifacts": {
    "spec": "specs/EngineBinding.md",
    "tools": [
      "tools/enginebind_symtab.txt (recovered LTTS7Util name->slot table used by the jorge engine: DAT_100b7058=ELQBinGetBuffer etc., 441 entries)",
      "tools/EngineBindDumpFuncs.java (creates + decompiles the 8 dispatch targets Ghidra had missed)"
    ],
    "new_dumps": [
      "jorge_re/decomp_loqtts_jorge.txt (engine LoqTTS7.dll)",
      "jorge_re/decomp_jorge_voice.txt (LTTS7Jorge.dll)",
      "jorge_re/decomp_jorge_funcs.txt (the 8 voice-module procedures)"
    ]
  },
  "key_findings": [
    "Registration: FUN_100444d0 (old FUN_10024ff0) loops i=0..15 over LinkedSde[ALL]/LinkedSde[i], VocalDBName[i], VocalDBPath[i], VoicePath, DataPath; fallback path appends DAT_1009f3c4=\".sde\" and registers the file via FUN_10043f50 (old FUN_10024ad0) using the descriptor attribute \"Id\" (VA 0x10097388) -> ELQSharedResourceAdd at session+0x18+i*4 with flag session[0x98+i]=1; LinkedSde path = FUN_10044040 (old FUN_10024ba0) loads plugin \"<name>Sde\"/SdeDllMain with version \"7.0.1\". FUN_10044450 (old FUN_10024f70) is the VocalDBName[0] predicate. Release path FUN_10043cb0.",
    "CORRECTION to CONTEXT: the suffix constant is \".sde\", not \".bin\", and the attribute name is \"Id\" (old build bytes at RVA 0x8eec0 = \".sde\\0/\", 0x88a0c = \"Id\"); jorge equivalents verified by mapping VA->file offset and reading bytes.",
    "The .bin is NOT selected by file name: FUN_10052380 stores per-VocalDBName[i] a ELQBinaryHeaderLoadInfo(name,dir,log) object as \"__BinInfo__[i]\"; ELQBinaryHeaderLoadInfo globs \"*.bin\" (literal in old Util) and matches case-insensitively against the .bin TLV tag Label; the variant is then chosen in FUN_10022a50 from header tags Freq/Coding/BitRate/Rank vs the .vcf SetSampleRate/SetCoding/SetBitRate(Forced*) keys.",
    "Descriptor family resolved: FUN_10052340 maps type 0/1/2/3 -> .rcf/.vcf/.lcf/.ycf; type 1 (voice) loads .vde + gdeInclude + registers VDBs, type 2 (language) loads .lde, type 3 only the configurator; keys BaseVoice (0x100a1f18)/BaseLanguage, Library -> FullLibraryName/.dll + LibraryVersion, gdeInclude -> .gde (Gilded speech-act/paralinguistic inventories).",
    "Voice module: single export \"Jorge\" @ RVA 0x1170 dispatches an 8-entry {name;proc} table at VA 0x10008878 (names + target VAs + bodies all recovered and quoted: GetVersion, ELQGetPhonemes, ELQVoiceChannelOpen/Close, FonVidAllofonoAnalisi/Voce, FonVidMetaFonema, FonVidAnalisi2Sintesi); engine stores them at voice-object +0x18/+0x1c/+0x20/+0x24/+0x28, channel procs at +0x24c/+0x250; FonVidAllofonoVoce is a no-op stub (33 C0 C3); 24-byte pitch/unit entries (stride 0x18) and 16-byte input records.",
    "Unit->decoder: engine passes (decoderHandle, startSAMPLE, countSAMPLES, int16* out, ELQBin handle) — no frames/bytes cross the boundary; SDE positions are 10 us units converted in FUN_1001e3a0 as sample = pos*Fs/100000; pitch/duration stretching (TD-PSOLA mark placement, period Fs/(unit+0x140) or Fs/125) is in FUN_1001e3a0; margins Fs/500.",
    "Codec side verified: LTTS7Codec210 export @ RVA 0x4760, 8-name table, ELQDecode asks ELQBinGetBuffer(bin, 110*frameIndex+28+payloadOffset, 110, 1, 0, &eof) with frameIndex=samplePos/640, then un-XORs each frame with the key at sub-header byte 27. EMPIRICAL PROOF (all 3 Jorge DBs) that the payload IS obfuscated: keys 0x6d/0x15/0x91 normalise the raw frame byte-0 sets {0x50..57}/{0x28..2F}/{0xA8..AF} to the same {0x38..3F}. ELQGetDecodedFileSize always returns -1; ELQBinGetSize(bin,which) is a divisor; ELQBinGetBuffer always copies into a heap buffer; the \"smart buffer\" is a plain {data,capacity} pair, not offset-keyed.",
    "Worked example (acceptance): unit Aa of JorgeGildedParalinguistics.sde = P=Aa|0|61846 -> start sample 0, length 19790 samples (pos*32000/100000), decoder called with (handle,0,19854,out,bin) [19854 = 19790+0 preroll+64 postroll]; frame 0 at file offset 164 and 31.02->32 frames of 110 B."
  ],
  "uncertainties_flagged_in_spec": [
    "DataPath's use in FUN_100444d0 is not visible after the register construction (section 1.6).",
    "The .sde record parser itself is not identifiable by name in the engine dump; identification of the P-record name|start|end fields with the +0x155c/+0x1564 slots is marked [INFERENCE] (supported by the range check and the 100000 conversion).",
    "Who sets the codec's payload offset field (*(decoder+0x4c)=122) is unproven; the resulting reads match 150+110*i exactly.",
    "GildedTTS is not a literal in the engine (only gdeInclude is); the flag's consumer is the .gde loading path."
  ]
}