# Loquendo TTS 7 (LTTS7) + Loquendo TTS Director 7 - reverse-engineering bundle

Top-level report: REPORT.md. Per-layer deep dives: specs/*.md. Tools: tools/*.py. Data: jorge/ (voice package), engine_re/, payload/.

---

# Loquendo TTS 7 "TTS Director" — reverse-engineering package

Target: `/home/user/Downloads/LTTSDirector7.rar`
(md5 `9c551a2da0a71189d7168948c9d339d3`, 52,178,626 bytes)

**Verdict (final pass) — can another agent replicate the app and the synthesis engine?**

* **Application and installer: YES** — the archive ships the *complete, decompilable application*
  (Java sources recoverable with CFR), its full public API (`loqtts.h`, doxygen for the Java API),
  the voice/language descriptor formats, SDK samples and the whole 91 MB payload (1 115 files),
  extractable with the reproducible procedure in §2.
* **Voice data formats: SOLVED** (third pass, on a real voice package
  `Jorge - Spanish.exe`, Inno Setup 5.2.3, unpacked with `tools/innoextract-1.9/build/innoextract`):
  the vocal-database container (`LOQUENDOTTS7` header, two key bytes, TLV fields, 28-byte sub-header,
  110-byte frames = 640 samples = 20 ms, per-frame XOR key) in §13.1/§13.6 and `specs/ELQBin.md`;
  the unit inventory `.sde` (both generations - base-93 `L<n>`/`R<n>` and legacy decimal `D=`) in §13.5
  and `specs/SDE.md`; the 10 µs position unit in §13.4; the Spanish language layer (phoneme inventory,
  SQLite lexicon, say-as styles, phoneme table in the voice DLL) in `specs/SpanishLanguage.md`.
* **Engine ↔ voice binding: SOLVED** (§14 and `specs/EngineBinding.md`): descriptor family
  (`rcf/vcf/lcf/ycf`), database discovery by `*.bin` glob + TLV `Label` match, variant selection by
  `Freq/Coding/BitRate/Rank` vs `.vcf` keys, `.sde` registration as a shared resource, the per-unit
  driver, the decoder ABI `(handle, startSample, count, int16* out, bin)`, pitch/duration via TD-PSOLA,
  and the voice module's 8-entry dispatch table.
* **Codec 210: structurally solved, one excitation path short** (§15 and `specs/Codec210.md`):
  the 880-bit frame layout, LSF VQ, LSF->LPC, the codebooks, the polyphase band filter
  (correlation 1.000000 against the real DLL) and the final combine `out = clamp(round(2*(A-B)))` are
  exact and validated; what remains is the excitation chain (8 kHz pitch/LTP + codebooks, 16 kHz coded
  branch, 32 kHz noise branch, exact gain dequantiser), listed in order in `specs/Codec210.md` S10.3,
  with `tools/codec210_oracle.py` (Unicorn emulation of the unmodified DLL) supplying ground-truth PCM
  so every remaining stage can be validated on its own.
* **Working binary-free toolchain**: `tools/bin_dump.py`, `tools/sde_parse.py`, `tools/render_bin.py`,
  `tools/render_unit.py`, `tools/codec210.py`/`codec210_extract.py`/`codec210_oracle.py` with
  `codec210_tables.json`. Runnable end-to-end paths: §13.7 (linear voice, exact) and §15.1
  (Jorge voice, envelope-correct; waveform exactness needs the excitation stages above).
* Everything else — GUI, RMI service, prosody/lexicon/audio *control*, file formats, installer,
  licensing — is specified in §1–§9 and §12.

Single-file handoff bundle: `local://ltts7-re-bundle.md` (this report + all `specs/*.md`, ~280 KB).

Deliverables produced by this analysis (in `/home/user/Downloads/ltts_re/`):
`cab_folder.bin` (91,462,710 B, the uncompressed payload stream),
`payload/` (1 115 extracted files + `_manifest`/`payload_manifest.json`),
`src/` (decompiled Java), `decomp_director.txt` (Ghidra decompilation of the
Wise loader), `extract_payload.py`, `wise_unpack.py`.
Third-pass additions (voice package + engine internals):
`jorge/` (the unpacked voice package), `engine_re/` (engine + SDK data extracts),
`specs/` (`ELQBin.md`, `SDE.md`, `EngineBinding.md`, `Codec210.md`, `SpanishLanguage.md`, `CONTEXT.md`),
`jorge_re/` and the root `decomp_*.txt` Ghidra dumps (engine, Util, voice module, both codecs),
`tools/` (`bin_dump.py`, `sde_parse.py`, `render_bin.py`, `render_unit.py`, `codec210.py`,
`codec210_extract.py`, `codec210_oracle.py`, `codec210_tables.json`, `7zz`, `innoextract-1.9/`).

---

## 1. What the RAR contains

| Path in archive | Size | Type | Role |
|---|---|---|---|
| `1.-LTTS7 Engine Full Distribution/LTTS7 Engine Full Distribution.exe` | 15,553,024 | Wise self-extractor (MSI-style) | TTS **engine** + SAPI5 runtime prerequisite |
| `1.-…/spchapi.exe` | 770,784 | MS CAB self-extractor | Windows Speech API 5.1 redistributable |
| `2.-LOQUENDO TTS DIRECTOR 7/LOQUENDO TTS DIRECTOR 7.exe` | 35,443,712 | Wise self-extractor | **The app**: TTS Director 7.7.1 + JRE 6 + SDK + Spanish voice |
| `3.-LTTS7 Spanish Distribution/LTTS7 Spanish Distribution.exe` | 2,269,184 | Wise self-extractor | Spanish voice package (Ludoviko family) |
| `4.-Parche (crack) para las voses/Patch.exe` | 411,648 | Delphi GUI app | Voice **keygen/crack** (§8) |
| `idiomas de las voces/English Distribution LTTS7.rar` | 2,107,229 | RAR | English voice installer (`…English Distribution LTTS7.exe`, 3,321,344 B) + `m3troid300.url` |
| `…/French Distribution LTTS7.rar` | 778,477 | RAR | French voice (`…French Distribution LTTS7.exe`, 1,987,584 B) |
| `…/Rusian Distribution LTTS7.rar` | 968,612 | RAR | Russian voice (2,190,848 B) |
| `…/PORTUGUESE DISTRIBUTION LTTS7.rar` | 614,463 | RAR | Portuguese voice (1,823,744 B) |
| `…/Loquendo TTS 7 Galician Distribution7.7.0.zip` | 773,113 | ZIP | `Galician Distribution 7.7.0.exe` (1,957,376 B) |
| `…/Loquendo TTS 7 German Distribution 7.7.1.zip` | 1,555,253 | ZIP | `Loquendo_TTS_7-Win32_German_Distribution_7.7.1.exe` (2,408,448 B) + EULA/manual/Readme |

The voice distributions are all the same kind of Wise self-extractor; they can be
unpacked with `wise_unpack.py` (see §2.6). The `.url` files credit the repack
author (`http://youtube.com/m3troid300`); they are not part of the product.

Identified installer metadata (from the PE version resource):
`CompanyName=Loquendo`, `FileDescription=Loquendo TTS 7 SDK Distribution`,
`FileVersion/ProductVersion=7.4.0.0` (loader), product version installed `7.4.0`,
app version string `7.7.1`.

---

## 2. The installer format (Wise Installation System, "WISE30139")

### 2.1 PE layout, loader and imports

`LOQUENDO TTS DIRECTOR 7.exe` (md5 `f575b9198a334b3d74c8d624fc03ac79`) is a
32-bit PE with four sections plus resources:

| Section | RVA | VirtualSize | Raw offset | RawSize |
|---|---|---|---|---|
| `.text` | 0x1000 | 0x5F42 | 0x400 | 0x6000 |
| `.rdata` | 0x7000 | 0x1AAA | 0x6400 | 0x1C00 |
| `.data` | 0x9000 | 0x10850 | 0x8000 | 0x600 |
| `.WISE` | 0x1A000 | 0x21BF618 | 0x8600 | 0x21BF800 |
| `.rsrc` | 0x21DA000 | 0x5518 | 0x21C7E00 | 0x5600 |

Image base 0x400000. Imports (verified): `WSOCK32.dll` **by ordinal** —
`3=closesocket, 4=connect, 9=htons, 10=inet_addr, 16=recv, 19=send, 21=setsockopt,
22=shutdown, 23=socket, 52=gethostbyname, 101/111=WSAAsyncGetHostByName/
WSACancelAsyncRequest, 115=WSAStartup, 116=WSACleanup` — i.e. a built-in HTTP/FTP
downloader; plus `VERSION.dll`, `KERNEL32.dll` (incl. `_lread/_lwrite/_llseek/
_lcreat/_lclose`, registry, `GetTempPathA/GetTempFileNameA`, process/token APIs),
`USER32`, `GDI32`, `ADVAPI32`, `SHELL32` (`ShellExecuteExA`).

The loader is a stock Wise stub: it locates the `.WISE` section via the PE section
table, seeks to its `PointerToRawData`, then interprets the section (Ghidra
decompilation: `decomp_director.txt`, functions `FUN_00402f41` = find `.WISE`,
`entry` = main installer, `FUN_00403975` = XOR/PRNG file decryptor,
`FUN_0040408e` = file extractor with CRC32, `FUN_00402f17` = PRNG,
`FUN_00404197` = script/UI driver, plus `_PasswordDlg`, `_ProgressDlg`,
`_LanguageDlg` dialog procedures).

* CRC32: standard reflected polynomial `0xEDB88320`, table built by
  `FUN_004028c7`, updated by `_UpdateCRC`.
* Optional file encryption: each file's bytes are XORed with a 31-bit LCG
  keystream (`x := (x mod 0xADC8)*0xBC8F − (x div 0xADC8)*0xD47`, `+= 0x7FFFFFFF`
  when negative; dword-wise then `(seed mod 0xFF)+1` per tail byte), seeded
  `0x5BC25A` and only used when the package has a password
  (`1 < passwordLen`). **The Loquendo packages have an empty password**
  (`passwordLen = 1`), so stored data is *not* XORed.

### 2.2 `.WISE` section layout (verified for all three Wise installers)

```
0x000  76-byte header, 19×u32.  Only field [0x18] (i.e. offset 0x18) is non-zero:
       it equals the end offset of the embedded payload container
       (Director: 0x21BF204; Engine: 0xEC7004; Spanish: 0x21BE04).
0x04C  1 byte flag
0x04D  5 length bytes, then 5 NUL-terminated strings of those lengths:
         [0] staging INI name  "WIS30139AC2AB194AEA865F2154240D851F_7_4_0.TMP"
         [1] ProductCode GUID  "{30139AC2-AB19-4AEA-865F-2154240D851F}"
         [2] ProductVersion    "7.4.0"
         [3] transform name    (empty)
         [4] remove-previous   "1"
0x0B0  21 length bytes -> font/title strings, then
         87-byte font+window-title block ("MS Sans Serif" …),
         1 byte password (empty), and the message string block
         (length-prefixed installer messages, e.g. "You must have
         administrator rights…", "…is already installed…", "CRCError",
         "SpaceError", "Internet", "Reboot", "MinVerMessage",
         "/Lv c:\LTTS_7-SDK.log /I", "English,1033" …).
        Followed by installer script/messages and Wise "property"/dialog tables
        (ASCII and UTF-16, e.g. the EULA text, `[_WiseDialogFontDefault]`,
        `SOFTWARE\Loquendo\LTTS7\Engine`, regsvr32 custom actions …).
```

### 2.3 The embedded payload container (MS CAB "MSCF") — **the key find**

Inside the `.WISE` section there is a genuine **MSZIP cabinet**:

* Director: `MSCF` at section offset **0x4B014**, `cbCabinet = 0x1FEFEC2`
  (33 480 386 B), `cFolders = 1`, `cFiles = 1115`, `coffFiles = 0x1030`,
  `flags = 4` (reserve present), `cbCFHeader = 0x1000`.
* Folder 0: `coffCabStart = 0xB27B`, `cCFData = 2792`, `typeCompress = 1` (MSZIP).
* The **file index** lives at `cab + coffFiles` and ends at
  `cab + coffCabStart`.  Each record is **16 bytes followed by the NUL-terminated
  name** (note: fields *precede* the name):

  ```
  struct WiseFileRec {      // 16 bytes, little endian
      uint32 size;          //   0x00  uncompressed size
      uint32 offset;        //   0x04  offset inside the *uncompressed* folder stream
      uint16 f1;            //   0x08  flags (always 0 in these packages)
      uint16 f2;            //   0x0A  DOS date/timestamp-ish (0x38CA..0x3902)
      uint32 hash;          //   0x0C  opaque (checksum/pointer; not needed)
  };  // followed by char name[] ; NUL terminated
  ```

  Verified invariant: the records **tile the folder stream gaplessly**
  (`off[i+1] == off[i] + size[i]`, first offset 0, last end == 0x5739C36 ==
  folder length; Σ sizes = 91 462 710).  `f1/f2/hash` are not required for
  extraction.

* **CFDATA blocks** (from `cab + coffCabStart`): `uint32 csum; uint16 cbData;
  uint16 cbUncomp; byte data[cbData];` — for MSZIP each `data` starts with the
  two ASCII bytes `CK` followed by a raw DEFLATE stream that continues the
  previous block's 32 KiB history (equivalent to zlib `inflateInit2(-15)` with
  `zdict = last 32768 bytes of output`).  Concatenating the 2792 blocks yields
  the folder stream byte-for-byte (`cab_folder.bin`,
  md5 `6031c37e91c05e2fed553f125caea94f`).  It starts with
  `%PDF-1.3\n%\xe2\xe3\xcf\xd3\r\n` (Loquendo TTS 7 Installation Manual) and
  contains MZ/PE, ZIP/JAR, PNG/GIF/JPEG, TTF, HTML, text and the whole JRE.

### 2.4 Loader behaviour observed (for a faithful re-implementation of the installer)

* Administrator check, Wise staging INI (`%TEMP%\WIS30139….TMP`), progress dialog,
  splash AVI (`FindResource` + `MCIWndCreateA`), optional password dialog,
  language dialog, EULA, "remove previous version" via MSI API
  (`MsiGetProductInfoA`/`MsiConfigureProductA`), .NET/MSI/WinInit version gates,
  reboot handling (registry `…\Run`/`RunOnce` value `WiseStubReboot`,
  `ExitWindowsEx`), `msiexec` invocation with `TRANSFORMS=`, and the regsvr32
  custom actions for the SAPI engine (`\bin\LTTS7SAPI5.dll`).
* Registry written (seen in script strings): `HKLM\SOFTWARE\Loquendo\LTTS7\Engine`,
  `…\LTTS7\default.session`, `…\LTTS7\LicenseCode`, plus ARP entries.

### 2.5 Reproduction recipe

```bash
./tools/7zz e -o/tmp/ws "<installer>.exe" .WISE -y       # .WISE section
python3 extract_payload.py                               # Director (fixed offsets)
python3 wise_unpack.py "<installer>.exe" <outdir>        # generic (engine/voices)
```

`wise_unpack.py` auto-locates the sane `MSCF`, reads `cFolders/cFiles/coffFiles`,
decompresses folder 0 and splits it by the index. Confirmed output for the
Director installer: **1 115 files, 91 462 710 bytes, gapless tiling**.

### 2.6 Per-installer specifics

| Installer | `.WISE` size | MSCF offset | cFiles | Notes |
|---|---|---|---|---|
| Director 7 | 0x21BF800 | 0x4B014 | 1115 | full SDK + JRE + Spanish voice |
| Engine Full Distribution | 0xEC7600 | 0x94E823 | 9 | cabinet holds the SAPI5 prerequisite (`sapi.dll`, `sapi.cpl`, `sapisvr.exe`, `speech.chm`, `sapicpl.hlp`); the engine payload is MSI-style (embedded OLE database) |
| Spanish Distribution | 0x21C400 | 0x660F | – | Spanish voice package |
| Voice packs (EN/FR/RU/PT/GL/DE) | – | – | – | same Wise format, one voice each |

---

## 3. Extracted payload (Director installer) — inventory & install layout

`payload/` = 1 115 files, 91 462 710 bytes total; manifest with
`name/wise_name/size/off/magic` in `payload_manifest.json` (+ `_manifest.json`
when using the generic tool). File-kind census: 82 PE (`MZ`), 28 ZIP (`PK`),
39 PNG, 16 GIF, 3 JPEG, 1 PDF, 946 other (JAR/HTML/CHM/text/voice data/...).

**Naming note:** the Wise index stores `<name><decimal id>`; on-disk files keep
that id suffix (e.g. `TTSDirector.jar8`, `loqtts.h` (no id), `attstest.exe512`).
`payload_manifest.json.name` is the on-disk name and `wise_name` the index
string; the tables below drop the numeric suffix for readability.

### 3.1 Headline components

| Component | Size | Description |
|---|---|---|
| `TTSDirector.jar` | 878 997 | **The app** (`Main-Class: loquendo.tts.ttsdirector.TTSDirectorMain`, splash `TTSDirector.jpg`, 75 classes) |
| `TTSDirectorManager.jar` | 15 829 | Launcher/console (`…ttsdirectormanager.TTSDirectorManager`, 6 classes) |
| `TTSEngineServer.jar` | 61 506 | RMI TTS engine server (`…engineserver.TTSServerManager`, 15 classes, incl. RMI `_Skel`) |
| `TTSEngineServerClient.jar` | 39 860 | Server-side stubs/skeletons + shared classes |
| `TTSEngineClient.jar` | 30 669 | RMI client + streaming player (`…engineclient.TTSEngineClientRMI`, 7 classes) |
| `TTSLexiconManager.jar` | 377 326 | Lexicon editor GUI (181 classes) |
| `TTSDirectorlookandfeel.jar`, `TTSLexiconManagerlookandfeel.jar`, `lookandfeel.jar` | 138 756 / 666 778 / … | Loquendo Swing L&F (`loquendo.lookandfeel.LoquendoLookAndFeel`) |
| `LTTS7JavaTTSUtil.jar` (164 100), `LTTS7JavaUtil.jar` (65 214) | | JDOM-based utilities, lexicon XML, DB/diff helpers |
| `rt.jar` (42 718 562), `jvm.dll` (2 334 720), `java.exe/javaw.exe`, `awt.dll`, `fontmanager.dll`, `msvcr71.dll` (348 160), … | | bundled **JRE 6** (Sun 1.6.0_07, `java -version` strings `10.0-b22`) |
| `LTTS7Ludoviko.dll` (57 344), `LTTS7Esperanto.dll` (73 728) | | per-voice native libraries |
| `Ludoviko.vde` 455, `Ludoviko.vcf` 331, `Ludoviko.sde` 186 290, `Ludoviko.16000.linear.256000.10.bin` 5 069 459 | | Spanish voice descriptors + vocal database |
| `Esperanto.lde` 258, `Esperanto.lcf` 181 | | Esperanto language descriptors |
| `LoqTTS7.lib` 69 054, `loqtts.h` 13 340, `loqtypes.h` 9 243 | | **engine C API** (import lib + headers) |
| `HelloTTS.c/.dsp/.java/.vbp/.vcproj`, `ReadSlice.c/.dsp/.vcproj`, `SAPI4.*`, `SAPI5.*`, `LangGuess.c`, `TTSWebServer.asp` | | SDK samples (C, Java, VB, ASP, SAPI4/SAPI5) |
| `TTSApp.exe` 806 912, `attstest.exe` 204 824, `destfile.exe` 36 376 | | SAPI5 test applications |
| `VoiceExperience.exe` 2 076 672, `TTSFileGenerator.exe` 77 824 | | voice demo player, batch audio generator |
| `Loquendo_TTS_7_{Installation,Users,Programmers,Java_Programmers}_…` (`pdf`, 3× `chm`) | | documentation |
| doxygen HTML tree (`*.html`, `loquendo.css`, `ftv2*.png`, `tabs.css`…) | | **Java engine API reference** (`loquendo.tts.engine.*`) |
| `client.policy` (582), `administrator.policy` (649), `security.policy` (807), `rmid.policy` (257), `US_export_policy.jar`, `local_policy.jar` | | Java security policies (see §8) |
| `TTSDirector.bat` (81), `TTSDirectorManager.bat` (70), `TTSDirectorClient.bat` (100) | | launchers (contents below) |

Launchers (verbatim):

```bat
rem TTSDirector.bat
@echo off
start ..\jre\bin\javaw.exe -jar TTSDirectorManager.jar standalone
exit

rem TTSDirectorManager.bat
@echo off
start ..\jre\bin\javaw.exe -jar TTSDirectorManager.jar
exit

rem TTSDirectorClient.bat
@echo off
start ..\jre\bin\javaw.exe -Djava.security.policy=client.policy -jar TTSDirector.jar
exit
```

**Install layout** (inferred from launcher paths, engine strings and the Wise
script; the Wise script encodes per-file destinations):
`<INSTALLDIR>\bin\` (native engine + `LTTS7SAPI5.dll` registered with
`regsvr32 /s`), `<INSTALLDIR>\…\<app>\` (the `.bat` files next to
`TTSDirector.jar`, with `..\jre\` as sibling), `voices\<Voice>\` (voice data,
cf. `VoicePath = "voices/Ludoviko"` in `Ludoviko.vcf`), documentation folders.
Registry: `HKLM\SOFTWARE\Loquendo\LTTS7\{Engine,default.session,LicenseCode}`.

---

## 4. Application architecture (fully recovered, decompiled sources in `src/`)

The product is a **3-tier client/server TTS system** (Java RMI), 7.7.1:

```
TTSDirector.bat  -> Manager (TTSDirectorManager.jar standalone)
                      |  creates RMI registry on port 1099
                      |  binds rmi://localhost:1099/TTSEngineServer  (TTSEngineServerUnicastImpl)
                      |  binds rmi://localhost:1099/TTSEngineServerAdministrator
                      |  spawns: javaw -Djava.security.policy=client.policy -jar TTSDirector.jar -standalone
                      v
TTSDirector.jar (Swing GUI) --RMI--> TTSEngineServer  --JNI--> loquendo.tts.engine.* --> loqtts.dll
```

* RMI constants: registry port **1099** (configurable in the manager GUI),
  service names **`TTSEngineServer`** and **`TTSEngineServerAdministrator`**
  (`TTSServerManager.SERVER_NAME`, `ADMIN_NAME`), codebase
  `java.rmi.server.codebase = file:/<dir>/TTSEngineServerClient.jar`,
  policy `administrator.policy`.
* `TTSServerManager` also supports RMI **activation** (`ActivationGroup`,
  `ActivationDesc`) and a graphic mode.
* Client (`TTSEngineClientRMI`, 3898 lines) registers itself
  (`server.registerClient()` → `clientCode`), pushes a `TTSParams` record, calls
  `server.read(text, params, aSync, clientCode)`, and streams the synthesised PCM
  back with `server.getOutBuffer(clientCode)` from a `Writer` thread
  (`saveAudio()` writes it to a `.wav`/`.asf` file, a `Player` thread feeds
  `javax.sound`). `getTextInfo()` returns per-word/phoneme timing and
  `getPhoneticTranscription()` the phoneme string.
* Engine server (`TTSEngineServerImpl`/`TTSEngineServerUnicastImpl`,
  1 237/1 216 lines) wraps one native reader per client
  (`TTSReaderWrapper`, 568 lines) and implements the whole API below; the native
  layer is the `loquendo.tts.engine` JNI package from `Loqjapi.jar`
  (shipped by the *Engine* distribution, not the Director archive).

### 4.1 RMI service interface `TTSEngineServer` (recovered signature list)

Server/client lifecycle: `initServer()`, `initServer(boolean)`, `shutDown()`,
`ping()`, `registerClient() -> String`, `unregisterClient(String)`,
`deleteSession()`.
Resources: `GetAvailableTTSResources(boolean)`, `FillVoicesAndComments()`,
`GetVoicesAndComments() -> String[]`, `GetVoiceAndComments(String)`,
`GetVoice(int)`, `GetVoiceIndex/GetLanguageIndex/GetFrequencyIndex`,
`checkVoicePresence/checkLanguagePresence`, `isBuiltinVoice`,
`GetVoiceMotherTongue`, `getVoiceParams(String,String) -> int[]`,
`deleteVoice(String)`, `GetGilded(String,String)`, `GetLanguages`, `GetStyles`,
`getVoiceFlavours(String,String)`.
Enumerations/ranges: `GetFrequencies`, `GetCodings`, `GetVolumeRange`,
`GetVolumePercentageRange`, `GetPitchRange`, `GetPitchPercentageRange`,
`GetSpeedRange`, `GetSpeedPercentageRange`, `GetTimbreRange`,
`GetTimbrePercentageRange`, `GetBalanceRange`, `GetGainRange`, `GetDelayRange`,
`GetDefault{Gain,Delay,Balance}`.
Speech: `read(String,TTSParams,boolean,String)`,
`readForUnitSelection(String,TTSParams,String)`, `stop(String)`,
`getReadingsMode()`, `getPhoneticTranscription(String,TTSParams,String)`,
`getOutBuffer(String) -> byte[]`, `getTextInfo(String) -> ArrayList<ArrayList>`,
`GetSpeechAtomTree(String,String) -> TreeModel`,
`saveVoiceConfiguration(String,String,TTSParams)`, `setDefaultAttributes(String)`.
Equaliser: `getGraphicEQBand(int[],String) -> float[]`,
`setGraphicEQBand(int[],float[],String)`, `resetGraphicEQ(String)`,
`setGraphicEQPreset(String,String)`, `getGraphicEQPreset(String) -> String[]`,
`addParametricEQ`, plus `detectLanguage`/language-guess helpers (see below).

`TTSParams` (serialisable; defaults): `voice="Mario"`, `language="Italian"`,
`frequency="32000"`, `coding="linear"`, `textFormat="autodetect"`,
`textEncoding="utf8"`, `voiceFlavour=null`, `channels=2`, `volume=50`,
`pitch=50`, `speed=50`, `timbre=50`, `gain=0`, `delay=0`, `balance=0`, plus
percentage variants (`*Percent`).

### 4.2 The `read()` pipeline (server side) — behavioural spec

1. `wrapper.setParam("TextCoding", params.textEncoding)`.
2. Format detection: if `textFormat == "autodetect"` → try `validateXML(text,false)`;
   success ⇒ SSML. `"ssml"` ⇒ SSML.
3. Language/voice: take the first space-separated token of `params.language` /
   `params.voice`; `"mother"` resolves via `GetVoiceMotherTongue(voice)`.
   A *voice flavour* makes the server synthesise a derived VCF:
   `TTSVoice(voice)`, `setParam ForcedSampleRate/ForcedCoding/ForcedBitrate`,
   `setParam <VOICEFLAVOURID>=yes`, `saveCF(voice+"-"+flavour+"-"+rate+"-"+coding+"-"+bitrate)`.
4. Audio: `setLanguage(lang)` then `audioDestination.setAudio(frequency, coding, channels)`.
5. If SSML: `setParam("TextFormat","ssml")`, `reader.read(text, aSync, false)`.
6. Else (plain text): `setParam("TextFormat","plain")` and the server **wraps the
   text in LTD control tags**:

   ```
   \{voice=<V>\{language=<L>\{volume=<vol>\{pitch=<p>\{speed=<s>\{timbre=<t>\
   {balance=<b>\{reverb=<gain>,<delay>\{pause=0 . \n <text>[ .]
   ```
   and calls `reader.read(that, aSync, false)`. (Single-character text gets a
   trailing " ." to make the engine speak it.)

This is the canonical "speak this text with these prosody settings" behaviour a
re-implementation must reproduce.

---

## 5. Engine API to be reproduced

### 5.1 Java API — `loquendo.tts.engine` (documented in the payload's doxygen)

* `TTSSession` — `TTSSession()`, `delete()`, `query()`, `queryAttribute()`,
  `getParam()`, `testPersona()`.
* `TTSReader` — `TTSReader(TTSSession)`, `delete()`, `read(text, async, fromFile)`,
  `pause()`, `resume()`, `done()`, `setAudio(dest, device, rate, coding, channels)`,
  `audioFreeSpace()`, `loadPersona(name, language, style)`,
  `setVoice/setLanguage/setStyle` (via voice objects), prosody
  `set/get Pitch|Speed|Volume|Timbre|Balance|Gain|Delay` (+ absolute and
  percentage variants, `setPitchRange`, `setSpeedRange`, `setDefaultAttribute`,
  `setReverb`), text `setParam/getParam` (`TextEncoding`, `TextFormat`,
  `TextCoding`, `VoiceFlavour`, …), lexicon hooks, events
  `addTTSListener/removeTTSListener/removeAllListeners`, speech atoms
  (unit selection), `phoneticTranscription()`, `checkPhoneticTranscription()`,
  `saveCF(name)`, graphic EQ `set/getGraphicEQBand`, `setGraphicEQPreset`,
  `resetGraphicEQ`.
* `TTSVoice` — `TTSVoice(session,name)`, `activate()`, `delete()`,
  `setParam/getParam` (`ForcedSampleRate`, `ForcedCoding`, `ForcedBitrate`, …),
  `saveCF(name)`, speech-atom inventory access
  (`locateSpeechAtomInventory`, `getSpeechAtomChild/Sibling`).
* `TTSLanguage` — `activate()`, `setParam/getParam`, `saveCF`.
* `TTSLexicon` — `addEntry`, `removeEntry`, `findEntry`, `activate`, `importfile`,
  `exportfile`.
* `TTSConfiguration` — `getVersionInfo`, `saveParam`, `loadParam`, `delete`.
* `TTSEvent` — `getReason()`, `getStringData()`; `TTSListener` callback interface;
  `TTSAudioDestination` — `setAudio(rate, coding, channels)` (per-client PCM sink);
  `TTSException` — `failure()`.

### 5.2 C API — `loqtts.h` / `loqtypes.h` (complete surface, 100+ entry points)

Reader/session: `ttsNewSession`, `ttsDeleteSession`, `ttsNewReader`,
`ttsDeleteReader`, `ttsClone`, `ttsClaimLicense`, `ttsUnclaimLicense`,
`ttsGetVersionInfo`, `ttsGetErrorMessage`.
Speech output: `ttsRead`, `ttsReadSlice`, `ttsReadNextSlice`, `ttsPause`,
`ttsResume`, `ttsSkip`, `ttsWaitForEndOfSpeech`, `ttsStop`, `ttsReset`,
`ttsAudioFreeSpace`, `ttsInject`, `ttsSetAudio`, `ttsGetPCM`.
Voices/personas/languages/styles: `ttsNewVoice`, `ttsDeleteVoice`, `ttsSetVoice`,
`ttsLoadPersona`, `ttsLoadPersonaFromFile`, `ttsTestPersona`, `ttsNewLanguage`,
`ttsSetLanguage`, `ttsDeleteLanguage`, `ttsNewStyle`, `ttsSetStyle`,
`ttsDeleteStyle`, `ttsLanguageGuess`, `ttsSetTextEncoding/Format` (+getters).
Prosody/audio processing: `ttsSet/Get Pitch|Speed|Volume|Timbre|Reverb|Balance`
(int + absolute), `ttsSet/GetAbsolutePitch/Speed/Volume`, `ttsAddParametricEQ`,
`ttsSetGraphicEQPreset/Band`, `ttsGetGraphicEQBand`, `ttsResetGraphicEQ`,
`ttsResetParametricEQ`, `ttsSaveCF`.
Lexicons: `ttsOpenLexicon`, `ttsActivateLexicon`, `ttsCloseLexicon`,
`ttsFindLexiconEntry`, `ttsAddLexiconEntry`, `ttsRemoveLexiconEntry`,
`ttsImportLexicon`, `ttsExportLexicon`, `ttsEnumLexicon{Entry}First/Next`,
`ttsGetLexiconFilename`.
Events/callbacks: `ttsSetCallback`, `ttsEnableEvent`, `ttsSetURLCallback`.
Queries/atoms/XML: `ttsQuery`, `ttsQueryAttribute`, `ttsEnumFirst/Next/Close`,
`ttsLocateSpeechAtomInventory`, `ttsGetSpeechAtom`, `ttsValidateXML`,
`ttsSSMLConvert`, `ttsPhoneticTranscription`, `ttsCheckPhoneticTranscription`,
`ttsGetPhonemeInfo`, `ttsGetTag`.
Configuration: `ttsSetParam`, `ttsGetParam`, `ttsSaveConfigurationParam`,
`ttsLoadConfigurationParam`, `ttsDeleteConfiguration`,
`ttsEnumConfigurationParameterFirst/Next`.

Types (`loqtypes.h`): `ttsHandleType`, `ttsResultType` (`tts_OK`, error codes),
`ttsBoolType`, `ttsCodings` (`tts_LINEAR`, …), channel consts, page/mix-language
enums, `ttsReasonType` for events. Error strings via `ttsGetErrorMessage`.
Minimal usage (payload `HelloTTS.c`): `ttsNewReader(&h,NULL)` →
`ttsLoadPersona(h,"Ludoviko",NULL,NULL)` →
`ttsSetAudio(h,"LTTS7AudioBoard",NULL,32000,tts_LINEAR,tts_STEREO,0)` →
`ttsRead(h,"\\demosentence",FALSE,FALSE,NULL)` → `ttsDeleteSession(NULL)`.
Java equivalent in `HelloTTS.java` (same sequence with `new TTSSession()`,
`new TTSReader`, `setAudio`, `loadPersona`, `setParam("TextEncoding","utf-8")`,
`read`).

### 5.3 LTD control-tag language (used by the Director and by `read()`)

Backslash tags (single `\` opens a tag, `\` closes the previous one; `\{name=value`
sets a parameter, remaining text is spoken):
`\voice=`, `\language=`, `\style=`, `\persona=`, `\volume`, `\pitch`,
`\speed`, `\SpeedFast=`, `\PitchDelta=`, `\PitchContour=`, `\pause=`,
`\emphasis`, `\prominence`, `\ipa=`, `\pause=`, `\spell`, `\say-as`-family
(see the Say-As menu), `\book=`, `\bookmark=`, `\item=`, `\plugin=`,
`\ExcludeUnit=`, `\u`, `\U`, and SSML is accepted verbatim when
`TextFormat=ssml` (`validateXML` autodetects `<speak>`/`<…>` documents).
Payload sample: `ttsRead(h,"\\demosentence",…)` = built-in demo sentence macro.

### 5.4 Audio destinations / formats

* Destinations: `LTTS7AudioBoard` (DirectSound/WaveOut playback),
  `LTTS7AudioFile` (write WAV/raw), buffer destination (used with the RMI
  `clientCode` so the server hands PCM chunks to the client), `LTTS7AudioExt`
  (streaming). Coding strings from `GetCodings()`: `linear`, `alaw`, `ulaw`,
  `adpcm`, … Sample rates from `GetFrequencies()` (8/11.025/16/22.05/32/44.1/48 kHz),
  1–2 channels.

### 5.5 Voice / language descriptor file formats (plain text, verified)

`<Voice>.vde` — voice descriptor (`; LTTSComponentVersion=7.1.0`):
`BaseDescription`, `Library` (`LTTS7Ludoviko, Ludoviko`), `BaseSpeed`, `BasePitch`,
`Algorithm` (`Sequens`), `Gender`, `Age`, `MotherTongue`, `MotherTongueAliases`,
`DemoSentence`, … (455 B for Ludoviko).

`<Voice>.vcf` — voice configurator (created/edited by "Voice Creator"/flavours):
`Description`, `BaseVoice`, `VoicePath` (`voices/Ludoviko`), `VocalDBName[0]`,
optional `Pitch/Speed/Volume/Timber`, `Built-in`.

`<Lang>.lde` — language descriptor: `BaseDescription`, `Library`
(`LTTS7Esperanto, Esperanto`), `Language` (`Esperanto,eo`), `WinLangid` (1536),
`DefaultVariant`.

`<Lang>.lcf` — language configurator (companion of `.lde`).

Voice payload: `<Voice>.<rate>.linear.<bitrate>.<n>.bin` = vocal database
(Ludoviko: 5 069 459 B, the `Ludoviko.16000.linear.256000.10.bin` file),
`<Voice>.sde` = Sequens segment/DB index (186 290 B), plus the per-voice
`LTTS7<Voice>.dll` (57 344 B for Ludoviko). These are the binary acoustic assets;
their internal structure is not documented and is engine-specific.

---

## 6. GUI functionality — what the Director app does

Constants are in `TTSDirectorConst` (decompiled, `src/TTSDirector/…`):
`TTSDirectorVersion="7.7.1"`, `TOOL_NAME="Loquendo TTS Director"`,
default frame 1024×768, `MAXUNDO=100`, OS enum (Windows/Linux/SunOS/other),
fonts, DRCRange `{1,1,5}`.

### 6.1 Main window

* Top strip: **voice combo** (250×19), **language combo** (180×19),
  **reading-mode combo** + label, **Play** and **Stop** buttons, and a
  font/size combo for the editor; mouse auto-play support
  (`MenuMouseAutoPlayGapX`, timed play of the current paragraph).
* Central `JTabbedPane`: one document per tab ("Untitled", "*" when dirty),
  each tab = rich text editor + per-document prosody controls
  (`TTSEditorPane`, `TTSTabbedPane`, `TTSSlidersControl`).
* Documents: plain text, **LTD** (Loquendo TTS Director format) or **SSML**,
  chosen under *View ▸ Highlight as* (Plain Text / LTD / SSML) with
  syntax highlighting (`TTSColorChooser` to customise colours) and
  *View ▸ Validate*.
* Editor: undo/redo (100), cut/copy/paste/select-all, word wrap,
  document size filter, print (`TTSPrintingThread`), font config
  (`TTSDirectorFont`), search/replace, bookmarks list.

### 6.2 Menus and commands (verbatim command names from `TTSDirectorConst`)

* **File**: New, Open…, Load…, Save, Save As…, Save All, Close, Close All,
  **Save Audio As…**, Print selected tab…, Exit.
* **Edit**: Cut, Copy, Paste, Select All, Undo, Redo.
* **View**: WordWrap, Highlight as ▸ Plain Text / LTD / SSML,
  Customize Highlight Colors…, Validate.
* **Effects**: Mixer… (mixer wizard), Play/Manage/Pause/Resume/Stop audio files,
  Set Global Path, Recording (start/stop), Loop, Repeat Counter,
  Fade In/Fade Out (ms), Volume (%), Ignore Absolute Path, Switch to Play Mode,
  Save Effects list as….
* **Configuration**: Voice flavours (Default/…), ControlTags, Audio, Mixer,
  Audio Files, **Reverb**, **Balance**, **Dynamic Range Control** ("Set DRC
  curve", "Reset DRC"), Bookmarks, Language (Set Foreign Language…, Reset Native
  Language, Language Guesser Configuration, Greeklish on/off, French stress
  on/off), AutoGuesser Capability (voice/language change per
  paragraph/sentence/phrase/word — 12 modes), Pronunciation, Phonetic Input
  (Transcription Plus Word, Insert IPA Phonemes, Insert SAMPA Phonemes),
  Say As (cardinal/ordinal masc/fem, telephone number, code number, time, date,
  currency, reset all permanent modifiers), User Lexicon (Load/Unload/Activate),
  Prosody (Duration Control → Force/End Force Duration; Emphasis → Increase/
  Decrease/Reset; Expressivity → Play An Extraphonetic Sound; Punctuation Pauses
  → Insert A Pause, short/medium/long pause lengths; Prominence → Stress/
  Unstress A Word; Speaking Rate → percentage/increase/decrease/reset, Use Fast
  Algorithm; Pitch → percentage/increase/decrease/reset, Monotonous, Pitch Delta,
  Pitch Contour, End Pitch Contour; Volume → percentage/increase/decrease/reset;
  Timbre → change/reset; Reverb → change/reset; Balance → change/left/right/reset),
  Reading Settings (Reading Style set/reset, Unit Selection, Tuning…),
  Spelling (Spell Next Word, Spelling level Normal/Every word/None, Read Aloud
  Control Tags, Spell punctuation), Prosodic Pauses (breath pause at phrase
  boundaries, word-by-word, pauses at empty lines/multiple spaces/titles),
  Voice (Voice Change…, Persona Change…).
* **Tools**: Loquendo LexEditor (`LexEditor.exe`), Loquendo TTS Voice Creator
  (`voices manager`), Loquendo TTS Lexicons Converter, Loquendo TTS Lexicon
  Manager (`TTSLexiconManager.jar`).
* **Help**: about box, HTML help (`TTSDirectorHelp`), CHM manuals.

Dialogs/wizards delivered: `TTSMixerWizard` (1237 lines, audio-file mixing with
fade/volume/loop/record and tag insertion), `TTSGraphicEqualizer` /
`TTSGraphicEqualizer1030Bande` (10- and 30-band EQ incl. presets),
`TTSDRCWizard` (dynamic range control curve — DRCRange `{1,1,5}`),
`TTSUnitSelector` (voice unit/persona selection), `TTSLangChooser`,
`TTSVoicesManager` (create/delete voice variants), `TTSChooserDialog`,
`OpenConvertDialog` + `ConvertDialog` (562 lines: batch conversion),
`TTSDirectorAboutBox`, `TTSAccessoryFileChooser`, `TimedMessage`.

### 6.3 File formats

* `.txt` — plain text; `.ssml` — SSML; `.ltd` — Director document: an editor text
  that *begins with an LTD header line of control tags*, parsed by
  `TTSFileHeader.extractHeaderParam()` which scans for `voice=`, `language=`,
  `volume=`, `speed=`, `pitch=`, `timbre=`, `reverb=` (two comma-separated values
  → `gain`,`delay`), `balance=`, values terminated by `\` or space
  (e.g. `\voice=Ludoviko\language=Spanish\volume=50…`).
* Export: **WAV** (`WAV file (*.wav)`) and **ASF**
  (`Microsoft Advanced Systems Format (*.asf)`) through
  `TTSEngineClientRMI.saveAudio(file, type, text)`; selectable channels, coding
  and sample rate; conversion dialog also emits `.txt`/`.ssml`/`.ltd` targets.
* Printing produces the current tab.

### 6.4 Other executables

* `TTSDirectorManager` — GUI console (port field default 1099, uri `rmi://`,
  "start server"/"stop server" buttons, standalone switch) and CLI
  (`standalone` argument starts registry + server + Director).
* `TTSLexiconManager.jar` — full lexicon editor (`.lex`/XML via
  `LTTS7JavaTTSUtil` JDOM classes: `Lex`, `Entry`, `Lex0`, diff/patch, DB).
* `VoiceExperience.exe` — voice demo player (vocabulary demo sentences).
* `TTSFileGenerator.exe` — batch generator (text → audio files).
* `TTSApp.exe`, `attstest.exe`, `destfile.exe` — SAPI5 validation utilities
  (voice attributes / destination-file / generic TTS app).
* `TTSWebServer.asp` — ActiveX/ASP sample server (per README).

---

## 7. Licensing model

* Engine licences are **per-voice**, keyed to the machine: the crack
  (`Patch.exe`, Borland Delphi, 8 sections) reads the MAC from
  `HKLM\SOFTWARE\Microsoft\SystemID`, computes a key and writes
  `HKLM\SOFTWARE\Loquendo\LTTS7\LicenseCode` (strings: `Enter valid MAC!`,
  `Can't delete HKLM\`, `Can't delete HKCU\`, `TTSVersion`, `Channels`,
  `keygen`, `0123456789ABCDEF`). Error strings `Error #1..#7` mark the flow.
* Java side: `client.policy` grants read/write/delete on `<<ALL FILES>>`,
  sockets ≥1024, clipboard/show-window; `administrator.policy` additionally
  `loadLibrary.*`, `exitVM`, writes to `${user.home}/.Loquendo/*`;
  `rmid.policy`/`security.policy` are the JRE defaults.
* A re-implementation that keeps the original engine must keep the
  `LicenseCode` contract (or reuse the same MAC-key scheme) for the voices to
  load; a re-implementation with a substitute engine can drop it.

---

## 8. How to re-implement (concrete plan for another agent)

**Phase 0 — reproduce the payload.** Run `wise_unpack.py` (or
`extract_payload.py`) to obtain `payload/`; verify: 1 115 files,
91 462 710 bytes, `TTSDirector.jar` md5 `0ee06cf651fea786b6cd816e96a05097`,
`TTSEngineServer.jar1` md5 `aa6863d02162cbc1f68b9cb322d442a5`,
`loqtts.h` md5 `6ac716ab4cdd7416fc1b9842f5aadea3`,
`Ludoviko.vde` md5 `7ef62dafd49eba4741b437f33badb8cc`, `cab_folder.bin` md5
`6031c37e91c05e2fed553f125caea94f`.

**Phase 1 — app skeleton (no synthesis).** Rebuild the Java client/server:
* `TTSEngineServer` RMI interface exactly as in §4.1, bound as
  `rmi://<host>:1099/TTSEngineServer` (+ `…Administrator`), `clientCode`
  registration, `TTSParams` transfer object, PCM streaming via `getOutBuffer`.
* `TTSEngineServerImpl.read()` semantics of §4.2 (SSML autodetect via XML
  validation, LTD wrapper string, audio destination setup, voice flavours as
  derived VCFs).
* Director Swing GUI: top strip + tabs + menus of §6 using the same command
  strings, `.ltd` header parsing, `.txt`/`.ssml`/`.ltd` documents, WAV/ASF
  export, undo/redo, highlight modes, bookmarks, EQ/DRC/mixer wizards
  (the decompiled `src/TTSDirector/**` is a direct reference implementation).

**Phase 2 — engine binding.** Two options:
1. *Reuse*: load `loqtts.dll` + voice DLLs + voice databases from the Engine
   distribution and bind them through the documented API (§5.1/§5.2) via JNI
   (recreate `Loqjapi.jar`’s `loquendo.tts.engine.*` classes) — the semantics of
   every call are documented in the payload’s doxygen/headers and exercised by
   the samples.
2. *Substitute*: implement the same C/Java API on top of any modern TTS backend
   (eSpeak-NG, Piper, Azure/Google TTS, …). Keep the API, parameter ranges
   (`get*Range`), tag syntax (§5.3), voice/language descriptor files (§5.5) and
   event model; map `setVoice/loadPersona` to installed backend voices,
   `setAudio` to WAV/stream sinks, `getPhoneticTranscription` to the backend’s
   phonemiser, EQ/DRC/reverb to DSP.

**Phase 3 — packaging.** Recreate the Wise installer or (better) a modern
installer reproducing: file set from `payload/`, install layout of §3
(`bin\` with `regsvr32` of `LTTS7SAPI5.dll`), registry keys
(`SOFTWARE\Loquendo\LTTS7\{Engine,default.session,LicenseCode}`), Start-menu
shortcuts and ARP entry, plus the SAPI5 registration for `TTSApp.exe`-style
usage. §2 fully documents the original format if byte-identical installers are
required.

**Acceptance criteria for equivalence**
1. `TTSDirector` GUI exposes the same commands/dialogs and speaks the text of a
   document with the same prosody controls; `.ltd` documents round-trip.
2. `read()` of a given text with given `TTSParams` yields a playable PCM stream
   with the same rate/coding/channels and the same tag semantics.
3. RMI contract: a stock client can `registerClient`, `GetVoicesAndComments`,
   `read`, `stop`, `getOutBuffer`, `saveVoiceConfiguration`,
   `getPhoneticTranscription`, `GetSpeechAtomTree`, EQ calls.
4. Voice/language descriptors (`.vde`/`.vcf`/`.lde`/`.lcf`) are parsed with the
   documented keys, and a new voice can be registered by dropping a folder under
   `voices\`.
5. SAPI5 engine registered (`regsvr32 \bin\LTTS7SAPI5.dll`) enumerates the
   voices as SAPI tokens (`SpEnumTokens(SPCAT_VOICES,"Name=…")`) and speaks.

---

## 9. Evidence, reproducibility and limits

* Extraction re-verified end-to-end: `.WISE` → `MSCF` (cbCabinet 33 480 386,
  1115 files, 1 folder) → 2792 MSZIP blocks, 0 failures → 91 462 710 bytes,
  gapless file index → 1115 files. Both tools (`extract_payload.py` and the
  generic `wise_unpack.py`) were re-run independently and produce **identical
  name/size sets** for the Director installer.
* Generality check: `wise_unpack.py` also unpacks the voice installers — e.g. the
  German distribution yields 15 files / 2 247 763 B (`German.lde4`, `German.lcf`,
  `German.lex`, `German.rex8`, `German.ycf`, `German.dbl5`,
  `German_Automotive.lex6`, `German_Cities.lex`, `LTTS7German.dll1`,
  `Loquendo_TTS_7_Installation_Manual.pdf4`, `Logo.ico`, …). The *Engine*
  distribution uses the MSI-style variant, so its cabinet only carries the SAPI5
  prerequisite (9 files; `sapi.dll`, `sapi.cpl`, `sapisvr.exe`, `speech.chm`,
  `sapicpl.hlp`).
* Ghidra headless decompilation of the loader (`decomp_director.txt`, 4489 lines)
  used to derive the container/decryption/CRC behaviour; CFR 0.152 was used for
  the Java jars (`src/`).
* Not recoverable from this archive: the acoustic engine internals
  (`loqtts.dll` isn't even present — it comes from the MSI-style *Engine*
  distribution whose payload is stored as an OLE/MSI database, not as the
  MSZIP cabinet used by the SDK/voice packages), the voice databases
  (`.bin`/`.sde` binary formats), and the exact Wise script destination strings
  (the script is stored in a Wise-proprietary encoded section; only its ASCII
  fragments — EULA, registry keys, regsvr32 lines — are readable).
* Marked as [inferred]: the `f2` field semantics (DOS date), the last u32 of the
  file record, the exact install tree (derived from launcher paths, `VoicePath`,
  and `INSTALLDIR\bin\…` strings in the script).

---

### Appendix A — key file contents (verbatim, for quick reference)

`Ludoviko.vde` (455 B):
```
; LTTSComponentVersion=7.1.0
; Voice descriptor file for Loquendo TTS
"BaseDescription"	=	"Esperanto robotic male voice"
"Library"		=	"LTTS7Ludoviko, Ludoviko"
"BaseSpeed"		=	"128"
"BasePitch"		=	"95"
"Algorithm"		=	"Sequens"
"Gender"		=	"Male"
"Age"			=	"40"
"MotherTongue"		=	"Esperanto"
"MotherTongueAliases"	=	"Esperanto,eo"
"DemoSentence"		=	"Mia nomo estas Ludoviko, mi estas lo robota vocxo d…"
```

`Ludoviko.vcf` (331 B):
```
; Voice Configurator File for Loquendo TTS
"Description"       = "Esperanto robotic male voice"
"BaseVoice"         = "Ludoviko"
"VoicePath"         = "voices/Ludoviko"
"VocalDBName[0]"    = "Ludoviko"
;"Pitch"            = ""
;"Speed"            = ""
;"Volume"           = ""
;"Timber"           = ""
"Built-in"          = "Yes"
```

`Esperanto.lde` (258 B):
```
; LTTSComponentVersion=7.3.0
; Language descriptor file for Loquendo TTS
"BaseDescription"	=	"Esperanto generic descriptor file"
"Library"		=	"LTTS7Esperanto, Esperanto"
"Language"		=	"Esperanto,eo"
"WinLangid"		=	"1536"
"DefaultVariant"  	= 	"yes"
```

### Appendix B — extracted artefact checksums

| Artifact | md5 |
|---|---|
| `LTTSDirector7.rar` | `9c551a2da0a71189d7168948c9d339d3` |
| `LOQUENDO TTS DIRECTOR 7.exe` | `f575b9198a334b3d74c8d624fc03ac79` |
| `cab_folder.bin` (uncompressed payload) | `6031c37e91c05e2fed553f125caea94f` |

---

# 10. Acoustic synthesis core — reverse-engineered specification

Everything below is derived from the extracted engine modules (all decompiled into
`decomp_loqtts.txt`, `decomp_db.txt`, `decomp_ludoviko.txt`, `decomp_codecmsx.txt`,
`decomp_codec210.txt`, `decomp_util.txt`) plus byte-level analysis of the voice
data (`.vde`, `.sde`, `.bin`, `.dbl`, `.rex`, `.lex`, `.lde`, `.lcf`, `.vcf`, `.ycf`).

## 10.1 Module map (from the Engine distribution, cab `cab05_9d8423`)

| Module | Role |
|---|---|
| `LoqTTS7.dll` (888,832 B) | engine core: C++ classes `CttsSession/Reader/Voice/Language/Style/Lexicon/Enum/Error` (232 exported methods), prosody, SSML, streaming, unit selection |
| `LTTS7DB.dll` (331,776 B) | DB layer `DBOpen/DBGetTable/DBGetNext/DBExecuteQuery/DBCreateTable/DBGetVersion/…` |
| `LTTS7Util.dll` (266,240 B) | 546 `ELQ*` exports: `ELQBinaryHeader*` (self-describing binary file headers), `ELQBin*` (buffered/smart-buffer file I/O), `ELQDB*` (lexicon DB access), `ELQXML*` (XML/SSML parser), `ELQAtm*` (text automata), `ELQNum*` (118 number/date/telephone normalisers), `ELQToken/ELQList/ELQBuffer/ELQMemory/ELQPlugin/ELQShared/ELQLog/ELQFile/ELQUrl/ELQRequest/ELQRxc/ELQText/ELQG` |
| `LTTS7CodecMsx.dll` (122,880 B) | voice-DB **decoder** (LPC/CELP, "Msx") |
| `LTTS7Codec210.dll` (204,800 B) | voice-DB **decoder** (LPC/CELP, "210") |
| `LTTS7Morphyzer.dll` (106,496 B) | morphological analysis |
| `LTTS7GPR.dll` (57,344 B) | grapheme-to-phoneme rules (reads its own rule files via `ELQfopen/ELQfread`) |
| `LTTS7LanguageGuesser.dll` (1,433,600 B) | language identification |
| `LTTS7XML.dll` | XML/SSML helper |
| `LTTS7jni.dll` (122,880 B) | 87 JNI exports `Java_loquendo_tts_engine_*` → `tts*` C API |
| `LTTS7SAPI4/5.dll`, `LTTS7.ocx` | SAPI4/SAPI5 engines (`CTTSEngine : ISpTTSEngine, ISpObjectWithToken`, ATL) and ActiveX control |
| `LTTS7AudioBoard/File/Asf/SAPI4.dll` | audio destinations (board, WAV/raw file, ASF, SAPI4) |
| `LTTS7<Voice>.dll` | **voice plugin**: `LTTS7Ludoviko.dll` 57 344 B, `LTTS7Spanish.dll` 196 608 B, `LTTS7German.dll` 1 566 208 B |
| `LTTS7<Language>.dll` | language module (e.g. `LTTS7Esperanto.dll` 73 728 B, `LTTS7German.dll`) |
| `Loqjapi.jar` (14,408 B) | Java↔JNI bindings (`loquendo.tts.engine.*`) |
| `TTSDiag.exe` | diagnostic tool |

## 10.2 Text → speech pipeline and the plugin procedure contract

`LoqTTS7.dll` loads modules with `ELQPlugin*` and resolves named procedures with
`ELQPluginGetProc(plugin, "<name>", &fn)`; failures are logged as
`Error loading <name> procedure from %s`:

```
resolved from the LANGUAGE module:
  FonNewLanguage, FonAllofonoLingua, FonAllofonoAnalisi, FonMetafonema, FonTrasParola,
  FonTrasConfini, FonIngloba, FonSetStile, Fonetica_, Fonetiche_, Fonema, CatVoiceVersion
resolved from the VOICE module (synthesis side):
  FonNewVoice, FonCommonIniChan, FonIniGlob, FonAllofonoVoce, FonAnalisi2Sintesi,
  FonGetSamples, FonOut, and the "Vid" variants FonVidAllofonoVoce, FonVidAnalisi2Sintesi,
  FonVidIngloba, FonVidAllofonoAnalisi, FonVidMetaFonema
resolved from the per-voice "SDE" module (unit database):
  GetVersion, CatVoiceVersion, CatSdeData   (log: "Error loading dbunita from %s",
                                             "%s voice version (%s) is not compatible …",
                                             "Missing version information in sde dynamic library")
```

So a re-implementation must provide, per language and per voice, a module exporting
these procedures (name-significant C linkage), where:

* `FonAnalisi2Sintesi` performs **unit selection + concatenation** ("Algorithm = Sequens"
  in the `.vde`), using the SDE unit inventory and the codec-decoded samples;
* `FonAllofono*` builds allophones from the phoneme string, `FonMetafonema` maps
  metaphonemes, `FonIngloba`/`FonTrasParola`/`FonTrasConfini` handle
  word/phrase/boundary level processing, `FonSetStile` selects style, `FonGetSamples`
  yields PCM/float samples, `FonOut` writes the output stream;
* `CatSdeData` loads the **dbunita** (unit DB) — implemented by the voice's SDE module.

`LTTS7Ludoviko.dll` shows the concrete plugin dispatch shape: it exports a single
symbol `Ludoviko` and a 4-entry name→function table:

| name | address |
|---|---|
| `GetVersion` | 0x10001150 |
| `ELQGetPhonemes` | 0x10001060 |
| `ELQVoiceChannelOpen` | 0x10001070 |
| `ELQVoiceChannelClose` | 0x10001100 |

(`ELQ<Voice>ChannelType` / `Fon<Voice>ChannelType` allocation objects appear in
`ELQmalloc`/`ELQLogWrite` diagnostics.)

## 10.3 Linguistic data formats (all verified byte-level)

* **`<Language>.dbl` — pronunciation lexicon = SQLite 3 database.**
  `CREATE TABLE 'lessico'(grafemica, fonetica, grammaticale, specgramm, gennum, tempomodo,
  abbreviazione, gradoaccentuale)` + `CREATE INDEX idx_lessico on lessico (grafemica)`.
  Row counts: Spanish-Es 5 469, Spanish-Am 5 464, German 4 712.
  Example row: `('ABM', 'a: b e: `E m', 'ACC', '', '', '', 'ABM', '')`
  (graphemes → SAMPA-like phoneme string, POS, gender/number, tense/mood, abbreviation flag,
  accent degree). Node encoding is not UTF-8 everywhere — read with `text_factory=bytes`.
  Exported: `engine_re/SpanishEs.csv`, `SpanishAm.csv`, `German.csv`.
* **`<Language>.rex` — text normalisation rules, plain text** (regex → replacement with LTD
  tags), e.g. German: `"(^|[^0-9\.,;:])([1-9][0-9]*)(\.)[ \t]+" = "\1 \{number=ordinalM \2 "`,
  plus Spanish contraction rules (`"([cdhlmnrstvzjCDHLMN…])([aeiou…])" = "\1 \2"`).
  UTF-8 BOM + CRLF, comments start with `;`.
* **`<Language>.lde` — language descriptor (text)**:
  `BaseDescription`, `Library` (`LTTS7German, German`), `Language` (`German,de,de-DE`),
  `WinLangid` (1031/1536), `LexicalDB` (`German.dbl`), `RegExp` (`German.rex`),
  `DefaultVariant`, `Le…`; `LTTSComponentVersion=7.3.1`.
* **`<Language>.lcf` — language configurator (text)**: `Description`, `BaseLanguage`,
  `LanguagePath` (`languages/German`), `SpecialLexicon[0]`, `Built-in`.
* **`<Voice>.vde` — voice descriptor (text)**: `BaseDescription`, `Library`
  (`LTTS7Ludoviko, Ludoviko`), `BaseSpeed` (128), `BasePitch` (95),
  **`Algorithm` = `Sequens`**, `Gender`, `Age`, `MotherTongue`, `MotherTongueAliases`,
  `DemoSentence`; `LTTSComponentVersion=7.1.0`.
* **`<Voice>.vcf` — voice configurator (text)**: `Description`, `BaseVoice`,
  `VoicePath` (`voices/Ludoviko`), `VocalDBName[0]`, optional `Pitch/Speed/Volume/Timber`,
  `Built-in`. The engine *writes* derived flavour files (`<voice>-<VOICEFLAVOURID>-<rate>-<coding>-<bitrate>.vcf`)
  containing `ForcedSampleRate`, `ForcedCoding`, `ForcedBitrate`.
* **`<Style>.ycf` — style configurator (text)**: `SampaSecondAccent`, `lexicon[0..n]`.
* **`<Voice>.lex` / `SI<Language>.lex` / `SMS<Language>.lex` — binary special lexicons**
  (word lists with companion data; e.g. `German_Automotive.lex`, `German_Cities.lex`,
  `SIGerman.lex` = abbreviation/expansion, `SMSGerman.lex` = SMS abbreviations).
* **`<Voice>.sde` — unit/segment index, ASCII with bit 7 set on every byte**
  (decode by `b & 0x7F`). Structure (verified, `engine_re/Ludoviko.sde.txt`, 10 062 lines):

  ```
  14,1
  VERSION=7
  N=3482,6953,6578              ; units, records, D-records
  U=<phoneme> [<flags>]         ; one unit definition (3482 of them, 3416 distinct,
                                ;   e.g. "U=Dg: #", "U=`E #", "U=a~ #")
  D=0,S,<start>,<end>,0         ; S-record  = left*/static part of the unit
  D=0,D,<start>,<end>,0         ; D-record  = the unit body (6577 D/S pairs total)
  ```
  Positions are in **decoded sample units** (max end 15 829 000 ≈ 989 s @16 kHz);
  `S` records of ~9 675 samples vs `D` records of ~15 319 samples are the per-unit
  static (context) and dynamic parts used by the concatenator.
* **`<Voice>.<rate>.<coding>.<bitrate>.<version>.bin` — codec bitstream** (§10.4);
  Ludoviko: `Ludoviko.16000.linear.256000.10.bin` = 5 069 459 B. The name describes the
  **decoded** format (16 000 Hz, linear PCM, 256 kbit/s, DB version 10), not the storage codec.

## 10.4 Voice-database codec (`LTTS7CodecMsx` / `LTTS7Codec210`)

### 10.4.1 Plugin ABI (identical in both codecs)

`LTTS7CodecMsx(name)` / `LTTS7Codec210(name)` dispatch a 7-entry name table
(Msx table @VA 0x10015230, 210 table @VA 0x1002D000):

| name | Msx | 210 |
|---|---|---|
| `GetVersion` | 0x100010e0 | 0x10001030 |
| `ELQOpenDecoder` | 0x10001c30 | 0x10001410 |
| `ELQCloseDecoder` | 0x10001b20 | 0x10001550 |
| `ELQGetDecodedFileSize` | 0x10001100 | 0x10001050 |
| `ELQGetDecoderDescription` | 0x10001000 | 0x10001000 |
| `ELQDecoderFileChanged` | 0x10001010 | 0x10001010 |
| `ELQDecode` | 0x10001b90 | 0x10001360 |

`ELQDecoderFileChanged(handle, dbId, filename)` binds the codec to a voice file
(`*(state+0x4C) = dbId`). All file access is `ELQBinGetSmartBuffer/ELQBinGetBuffer`
(LTTS7Util) — i.e. cached/mapped random access, never plain stdio.

### 10.4.2 DB header — 124 bytes (`0x7C`), **big-endian** 32-bit fields

The codec reads `0x7C` bytes at the DB offset through `ELQBinGetSmartBuffer(...,0x7C,...)`;
fields are decoded by `FUN_10001110` = `(p[0]<<24)|(p[1]<<16)|(p[2]<<8)|p[3]`
(header parser: `FUN_10001160`).

| off | meaning | notes |
|---|---|---|
| +0x0C | sample rate (Hz) | recognized values: 8000, 11000, 11025 (0x2B11), 16000, 22000, 22050 (0x5622), 32000, 44000, 44100 (0xAC44); mapped to a rate class 0/1/2 stored at state+0x11D0 |
| +0x10 | **bytes per frame** | stored as short at state+0x11D2; observed table of legal values 27, 29, 33, 35, 39, 43, 48, 52, 56, 60, 66, 70, 82, 86, 102, 106 → ≈10.8–42.4 kbit/s at 20 ms |
| +0x14 | header/extra size | added to the frame-stream base offset |
| +0x18 | byte flag | stored at state+0x11E8 |
| +0x1C | layout version | `<2` ⇒ legacy: fixed LPC/quantizer widths; `>=2` ⇒ extended: extra fields at +0x54…+0x74 are read |
| +0x20…+0x50 | per-parameter **bit counts** (up to 13 streams: LPC, pitch, gains, codebooks, …) | copied to decoder-state +4…+0x80 |
| +0x2C,+0x30,+0x34,+0x38,+0x3C,+0x40,+0x44,+0x48,+0x4C | **bits per code** of the matching streams | word counts derived by `log2(bits/width)` (`FUN_10001130` = floor log2) |
| +0x54…+0x74 | extended per-stream sizes (version ≥2 only) | |
| +0x7A | (byte) **XOR obfuscation key** | read into decoder state +0x47A |

Frame stream layout: frame *i* occupies
`dbOffset + state[0x78] + i * bytesPerFrame`, `bytesPerFrame = header(+0x10)`,
`state[0x78] = header(+0x20)`. Frame length in samples = `state[0x11D4]`
(used with `samplePos / frameLength` for random access).

### 10.4.3 Frame decode and synthesis

`FUN_10001830` (per-frame decode, driven by `ELQDecode` → `FUN_100018E0` loop):

1. **De-obfuscate**: `for i in 0..bytesPerFrame-1: payload[i] ^= key`, `key = state[0x47A]`.
2. **Unpack** parameters: `FUN_10002070` (reset) then
   `FUN_10002090(state, payload, bytesPerFrame)` — bit reader that fills the
   per-parameter arrays according to the header bit counts/widths.
3. **Synthesise**: `FUN_10001F90(decoderObject, state, out, arg)` calls the decoder
   object's method at vtable `+0x1C`, producing a **float** frame buffer
   (`float afStack_a3c[654]`), then converts to int16 with saturation:
   `if x > +K → 0x7FFF; if x < −K → 0x8000; else short(round(x + C))`
   (constants `_DAT_10015300/08/10`), i.e. **float internal precision, 16-bit linear PCM out**
   — matching the "linear" in the file name.
4. The decoder object (created by `FUN_10001E70/FUN_100021A0`, methods at vtable
   `+0x14/+0x18/+0x1C/+0x20`) is the actual LPC/CELP synth: it complains
   `"No pitch prediction, what's wrong"` and `"?No fixed codebook"` when the DB lacks
   the pitch (adaptive codebook) or fixed-codebook streams, and validates the filter
   orders: `"La dimensione del filtro lpc (%d) non …"`, `"La dimensione del filtro lpc wide (%d) non …"`
   → the codec is a **CELP/RELP vocoder** with an LPC synthesis filter (a short "lpc" and a
   "wide"/long-term or wideband filter), **pitch prediction** (adaptive codebook) and a
   **fixed codebook**, per-frame gains, and per-parameter bit allocation driven by the header.

### 10.4.4 Random access (this is what unit selection needs)

`FUN_100018E0(state, outPtr, outLenPtr, handle)`:
`frame = *pos / state[0x11D4]`; if `frame == state[0x11E0]+1` seek forward, if
`frame != state[0x11E4]` decode all frames up to it, then `memcpy` the requested
samples from the 2-frame cache at `state[0x11D8]` (current) / `state[0x11DC]`
(previous) and advance. Silence is emitted (`_memset(buf,0,frameLen*2)`) when a frame
is absent. ⇒ the voice DB is a **frame-indexed, randomly addressable CELP stream**,
which is how `FonAnalisi2Sintesi` concatenates arbitrary units from the `.sde` ranges.

### 10.4.5 Empirical geometry of the available voice (Ludoviko)

* file 5 069 459 B; `.sde` max end 15 829 000 decoded samples (≈989 s @16 kHz);
* divisibility search over `(headerSize, bytesPerFrame)` with frame lengths 160/240/320/480
  gives the consistent solutions
  `header = 59, bytesPerFrame = 102, 49 700 frames × 320 samples = 15 904 000` (+0.47 % vs SDE)
  and `header = 5, bytesPerFrame = 103, 49 218 frames × 320 = 15 749 760`;
* ⇒ **20 ms frames (320 samples @16 kHz), ≈102 bytes/frame (≈40.8 kbit/s)** for the
  Ludoviko DB version 10. (Header offsets inside the file are consistent with the codec's
  `dbOffset + state[0x78]` formula; `state[0x78]` is taken from the DB header itself.)

## 10.5 Reusable extracts produced for the re-implementation

| file | content |
|---|---|
| `engine_re/codecmsx_rdata.bin` / `codecmsx_data.bin` | Msx read-only data (VA 0x10015000) and data (VA 0x10019000) — quantizer/codebook tables (`DAT_10019510`, `DAT_1001B080`, `DAT_1001A73C`, `DAT_1001AC28`, `DAT_100192AC/A8`, `DAT_1001B040/68/3C/64`, …) |
| `engine_re/codec210_rdata.bin` / `codec210_data.bin` | same for the "210" codec (VA 0x10021000 / VA 0x1002D000 — the dispatch table lives at the start of `.data`) |
| `engine_re/Ludoviko.sde.txt` | decoded unit index (10 062 lines: `VERSION=7`, `N=3482,6953,6578`, 3482 `U=`, 6577 `D=`) |
| `engine_re/SpanishEs.csv`, `SpanishAm.csv`, `German.csv` | full pronunciation lexicons (SQLite → CSV) |
| `engine_re/vox.bin` | the Ludoviko codec bitstream (5 069 459 B) |
| `decomp_codecmsx.txt` / `decomp_codec210.txt` | decompiled codec DLLs (header parser `FUN_10001160`, unpack `FUN_10002070/90`, frame decode `FUN_10001830/E0`, float→int16 `FUN_10001F90`, DSP `FUN_100030C0…FUN_10005AB0`) |
| `decomp_loqtts.txt` | engine core: plugin resolution (~lines 32037, 79317), `Ctts*` classes, SSML, prosody |
| `decomp_util.txt` | `ELQBinaryHeader*`, `ELQBin*`, `ELQDB*`, `ELQXML*`, `ELQAtm*` implementations |
| `decomp_ludoviko.txt` | voice plugin dispatch (`GetVersion`, `ELQGetPhonemes`, `ELQVoiceChannelOpen/Close`) |

## 10.6 What still has to be derived (and exactly how)

The remaining unknowns are *localised*, not open-ended:

1. **Per-CELP-parameter bit widths and packing order** — read
   `FUN_10002090`/`FUN_10002070` in `decomp_codecmsx.txt` (bit reader) together with the
   header fields at +0x20…+0x50 and the widths at +0x2C…+0x4C; each stream is a
   contiguous bit-slice of the 102-byte frame.
2. **Quantizer/codebook tables** — already extracted verbatim in
   `codecmsx_data.bin` (VA 0x10019000 base; the arrays referenced as `DAT_10019510`,
   `DAT_1001B080`, `DAT_1001A73C`, `DAT_1001AC28`, … are at `VA − 0x10019000` in that file).
3. **LPC order / sub-frame partitioning per bitrate** — the switch on the bytes-per-frame
   value in `FUN_10001160` sets the orders (10 or 8) and 5-sample sub-frames for the
   high-rate modes; the "lpc"/"lpc wide" filter sizes come from the same fields.
4. **Float→int16 constants** — `_DAT_10015300`, `_DAT_10015308`, `_DAT_10015310`
   (in `codecmsx_rdata.bin`) hold the scale/clip constants.
5. **Which codec a voice uses** — resolve `dbunita`'s codec through the SDE plugin
   (`CatSdeData`) or by trying both decoders: the header's sample-rate/bytes-per-frame
   values must match the legal tables listed in §10.4.2.

**Acceptance test for a re-implementation of the acoustic core**: implement the codec
plugin (7 entry points) + header parser + bit unpack + CELP synth, then decode the
`.sde` ranges of a voice and compare: (a) decoded sample counts must equal
`end-start` of each `D`/`S` record; (b) a concatenation of e.g. `\demosentence` for
Ludoviko must produce the same number of PCM samples as the original engine and be
intelligible; (c) `ELQGetDecodedFileSize` must return the `.sde` maximum end.

## 10.7 Voice-data observations and the one remaining mapping question

Checks performed after §10.6 was written:

* `Ludoviko.16000.linear.256000.10.bin` (5 069 459 B): the last 64 bytes are
  `f4 ff f3 ff f6 ff f7 ff … 00 00`, i.e. **int16 little-endian near-silence**, and the
  byte histogram peaks symmetrically at `00/FF/01/FE/…` — consistent with 16-bit
  **linear PCM** (as the file name states: 16 000 Hz, linear, 256 kbit/s). No ELQ binary
  header keys (`Coding`, `BitRate`, `Endian`, `DataDescriptor`, …) and no big/little-endian
  sample-rate constant (8000/11025/16000/22050/32000/44100) exists anywhere in the file,
  and no single-byte-XOR variant of the first 0x100 bytes yields the codec header either.
* `Ludoviko.sde` is **100 % the 0x80-biased text index** (186 290 B, 10 062 lines, last
  byte is the final newline) — no binary tail, no codec header inside it.
* `.sde` range limit is 15 829 000; the `.bin` holds 2 534 729 int16 samples ⇒ a factor
  6.245. Correlating unit boundaries with PCM energy at plausible scales (÷4, ÷8, ÷16,
  ÷32) shows **no** alignment (median RMS at boundaries ≈ random RMS ≈ 18 7xx for all
  divisors), so the positions are neither sample indices, bit offsets nor byte offsets
  into this PCM file at any of those scales.
* The language/voice installers in this RAR ship **language data only** — the English
  pack yields exactly: `English{Gb,Us}.dbl` (SQLite lexicons), `English{Gb,Us}.gpr`
  (**1 230 841 / 1 009 561 B** — the GPR rule data used by `LTTS7GPR.dll`),
  `English{Gb,Us}.rex` (regex normalisers), `English{Gb,Us}.lde/.lcf` (descriptors),
  `LTTS7English.dll` (282 624 B) — i.e. **no `.sde`/`.bin`**. The Spanish pack
  (`Spanish{Am,Ar,Cl,Es,Mx}.{dbl,lde,lcf}`, `Spanish.rex`, `LTTS7Spanish.dll`) is the same.
  The only acoustic pair in the whole RAR is therefore the SDK's
  `Ludoviko.sde` + `Ludoviko.16000.linear.256000.10.bin`.

Consequences for the re-implementation:

1. The **unit index** (`.sde`: `U=`/`D=`/`S=` records) and the **sample database** are the
   two halves of a voice; their binding is done at runtime by the voice/SDE plugin
   (`CatSdeData` → "dbunita", `FonGetSamples` → samples). The index positions use a
   granularity that is *not* the stored byte/sample domain of the shipped `.bin`
   (either a finer position unit — e.g. the codec's internal sub-frame/pitch-mark domain —
   or the `.bin` is a *packed* representation despite its "linear" name).
2. To settle it, the shortest path is **dynamic/greybox**, not more static reading:
   (a) implement the two codec plugins' `ELQOpenDecoder/ELQDecode` per §10.4 and feed them
   the `.sde`-derived offsets; (b) or run `LoqTTS7.dll` under a debugger/Wine with a
   breakpoint on `ELQBinGetBuffer`/`ELQBinGetSmartBuffer` while the engine synthesises
   `\demosentence` for Ludoviko — the first calls reveal exactly which file/offset/size the
   codec is bound to and how `.sde` positions are converted to it.
3. Everything else needed to rebuild the acoustic core is specified: the plugin ABIs
   (§10.2, §10.4.1), the codec header/frame layout and de-obfuscation (§10.4.2/3), the
   random-access contract (§10.4.4), the CELP algorithm class with the exact functions and
   tables to port (§10.4.3, §10.5), the linguistic stack (`Fon*` procedures, SQLite
   lexicons, `.rex`, `.gpr`), and the prosody inputs (`BasePitch`, `BaseSpeed`,
   `Algorithm=Sequens`).

## 10.8 Where the codec's tables actually live (porting note)

Section layout of the shipped codecs (raw sizes matter):

| module | .text | .rdata | .data | other |
|---|---|---|---|---|
| `LTTS7CodecMsx.dll` | VA 0x10001000 / 0x14000 | VA 0x10015000 / **0x4000** | VA 0x10019000 vsize 0x31BC / **raw 0x2000** | .rsrc @0x1001D000, .reloc @0x1001E000 |
| `LTTS7Codec210.dll` | VA 0x10001000 / 0x20000 | VA 0x10021000 / **0xC000** | VA 0x1002D000 vsize 0x321C / **raw 0x2000** | .rsrc @0x10031000, .reloc @0x10032000 |

* Tables inside `.rdata` and inside the **raw** part of `.data`
  (VA 0x10019000–0x1001B000 for Msx, 0x1002D000–0x1002F000 for 210) are stored in the
  binaries and are provided ready to use in `codecmsx_rdata.bin`, `codecmsx_data.bin`
  (and the 210 equivalents), addressed by `VA − sectionVA`.
* Tables above the raw `.data` end (Msx: 0x1001B000–0x1001C1BC, e.g. `DAT_1001B038`,
  `DAT_1001B064`, `DAT_1001B080`, `DAT_1001C1A0…`) are **zero-initialised BSS filled at
  load time** ⇒ a re-implementation must port the *generating code* (the codec's
  initialisation functions, which build the quantiser/gain/codebook tables from the
  constants in `.rdata`), not copy those bytes.
* Same distinction applies to the float→int16 constants `_DAT_10015300/08/10`, which are
  stored in `.rdata` and are present in `codecmsx_rdata.bin` (offsets
  0x300/0x308/0x310 from VA 0x10015000).

---

# 11. Binary-free re-implementation: what is possible, and what is provably missing

## 11.1 Proof that the voice's acoustic module is not in this RAR

* `CatSdeData`, `CatVoiceVersion`, `GetSdeData` (the "dbunita" = unit-database plugin
  procedures) are referenced **only inside `LoqTTS7.dll`** (as `ELQPluginGetProc` names and
  in the log strings `Error loading dbunita from %s`,
  `Error loading GetSdeData procedure from %s`). A corpus-wide string/export/dispatch-table
  search over all 1 265 extracted binaries finds **no module that provides them**.
* The voice modules that *are* present implement a different slot set:
  * `LTTS7Ludoviko.dll` (voice, 57 344 B): `GetVersion`, `ELQGetPhonemes`,
    `ELQVoiceChannelOpen`, `ELQVoiceChannelClose` (dispatch table @VA 0x100086B0).
  * `LTTS7Esperanto.dll` / `LTTS7Spanish.dll` / `LTTS7German.dll` (language):
    `GetVersion`, `ELQGetGraphemes`, `ELQGetPhonemes`, `ELQGetLicenseMessage`,
    `Les*` (lexicon/morphology: `LesGetSymbolName`, `LesGetMorphTable`,
    `LesGetOrdinalStringTable`, `LesGetAbbreviazioni`, `LesGetNumeroAbbreviazioni`,
    `LesGetDefaultCurrency`, `LesWriteCateg`), `FonTrasParola`, `FonTrasConfini`,
    `FonAllofonoLingua`, `FonGetSamples`, `ELQLanguageChannelOpen/Close`,
    `ELQLanguageLoadReadOnlyData/UnloadReadOnlyData`.
  * Voice DLLs do **not** read files (their only imports are
    `ELQmalloc/ELQfree/ELQLogWrite/ELQSharedResource*`), so the sample-database I/O and the
    `.sde`→sample mapping live in the missing dbunita module.
* No file in the archive contains a voice-DB **codec header**: a full-corpus scan for the
  big-endian/little-endian header layout of §10.4.2 (legal sample rate at `+0x0C` followed by
  a legal bytes-per-frame at `+0x10`) over all 1 179 payload/engine files finds only two
  coincidences inside unrelated DLLs (`jaas_nt.dll`, `LTTS7jni.dll`) — none in any voice data
  file. The shipped `Ludoviko.16000.linear.256000.10.bin` contains no such header at any
  offset, in either endianness, and no legal sample-rate constant at all.
* ⇒ The acoustic model of the shipped voice (`dbunita` data + the code that consumes
  `Ludoviko.sde`) **is not part of `LTTSDirector7.rar`**. The `.sde` (text index) and the
  `.bin` are present, but their reader/authority is not, which is why no static mapping
  between `.sde` positions and `.bin` offsets can be derived from this archive alone
  (empirical tests in §10.7 agree).

## 11.2 What another agent *can* build today, with no Loquendo binary

A **functionally complete, binary-free TTS Director** is fully specified by this report:

1. **Application layer** — rebuild (or recompile from `src/`) the six jars: Director GUI,
   Manager, Engine client/server (RMI), Lexicon Manager, look&feel, utilities. Behavioural
   spec: §4 (interface), §4.2 (`read()` pipeline), §6 (GUI, menus, file formats, `.ltd`),
   §3 (launchers, install layout), §7 (policy files).
2. **Engine implementation** — implement the documented interfaces:
   * C API `tts_*` (`loqtts.h`, §5.2) and Java API `loquendo.tts.engine.*` (§5.1) with the
     same semantics, parameter ranges and event model; the JNI names to export are the 87
     `Java_loquendo_tts_engine_*` in `LTTS7jni.dll`.
   * Plugin interface struct used by the engine — procedures are resolved by
     `ELQPluginGetProc(plugin, "<name>", &slot)` and stored per module:
     `FonTrasConfini → +0x1C`, `FonGetSamples → +0x20`, `FonSetStile → +0x24`,
     `FonAllofonoLingua → +0x28`, plus `FonNewVoice`, `FonVidAllofonoVoce`,
     `FonVidIngloba`, `FonVidAllofonoAnalisi`, `FonVidMetaFonema`,
     `FonVidAnalisi2Sintesi`/`FonAnalisi2Sintesi`, `FonAllofonoAnalisi`,
     `FonTrasParola`, `FonIngloba`, `FonCommonIniChan`, `FonIniGlob`,
     `FonAllofonoVoce`, `FonOut`, and (dbunita module) `GetVersion`, `CatVoiceVersion`,
     `CatSdeData`, `GetSdeData`. A replacement module must export the *same names*
     (the engine looks them up by string) and fill the same slots.
   * Codec plugin ABI (7 entry points, §10.4.1) for whatever internal DB format the
     replacement engine uses.
   * **Substitute synthesis core**: rather than CELP with a missing DB, implement the
     allophone/unit layer with any backend (e.g., concatenate the shipped linear data if a
     DB is provided, or a formant/HMM/neural TTS), keeping the observable contract:
     sample rates/codings from `GetFrequencies`/`GetCodings`, per-voice `BasePitch`/
     `BaseSpeed`, LTD tags, prosody ranges, events, `saveCF`, EQ/DRC/mixer.
3. **Linguistic layer** — the data formats are known and reusable as-is:
   SQLite `.dbl` lexicons (§10.3, CSVs in `engine_re/`), regex `.rex`, `.lde/.lcf/.vde/.vcf/.ycf`
   descriptors, the `.sde` text unit index, and the `.gpr` rule data (needs its own format
   reverse, see §11.3). Unknown words then need a G2P implementation (rules, or a modern
   phonemiser mapped into the recovered SAMPA-like phoneme set, cf. `ttsGetPhonemeInfo`,
   `TTSLanguage.getPhonemeMap`, `ELQGetPhonemes`).
4. **Formats/behaviour to preserve for compatibility**: `.ltd` header keys, `.txt/.ssml`
   handling, `saveAudio` WAV/ASF, `\demosentence`, voice flavours → derived `.vcf`, RMI
   contract, registry keys and `LicenseCode`.

**Acceptance criteria for the binary-free build**
1. The Director GUI exposes the same commands/dialogs and speaks the text of any document
   with the same prosody controls; `.ltd` round-trips; WAV/ASF export works.
2. A stock client can `registerClient`, enumerate voices/languages, `read`, `stop`,
   `getOutBuffer`, `saveVoiceConfiguration`, `getPhoneticTranscription`,
   `GetSpeechAtomTree`, EQ calls — i.e. the RMI contract of §4.1 is honoured.
3. SAPI5 integration enumerates voices as SAPI tokens and speaks.
4. Lexicon editor round-trips `.dbl` (SQLite) lexicons; `.rex` normalisation and the
   `.lde`-driven language selection behave as specified.
5. Any module written for the plugin interfaces above can be dropped in and is picked up by
   `ELQPluginGetProc` naming (i.e. the plugin contract is honoured, not bypassed).

## 11.3 Remaining work for a *voice-identical* binary-free port

Two items, both bounded:

1. **Obtain (or capture) the dbunita module/DB.** Options: use a voice package that ships it
   (the packs in this RAR ship language data only — proven in §11.1), or run the original
   engine once under a debugger/Wine with a breakpoint on the dbunita `CatSdeData` and on
   `ELQBinGetBuffer`/`ELQBinGetSmartBuffer` while speaking `\demosentence`; the call log
   yields the DB file, its offset/size window and the exact `.sde`→frame mapping.
2. **Port the CELP/LPC decoder** from the already-decompiled codec sources
   (`decomp_codecmsx.txt`, `decomp_codec210.txt`): header parser (`FUN_10001160`),
   bit unpack (`FUN_10002070/90`), frame decode (`FUN_10001830/E0`), float→int16
   (`FUN_10001F90`), synth DSP (`FUN_100030C0`…`FUN_10005AB0`), with the tables from
   `codecmsx_rdata.bin`/`codecmsx_data.bin` and the runtime-built (BSS) tables ported from
   their generators (§10.8). Same for the `.gpr` G2P rule format if rule-based OOV
   pronunciation is required.

Neither item blocks the functional re-implementation in §11.2; both are required only for
bit-identical voice output of the original voices.

---

# 12. Authoritative description of the synthesis algorithm (vendor documentation)

The archive ships the vendor guides (`guides/ug/*` = Users Guide, `guides/pg/*` = Programmer's
Guide, `Loquendo_TTS_7_Java_Programmers_Guide.chm`; extractable with
`tools/7zz x -o<dir> <chm> -y`). The Users Guide states the algorithm verbatim:

> "The written text is first transcribed into a sequence of phonetic symbols, according to
> the grammar, the lexicon and the phonetic rules of the **Language**. Then, the phoneme
> sequences are mapped onto the **Vocal Database** of the **Voice**, which consists of a
> large collection of utterances recorded by a professional speaker and carefully labeled
> with phonetic and prosodic tags. The best matching speech fragments are extracted from the
> Vocal Database and concatenated to form the desired output speech. The fragments are chosen
> taking into account their intonation and their context."

and lists the processing chain:

1. split the character sequence into words and sentences (blanks, punctuation);
2. interpret/expand numbers, abbreviations, symbols and acronyms via tables and rules;
3. assign grammatical tags to words and resolve ambiguities from context;
4. assign pauses and intonation from punctuation and a minimal syntactic parse;
5. assign lexical stress and phonetic transcription per word (rules or lexicon);
6. transcribe the phrase in phonemes and assign prosodic labels;
7. **search the Vocal Database for the longest phoneme sequences** matching the
   transcription, taking context into account;
8. concatenate the corresponding signal fragments and apply signal processing for
   **concatenation smoothing and slight prosodic variations**.

This is the vendor's own confirmation of the decomposition derived in §10.2 — the engine is a
**unit-selection (concatenative) synthesizer** over a labeled speech database:

| Doc step | Recovered component |
|---|---|
| 1–2 | `FonTrasParola` / `FonTrasConfini`, `ELQToken*`, `ELQNum*` (118 number/date/telephone normalisers), `.rex` regex rules |
| 3 | `LTTS7Morphyzer.dll`, `LesGetMorphTable`/`LesGetSymbolName`, SQLite `.dbl` lexicon |
| 4, 6 | prosody/pause rules; `LTTS7GPR.dll` + `.gpr` data; `FonMetafonema` (metaphoneme mapping), SAMPA/SAMPA-2 phoneme alphabet |
| 5 | `.dbl` lexicon (`fonetica` column) + GPR rules for OOV |
| 7 | `FonAnalisi2Sintesi` (unit selection over `dbunita` = the `.sde` index), `ttsLocateSpeechAtomInventory`/`GetSpeechAtomTree` (speech atoms), `GetGilded` |
| 8 | `FonAllofono*`, `FonGetSamples`, `FonOut`; the codec decodes DB frames; per-frame smoothing/prosody |

Additional semantics confirmed by the Programmer's Guide: `BaseSpeed` is in **words/minute**,
`BasePitch` is in **hertz** (`Ludoviko.vde` ⇒ 95 Hz, `BaseSpeed=128`), `WinLangid` is the
Windows language id, SAMPA is the phonetic alphabet (`SampaSecondAccent` style flags in
`.ycf`), and the say-as family (generic/telephone/currency/code/hour/date/amount/
MasculineOrdinal/FeminineOrdinal) matches the Director's *Say As* menu; SAPI 5.1 XML
peculiarities (case-insensitive tags, `&amp;` escaping) are documented too.

**Consequence for re-implementation:** steps 1–6 are rebuildable from this archive (rules,
lexicon, descriptors, formats — §§10.3, 11.2). Step 7/8 are the acoustic core: they require a
labeled speech database. Because the shipped voice's database *authority* (the dbunita
module) is absent (§11.1), a binary-free port implements steps 7–8 over a **substitute**
database — either the shipped linear sample data if its layout is established by the runtime
trace of §11.3, or a new unit database built for the replacement engine, with the same
observable behaviour (longest-match selection, context-sensitive choice, concatenation
smoothing, slight prosodic variation).

---

# 13. SOLVED: the vocal-database (.bin) container and unit inventory (.sde) formats

The voice package `/run/media/.../Jorge - Spanish.exe` (Inno Setup 5.2.3, unpacked with the
freshly built `tools/innoextract-1.9/build/innoextract`) ships the *complete* runtime for one
Spanish voice: engine (`LoqTTS7.dll` 746 KiB, `LTTS7Util.dll` 551 KiB, codecs, all language
modules), the voice module `LTTS7Jorge.dll`, descriptors (`Jorge.vcf/.vde`, `JorgeGilded.gde`)
and the data: `Jorge.sde` (1 511 129 B), `Jorge.32000.LTTS7Codec210.44000.10.bin`
(29 144 430 B) plus two Gilded databases. Both data formats are now fully decoded.

## 13.1 `.bin` = `LOQUENDOTTS7` binary container (verified on 4 files)

```
offset  size   content
0       1      keyA                    (stored plain)
1       1      keyB                    (stored plain)
--- all following header bytes are XORed with  k = keyA ^ keyB -------------------
2       12     "LOQUENDOTTS7"           (signature)
14      2      u16 LE format version    (= 1)
16      2      u16 LE header_size
18      ...    TLV list up to header_size:
                 u16 LE tag, u16 LE size, size bytes (values are NUL-terminated ASCII)
                 tag 1 Name, 2 Label, 3 Comment, 4 Freq, 5 Coding, 6 BitRate, 7 Rank, 8 Version
-- from header_size on, the sub-header is plain, but the FRAMES are XOR-obfuscated ------------
   (corrected in S13.6: each 110-byte frame is byte-XORed with the key = sub-header byte 27)
hdr+0   28     7 x BE u32 sub-header:
                 [0] BitRate (bit/s)        [1] Rank
                 [2] samples per frame      [3] Freq (Hz)
                 [4] bytes per frame        [5] frame count
                 [6] (cookie/id)
hdr+28  n      frame_count * bytes_per_frame bytes of coded frames
```
Verified exactly (file size = header_size + 28 + frame_count * bytes_per_frame):

| file | key | hdr | Freq | Coding | BitRate | Rank | samples/fr | B/fr | frames | size |
|---|---|---|---|---|---|---|---|---|---|---|
| `Jorge.32000.LTTS7Codec210.44000.10.bin` | 0x02 | 122 | 32000 | LTTS7Codec210 | 44000 | 10 | 640 | 110 | 264 948 | 29 144 430 |
| `JorgeGildedPhrases...` | 0x7C | 148 | 32000 | LTTS7Codec210 | 44000 | 10 | 640 | 110 | 8 889 | 977 966 |
| `JorgeGildedParalinguistics...` | 0xE2 | 164 | 32000 | LTTS7Codec210 | 44000 | 10 | 640 | 110 | 9 958 | 1 095 572 |
| `vox.bin` (SDK Ludoviko voice, v7.3.0) | 0x39 | 125 | 16000 | linear | 256000 | 10 | – | – | – | 5 069 459 |

Sub-header check for Jorge: 122 + 28 + 264 948x110 = 122 + 28 + 29 144 280 = 29 144 430 ✔
(each coded frame is 20 ms of 32 kHz speech at 44 kbit/s; `640 samples/frame` is consistent
with `110 B/frame x 8 / 0.02 s = 44 000 bit/s`.)

Reproduction (no Loquendo code needed):
```python
d = open(path,'rb').read(); k = d[0]^d[1]
h = bytes(b^k for b in d[:256])
assert h[2:14] == b'LOQUENDOTTS7'
fmt, hdr_size = struct.unpack_from('<HH', h, 14)
# TLV from 0x12 to hdr_size, then 7 BE u32 at hdr_size, frames from hdr_size+28
```
This also retro-explains the earlier "0x7C header" hypothesis for the SDK voice: that number
came from the *per-file key byte* of `JorgeGildedPhrases` (0x7C), not from a header length.

## 13.2 `.sde` = unit inventory (bit-7-masked descriptor text)

`Jorge.sde` is plain text with bit 7 set on every character (newlines stay 0x0A):
`bytes(b & 0x7f)` yields 153 223 lines:

```
10,4
LTTSComponentVersion=7.0.0
N=3647,82007
U=# # @ @
L# !'E #-% "
R# #>E "
...
```
i.e. a component header (`<a>,<b>`, version), a unit count `N=<units>,<total>`, then per-unit
records `U=...` with left/right context records `L<n>/R<n>` whose numeric fields are written in
a printable alphabet. The reader lives in the engine/Util descriptor layer
(`ELQDataDescriptor*` / `ELQTagsDescriptor*`); details are being extracted in
`specs/SDE.md` (field-by-field decoding, cross-checked against the 264 948-frame geometry).

## 13.3 What this changes for the binary-free reimplementation

* The acoustic data of the shipped voice is **fully accessible without any Loquendo binary**:
  header rules, frame geometry, frame count and bit rate are all in the file, and the frames are
  stored unobfuscated (only the 122/148/164-byte header is XORed with a two-byte key).
* A reimplementation therefore needs: (1) a container reader (§13.1), (2) a `.sde` parser
  (§13.2), (3) the Codec210 decoder (§ specs/Codec210.md), (4) unit selection + concatenation,
  which is the engine/voice-module logic documented in §10 and specs/EngineBinding.md.
* The missing `dbunita`/`SdeDllMain` plugin (§11.1) is **not** needed: it is only used for
  "linked SDE" voices, selected by a `LinkedSde[...]= y` descriptor tag which the Jorge voice
  does not have; without it the engine reads `.sde`/`.bin` itself through `ELQSharedResource*`
  and the `ELQBin*` layer of `LTTS7Util.dll`.

## 13.4 Verified time base: 1 position unit = 10 microseconds

`JorgeGildedParalinguistics.sde` uses a second record type, `P=<name>|<start>|<end>`, with pipe-separated
fields. The 147 segments (`Aa, Aa_01..Aa_04, Ah, ..., Yawn_01..Yawn_04` - exactly the paralinguistic
"Extras" names of `JorgeGilded.gde`) are **contiguous** (`end[i] == start[i+1]`, zero gaps) and span
`0 .. 19 915 859`. The database holds 9 958 frames; `9 958 x 2000 = 19 916 000`. Hence:

```
1 frame = 2000 position units = 110 coded bytes = 640 samples = 20 ms   (32 kHz, 44 kbit/s)
1 position unit = 10 microseconds
```

converted back: `19 915 859 x 110 / 2000 = 1 095 372` bytes versus `1 095 572 - 164 (header) - 28
(sub-header) = 1 095 380` data bytes (the 8-byte difference is per-segment rounding at frame
granularity). This gives a *hard* consistency anchor for decoding the numeric fields of the main
`Jorge.sde` (positions there must lie below `264 948 x 2000 = 529 896 000`) and of
`JorgeGildedPhrases.sde` (below `8 889 x 2000 = 17 778 000`).

Record invariants extracted from the bit-7-cleared text (useful as parser self-checks):

| file | `N=` | `U=` records | L0..L9 / R0..R9 records | other |
|---|---|---|---|---|
| `Jorge.sde` | `3647,82007` | 3647 | 2584,2482,2379,2284,2160,2052,1911,1795,1676,1523 (each side) | 153 223 lines |
| `JorgeGildedPhrases.sde` | `261,2960` | 261 | 44,34,26,20,17,13,10,8,7,7 (each side) | 5 401 lines |
| `JorgeGildedParalinguistics.sde` | - | - | - | 147 `P=` cues |

## 13.5 `.sde` semantics (verified) and how units map to the database

`specs/SDE.md` + `tools/sde_parse.py` (agent "SdeFormat") decode the inventory from the decompiled
readers (`LoqTTS7.dll`) with every rule tied to a code address. Verified here independently:

* `N=3647,82007` = number of speech atoms / total `U=` tokens - re-counted exactly (3 647 atoms,
  82 007 tokens, 149 426 `L`/`R` records, 146 `S=`).
* `U=` line grammar: `<left-context> <p1..pK> <right-context>`; tokens are matched against the voice's
  phonetic table (`TabelleFonetiche` resource), `-` joins two phonemes into one token.
* `L<n>`/`R<n>` lines carry the atom's timeline in **base-93 printable numerals**
  (`while (c > 0x21) v = v*0x5d + (c-0x22)`, alphabet `"`=0 … `a`=63, `-` = digit 11 in this context);
  grammar `L<n> [!start] <dur> <val>`; slot `n` = 1-based phoneme inside the atom, `L` = left half
  (slot 2n), `R` = right half (slot 2n+1); only the first `L` of an atom carries an explicit `start`,
  later lines inherit the running end.
* Times are in the verified 10 us unit (S13.4). Max end = 529 894 060 vs `264 948 x 2000 = 529 896 000`
  (0.97 frame short) - the records tile the whole database in time order.
* **The atom times are NOT frame aligned**: `start % 2000` is uniformly distributed over 0..1999.
  So the engine must decode whole 110-byte records and splice at 10 us accuracy (the
  "concatenation smoothing and slight prosodic variations" of the vendor text, REPORT S12), rather
  than fetching whole frames per atom.
* `val` (10-bit field, observed 0..284, 207 distinct values) is per-half prosodic data shipped with the
  unit (pitch/period-like magnitude); `S=` sets a per-atom flag (Jorge: 146 x `I`; phrase DB: `e/i/f/x`).

**Consequence:** with §13.1 (container) + §13.5 (inventory) the only remaining unknown of the acoustic
path is the Codec210 frame decoder (`specs/Codec210.md`). Rendering then is: choose atoms by
phoneme+context match, decode the referenced 110-byte records to 640-sample frames, cut each half at
`start/2000` frames + `(start%2000)*0.32` samples, splice with smoothing.

## 13.6 CORRECTION: the coded frames are XOR-obfuscated (per-file key)

An earlier statement in this report ("the data region is not obfuscated") is correct **for the
container layer**: `ELQBin*` never transforms bytes (`specs/ELQBin.md` S4, proven at asm level), and
the 28-byte sub-header is stored in the clear. The *frame payload* after that sub-header is nevertheless
stored **XOR-obfuscated**, and it is the **codec** that un-XORs it (`LTTS7Codec210.dll`, jorge build):
`ELQDecode` (0x10004530) reads the sub-header with `ELQBinGetBuffer(bin, 122, 0x1c, 1, 0, &sub)` and then

```c
*(s16*)(decoder+0x11d0) = sub[19];   /* bytes_per_frame = 110 */
*(u8 *) (decoder+0x11e4) = sub[27];  /* XOR key = last byte of the cookie */
... per frame: for (i=0;i<110;i++) buf[i] ^= key;      /* FUN_10004290 */
```
and requests frame bytes as `ELQBinGetBuffer(bin, 110*frameIndex + 28 + header_size, 110, 1, …)`,
i.e. file offset `150 + 110*i` (matching the container layout of S13.1).

Independently re-verified here: de-obfuscating with `sub[27]` normalises the first byte of every frame
to the **same tag set `{0x38..0x3F}` in all three databases**, although their stored tags and keys differ:

| file | header key | sub[27] (frame key) | frame[0] as stored | frame[0] ^ key |
|---|---|---|---|---|
| `Jorge.32000.LTTS7Codec210.44000.10.bin` | 0x02 | 0x6D | 0x50..0x57 | 0x38..0x3F |
| `JorgeGildedPhrases…bin` | 0x7C | 0x15 | 0x28..0x2F | 0x38..0x3F |
| `JorgeGildedParalinguistics…bin` | 0xE2 | 0x91 | 0xA8..0xAF | 0x38..0x3F |

The most frequent payload bytes likewise converge (`0xc6/0xd7/0x92` -> `0xab/0xba` in file 1 and
`0xbe/0xaf` -> `0xab/0xba` in file 2). `tools/render_bin.py` de-obfuscates frames with this key
(`frame_plain()`); the frame tag set `0x38..0x3F` is a 3-bit mode field under a fixed 5-bit `00111`
marker, so the record-level bit layout starts at a fixed alignment.

Consequence for a reimplementation: frame bytes must be de-obfuscated before bit-unpacking; both keys
(header key `d[0]^d[1]` and frame key `sub[27]`) are readable from the file itself.

---

# 14. Engine ↔ voice binding, selection and the decoder contract (verified)

Full detail with code addresses: `specs/EngineBinding.md` (1 314 lines), `specs/SDE.md`,
`specs/ELQBin.md`. Summary of what a reimplementation must reproduce:

## 14.1 Descriptors and where the data files are found

* Descriptor family by type: `0 .rcf`, `1 .vcf`, `2 .lcf`, `3 .ycf`. A voice descriptor (`.vde`,
  named through the `.vcf` `BaseVoice` key, with `gdeInclude` -> `.gde`) registers up to 16 vocal
  databases.
* For each `VocalDBName[i]` the engine builds a `ELQBinaryHeaderLoadInfo(name, dir, log)` object
  (stored as `__BinInfo__[i]`): it **globs `*.bin` in the voice directory**
  (`LTTS7Util.dll FUN_10001fd0`: `ELQFileSearchIni(this,"*.bin")`) and matches the file's TLV tag
  `Label` case-insensitively against the name (`ELQstricmp(...,"Label")`). *Verified in
  `jorge_re/decomp_util_jorge.txt` at the cited lines.*
* The **variant** is chosen from the header tags `Freq`/`Coding`/`BitRate`/`Rank` compared with the
  `.vcf` keys `SetSampleRate`/`SetCoding`/`SetBitRate` (and the `Forced*` forms); with no match the
  coding name is forced to `built_in`.
* The **inventory** is a separate file: the engine appends the literal **`".sde"`** to
  `VocalDBPath[i]`/`VoicePath` (+`DataPath`) and registers it as a shared resource
  (`ELQSharedResourceAdd`, descriptor attribute `Id`). So `.sde` and `.bin` are opened by the engine
  itself; the optional `LinkedSde[...]` path (a `SdeDllMain` plugin) is not used by this voice.
* The engine's `.sde` reader handles **both generations with no version branch**: pass 1 reacts to
  `N`/`U`/`P`, pass 2 dispatches on tag characters `{A,D,L,R,F,S,U,P}`; `VERSION=` has no case and is
  skipped. Generation 1 (`LTTSComponentVersion=7.0.0`: `L<n>`/`R<n>` base-93 records, `S=`, `P=`) and
  the legacy generation (`VERSION=7`: `D=<order>,<S|D>,<start>,<end>,<pitch>` plain decimal) share
  the 10 us time unit and the same 8-byte half-slot pair `(start, (dur<<10)|pitch)`.

## 14.2 Per-unit synthesis path

* Per unit: `FUN_1001faa0` (driver) -> `FUN_1001ddd0` (reads the unit's `.bin` sub-header) ->
  `FUN_1001f580` (decoder request) -> `FUN_1001e3a0` (pitch-mark/PSOLA placement).
* Decoder ABI (codec plugin vtable `*(engine_sig + 0x1c)`):

```
int decode(openHandle, int startSample, int sampleCount, short *out, ELQBin binHandle);
```
  No frame index and no byte offset cross the boundary: the codec converts samples to frames/bytes
  itself (`frameIndex = samplePos / 640`, bytes at `150 + 110*frameIndex`, page 13.6) and un-XORs
  each frame with the sub-header key.
* Position conversion: `sample = pos * Fs / 100000` (10 us units), pre-roll/post-roll margin
  `Fs/500` samples (x4 for coding 2/4).
* Pitch and duration changes are **TD-PSOLA on the decoded signal** (marks placed from the recorded
  pitch marks, or uniformly at `Fs/125`, or at `Fs/pitchRatio`), never a resample.
* Voice module: single export (`Jorge` @ RVA 0x1170) dispatching an 8-entry `{name;proc}` table;
  `FonVidAllofonoVoce` is a no-op stub; `ELQVoiceChannelOpen/Close` provide the channel.
* Codec plugin: export @ RVA 0x4760 with an 8-name table; `ELQGetDecodedFileSize` always returns -1;
  `ELQBinGetSize(bin, which)` acts as a divisor (`1` -> byte size, `2` -> sample count);
  `ELQBinGetBuffer` always copies into a heap buffer; samples/frame = 160 @8 kHz, 320 @16 kHz,
  640 @32 kHz, with decoder lead-in 110/224/509 samples respectively.

**Worked example (paralinguistics unit `Aa`)**: `P=Aa|0|61846` -> start sample 0, length
`61846*32000/100000 = 19790` samples, decoder called `(handle, 0, 19854, out, bin)`
(19 790 + 0 pre-roll + 64 post-roll), i.e. frames 0..31 of `JorgeGildedParalinguistics…bin`.

## 13.7 Acceptance test already passing: inventory -> audio, binary-free

For the SDK voice (`engine_re/vox.bin`, `Coding=linear`, 16 kHz PCM; inventory `payload/Ludoviko.sde13`,
legacy generation) the whole chain was executed with only the tools in this repository:

```
sde_parse.parse(Ludoviko.sde13)  ->  units[i].d[] records (start/end in 10 us units)
sample = pos * Fs / 100000       ->  pcm[a:b]                       (render_bin.read_container/pcm_from_linear)
                                 ->  WAV
```
Observed for the first units:

| unit tokens | record | positions | samples | duration | RMS |
|---|---|---|---|---|---|
| `#` (pause marker) | `0,S,15769400,15779075` + `0,D,15779075,15794394` | 157.69 s .. 157.94 s | 1 548 + 2 451 = 3 999 | 0.250 s | **5.9** |
| `$` `#` | `0,D,2636850,2649844` | 26.37 s .. 26.50 s | 2 079 | 0.130 s | **609.9** |

The `#` unit (the alphabet's pause/silence symbol) cuts a near-silent segment (RMS 5.9) while a
voiced unit cuts an energetic one (RMS 609.9) - an end-to-end semantic check of the inventory
semantics, the 10 us time base and the container reader, with no Loquendo binary involved.

For the Jorge voice the identical code path runs once the Codec210 frame decoder exists
(`tools/render_bin.py` already de-obfuscates frames with the key from sub-header byte 27 and calls
`codec210.decode_frame`; frames are at `150 + 110*i`, 640 samples each).

---

# 15. Codec 210: ABI, frame layout, and verification against the real decoder

Full detail: `specs/Codec210.md` (599 lines), tables `tools/codec210_tables.json` (188 KiB),
prototype `tools/codec210.py`, table extractor `tools/codec210_extract.py`, and a **reference oracle**
`tools/codec210_oracle.py` that runs the *real* `LTTS7Codec210.dll` under Unicorn emulation to produce
ground-truth PCM.

* Plugin ABI: single export `LTTS7Codec210` (RVA 0x4760) = `{name;proc}` dispatcher over 8 entries
  (`LoadUtilSymbols`, `GetVersion`, `ELQOpenDecoder`, `ELQCloseDecoder`, `ELQGetDecodedFileSize`,
  `ELQGetDecoderDescription` = `"Loq210"`, `ELQDecoderFileChanged`, `ELQDecode`); the DLL imports only
  `KERNEL32` and binds the five Util entry points (`ELQBinGetBuffer`, `ELQLogWrite`, `ELQfree`,
  `ELQmalloc`, `ELQstricmp`) at load time.
* A frame is **880 bits = 110 bytes** with a layered sub-band CELP layout: 8 kHz core
  (`wideband` 1b, `mode8` 4b, 5x6b LSF order-10, 5b frame energy, 4x{7b pitch index, 7b lag, 3b,
  16x6b codebook}) + 16 kHz band (1b, 3b mode, 2x6b LSF, 4x{4b gain, 10x(1b sign + 7b index)})
  + 32 kHz refinement (1b, 3b, 2x6b LSF, 4x5b). The bit reader consumes **880/880 bits on every
  frame** (verified over whole blocks, including the last frame of the file) - a very strong check
  that the field layout is right.
* **Exact** (reproduced byte-for-byte against the decoder's own internals): container + sub-header,
  per-frame XOR key/length, bit reader, field layout, LSF VQ (order-10 5-stage and order-8 2-stage,
  with the documented ramp tables), LSF -> LPC (P/Q sum-difference with `cos`), and the float -> int16
  clamp/round.
* **Root cause of the remaining gap, located** (fresh jorge dump `jorge_re/decomp_codec210_jorge.txt`,
  created here): there is **no unidentified filter-bank stage**. In `FUN_1000e170` the two buffers the
  verified combine reads are produced 4 lines earlier by the polyphase interpolator itself:
  `+0x2c` = `+0x28` shifted by a lag, `+0x34` = output of the upper-band LPC synthesis, then
  `A = FUN_10003960(+0x2c, 0x100240a8)` and `B = FUN_10003960(+0x34, 0x100241a8)`, immediately followed by
  `FUN_1000c290(out, A, B)` = `out = clamp(round(2*(A-B)))` (correlation 1.000000 when fed the real
  buffers). `FUN_10003960` (jorge VA 0x10003960) is a 4-phase polyphase FIR with a delay line, a
  coefficient strip pair and a tail state carried across frames, i.e. exactly the stage that is still
  unported; porting it (plus the two input buffers) is the whole remaining work on the output path.
* **Still approximate** (being closed): the frame-energy/gain dequantiser (currently fitted),
  the 3-tap pitch/adaptive-codebook excitation, and the QMF band re-combine. Measured against the
  oracle on voiced frames (37..42 of the Jorge DB, key 0x6D): RMS is in the right ballpark
  (4934 vs 3890) but the waveform correlation is only ~0.02, i.e. the spectral envelope is right and
  the excitation is not yet.

**Verification harness (works now):**
```
/tmp/uv/bin/python tools/codec210_oracle.py 37 6 0x6d /tmp/ref2.raw      # ground truth from the real DLL
python3 tools/codec210.py                                                # prototype: RMS per 10 frames
```
Unicorn 2.1.4 + pefile are installed in the venv `/tmp/uv`; the oracle binds the five Util entry
points to Python stubs, fixes the x87 control word and replaces the MSVC CRT allocator entry points so
the unmodified DLL runs.

## 15.1 End-to-end commands that work today (binary-free)

```
# 1. inspect any voice database container
python3 tools/bin_dump.py jorge/pf/Loquendo/LTTS7/data/voices/Jorge/Jorge.32000.LTTS7Codec210.44000.10.bin

# 2. inventory -> audio for a `linear` (raw PCM) voice - fully exact, no decoder needed
python3 tools/render_unit.py engine_re/vox.bin payload/Ludoviko.sde13 2 /tmp/u2.wav

# 3. inventory -> audio for the Jorge voice (Codec210 decoder; excitation still approximate)
python3 tools/render_unit.py \
    jorge/pf/Loquendo/LTTS7/data/voices/Jorge/Jorge.32000.LTTS7Codec210.44000.10.bin \
    jorge/pf/Loquendo/LTTS7/data/voices/Jorge/Jorge.sde 1 /tmp/jorge_u1.wav
```
Observed: (2) unit `$`+`#` -> 2 079 samples, RMS 609.9; (3) unit `#`+`` `a ``+`#` -> 7 748 samples
(0.242 s @ 32 kHz), RMS 4081.3 - the vowel `a` cut out of the coded database by the pure-Python chain.

## 15.2 Decoder architecture as now established (jorge build)

`tools/codec210.py` implements the following chain; the stages marked *exact* were each validated
against the real DLL (either by reproducing the decoder's own intermediate buffers or by correlation
1.000000 against the emulated decoder):

```
ELQDecode
  per 110-byte frame: un-XOR with sub-header[27] (exact)
  bit reader, 880 bits/frame, 182 reads, err=0 (exact layout)
  dyadic cascade 8 kHz -> 16 kHz -> 32 kHz:
     8k core : pitch (FUN_10006bb0) + 2 x segmented fixed codebook
               desc {dim 5, count 8, bits 6, no sign, table 0x10021bd8}
     16k band: coded branch, 2 x fixed codebook
               desc {dim 8, count 5, bits 7, sign, table 0x10022470}
     32k band: NOISE branch (mode object +0x28 == 0): read(5) -> gain dequantiser
               FUN_10011aec + energy FUN_10002ec0 + noise source, ramp + tilt gain
  per-level LSF VQ + interpolation/stabilisation + LSF->LPC (exact)
  per-level LPC synthesis, transposed DF-II (exact)
  band filter FUN_10003960 = 4-phase polyphase interpolator with delay line and tail state
       (ported; reproduces the real output with correlation 1.000000, max abs diff 5e-4)
  combine FUN_1000c290: out[i] = clamp(round(2*(A[i]-B[i])))        (exact)
       A = band_filter(obj+0x2C, coeffTable 0x100240a8)   (the dominant path: corr(2A, out) = 0.991)
       B = band_filter(obj+0x34, coeffTable 0x100241a8)
```

Remaining (ordered, in `specs/Codec210.md` S10.2): 8k pitch + codebook excitation, the ring-window
addressing of `obj+0x2C` (currently correlation 0.958 with the previous level's A output), the 16k coded
branch, the 32k noise branch, and the exact 5-bit frame-energy dequantiser. With those ported the
decoder becomes sample-exact; the oracle (`tools/codec210_oracle.py`, Unicorn emulation of the real DLL)
supplies ground-truth PCM for any frame range so each stage can be checked individually.

**Current fidelity, stated plainly:** the pure-Python chain reproduces the coded *envelope* (RMS within
~2x, correct silence/speech segmentation, correct bit consumption) but not yet the waveform
(correlation 0.006 on voiced frames). The repository tools therefore render structurally correct audio
from the real database, while sample-exact reproduction of the original voice still needs the excitation
stages above.

---

# 16. What remains, exactly (handoff)

Everything below is the *complete* list of work left for a 1:1 binary-free reimplementation. Nothing
else is unknown: the application, the installer, the engine API, the voice/DB/inventory/language formats,
the engine<->voice binding, the unit->decoder path, the codec's bit layout, spectral model, band filter
and output combine are solved and verified (S1-S15, `specs/*.md`).

## 16.1 Codec 210 excitation chain (the only thing between us and sample-exact audio)

Ordered, each step validated against `tools/codec210_oracle.py` (ground truth from the unmodified DLL):

1. **8 kHz LTP/pitch - SOLVED EXACTLY** (this pass, by emulator instrumentation; zero residual on 12/12
   pitch calls across frames 20/38/60). `FUN_10006bb0` (jorge VA 0x10006bb0) is called from `0x10009c0d` per
   subframe with `(h, 17, 144, 0, pitchDesc 0x100237e4, 40, &lag, &gains, bitreader, scratch, 0, 0, 2.04, 0)`
   and computes, with `lag = first 7-bit field + 17`, `idx = second 7-bit field`,
   `g[k] = int8[0x10022150 + 3*idx + k]/64 + 0.5`:

   ```
   S      = buf[h-(lag+1) : h-(lag+1)+120]        # 120-float copy taken BEFORE the outputs are written
   out[i] = g[2]*S[i] + g[1]*S[40+i] + g[0]*S[80+i]     # i = 0..39, exact (err = 0.000)
   ```
   Buffer maintenance (also measured): the frame base is fixed, `h = base + 40*sf`, and at every 8 kHz frame
   start a 145-float `memmove` from `base+15` to `base-145` runs (from `0x100096fc`), i.e.
   `buf[base-145:base] = buf[base+15:base+160]` - the excitation is one running array with 145 floats of
   history. Proven gains/lags per frame: f20 lags 59/78/29/115; f38 71/66/94/93; f60 82/72/69/80.
   Probes kept in the repository: `tools/oracle_ltp_probe.py` (captures + verifies the model) and
   `tools/oracle_attrib.py` (reliable write->code attribution).

   *Instrumentation trap worth recording:* the EIP reported inside a `UC_HOOK_MEM_WRITE` callback is not
   reliable in this Unicorn setup (it mis-attributed the excitation writes to the wrong function), and
   `UC_HOOK_MEM_READ` barely fires; reliable attribution needs a global `UC_HOOK_CODE` hook keeping the last
   executed address, and call-site stack snapshots for arguments.

   *Original open question (kept for context):* the *geometry* is proven by direct
   emulation tracing (read watchpoint on a real pitch call: exactly 120 reads at 4 instructions, spanning
   `h-72 .. h+47` for a declared lag of 71 = `h-(lag+1)`, i.e. the three delayed windows at lag+1, lag,
   lag-1) and the history priming is identified (a 580-byte `memmove` of the previous frame's LTP tail,
   145 floats, at the start of every 8 kHz frame from `0x100096fc`). What is still missing is the **gain
   dequantiser / index mapping**: the table read gives ~-0.05 while the subframe output RMS is 431, and a
   free 3-tap least-squares fit over the traced windows reaches only 0.57-0.61, so the coefficient values
   are not the ones assumed. A numeric solve `dest = g0*w0 + g1*w1 + g2*w2` over the scratch blocks was run
   and **failed with residuals exceeding the signal**, which rules out the assumed tap-window model:
   the 120 traced reads are *120 consecutive floats* (h-72 .. h+47) copied as three 40-blocks, i.e. a
   **linearisation of a ~120-sample circular buffer**, and the FIR then combines the three linearised blocks
   at offsets that are not the lag-1/lag/lag+1 triple - so the taps read the *already written* samples of
   the current subframe. The remaining measurement is one direct observation, specified in
   `specs/Codec210.md` S10.4: single-step the FIR loop from `0x10006e20` and log (scratch source address,
   coefficient address) pairs, which yields the tap offsets and the coefficient stride with no hypothesis
   left; then the 32 kHz and 16 kHz excitation branches complete the chain.
1b. **Innovation stage (remaining blocker, state of the chase).** Verified by emulator instrumentation:
   the scale/gain helper `FUN_10002da0` is called at `0x10009da4` (CB1, dst `0x300125f0+0xa0*k`) and
   `0x10009fda` (CB2, dst `0x3000e0a4`) with the multiplier as the *second stack argument*; measured values for
   frame 38 are 1245.3 / 366.36 (ratio 3.399 = q[4]/q[1], and CB2/CB1 = 1/2.2), which pins the law
   `g = C(g8)*q[b3]` with `C(27) = 958.5 = 0.430*1.3305^27` (the previously fitted 0.5 factor is wrong and
   has been removed). `FUN_10002ec0` is a plain energy (`sum(p^2)`), `FUN_10011aec` is the MSVC CRT
   intrinsic dispatcher, *not* a dequantiser - the gain arithmetic must be read at the CB call sites.
   The 8k-core call graph is mapped (`0x100011d0` bit reader, `0x10002da0` scale, `0x10005520`/`0x10005390`
   LSF interp/stabilise, `0x100030e0` LPC synthesis at `0x1000a14a`, `0x10011aec` once/frame). Open: the
   **domain/scale in which the innovation is summed into the excitation** - the LPC-synth call arguments are
   `(0x30012870 LPC coeffs, 0x30011ea0 output, 40, 10, 0x30012930 [rms 125, varies: excitation candidate],
   0x300082e0 [rms 584.7 *constant across subframes*: not excitation], 0x30007fe0)`, while the LTP output
   buffer (`0x30012364`, rms 1273) is ~10x larger than the candidate excitation, i.e. the excitation appears
   to live in a normalised domain that the LPC gain restores. Next measurement: capture the multiplier at the
   CB call sites per call and least-squares-fit `exc ~ a*ltp + b*cb1 + c*cb2` against the true excitation
   buffer (see the correction below).
   *Correction and last verified facts:* the 8k LPC synthesis `FUN_100030e0` is a transposed-DF-II all-pole
   filter (`x = in[i] + state[0]; t = -x; state[k] = coef[k]*t + state[k+1]; state[order-1] = t*coef[order-1];
   out[i] = x`) and it runs **in place on the excitation buffer itself** - the write timeline below shows
   `0x1000a14a` (the synthesis call) as the last of six writers of `0x30012364+40*sf`. `0x30011ea0` and
   `0x300082e0` have *identical* rms across all subframes (4180.2 / 584.7) and were **not written at all**
   during frame 38, so they are coefficient/state-like arrays, **not** the excitation; the earlier candidate
   list and the stage-local gate built on them are void (an earlier argument-role fit that suggested
   `0x30011ea0` was the input is superseded by this timeline). Also the probed addresses `0x1000a14a` and
   `0x10009d9f` are *not* the call instructions (their first stack dword is an argument, not a return
   address), so argument maps taken there are shifted - hook the actual `call` opcodes found by disassembly.
   Method that worked for the LTP and should close this stage: hook the precise call, snapshot the arguments,
   re-implement the callee in Python from its decompilation, and brute-force which argument assignment
   reproduces the observed output exactly.
   *Decisive result:* the 8 kHz LPC-synthesis input is **exactly the LTP output** - a least-squares fit
   `exc = a*ltp + b*cb1 + c*cb2` returns `(1.0, 0, 0)` with residual ~1e-12 for all four subframes of frame
   38. So the innovation is **not** summed into the 8 kHz excitation; it must be folded into the
   **adaptive-codebook history** that the LTP copies from (`buf[h-(lag+1) : +120]`), which is also why a port
   that maintains its own history without that priming diverges immediately (the LTP formula was verified
   against the real emulator scratch, i.e. it is exact *given the real history*). The last link is therefore
   to find the write that primes that history region (reliable attribution: global UC_HOOK_CODE + last
   executed address), and the clean gate is to match the port's own 120-float LTP window against the
   emulator's per subframe (target corr >= 0.999) before measuring end-to-end.
   *Follow-up counter-evidence:* the excitation region (`0x30012364+160*sf`) has **three writers besides the
   pitch call** - the codebook-synthesis sites `0x10009b6f`, `0x10009f3e`, `0x10009ff1`, each reached with an
   argument frame carrying **two gains** (a common 215.763 plus 1245.3 / 566.02 / 2.7489 respectively; all
   with `ebx = 0x30012364`, `esi = 0x3000de20`). So the 8 kHz core writes the excitation region more than
   once per subframe - i.e. the innovation *is* accumulated into the excitation (most likely after the LTP),
   and the "`exc == LTP`" reading must have been taken at an instant before/after that accumulation. The
   correct next measurement is a write timeline at 0x30012364+160*sf: pitch-entry, pitch-exit, after each of
   the three codebook sites, and at the LPC entry - which shows exactly where and with which gain the
   innovation enters, after which the port's LTP window S can be matched against the emulator's per subframe.
   (The port's current S is ~50x too large because its LTP recurses on itself without that renewal, which is
   also what keeps the real predictor stable.)
   *Settled by the write timeline (hooked at 0x10009b6f / 0x10009f3e / 0x10009ff1 / 0x1000a14a, reading both
   0x30012364 and 0x30011ea0):* the 8k core **clears the excitation region sample by sample** at 0x10009b6f
   each subframe, then accumulates the two/three codebook passes **and** the LTP into that same region, and
   only afterwards copies it to the LPC input 0x30011ea0 (which therefore reads `exc == LTP` at the LPC call
   while the *history* the LTP copies from is the innovation-refreshed buffer). That clear+rebuild is exactly
   what a naive port omits, and it is what makes the real predictor stable. The remaining port work is to
   reproduce the sequence `clear -> CB1 -> CB2 -> LTP -> copy to LPC input` with the measured gains
   (215.763 / 1245.3 / 566.02), then re-run the S gate (port S vs emulator S, corr >= 0.999).
1c. **Status of the innovation mapping (gap still open, with a golden dataset).** The accumulation
   architecture is closed and the port now reaches **correlation +0.51** (independently re-verified: global
   corr 0.465 over frames 0..59, per-10-frame 0.70/0.36/0.51/0.61/0.20/0.82) with the RMS envelope tracking
   the reference. What is still wrong is the *shape* of the innovation contribution: measured per subframe
   (frame 38) the exact stage values are
   `exc_stages_frame38.json` in `jorge_re/` - arrays for each subframe: values after the clear, after the LTP
   write, after the CB1 accumulation and after the CB2 accumulation, plus the parsed 16 six-bit indices.
   Negative results (so the next attempt does not repeat them): the CB1/CB2 increments are **not** reproduced
   by "8 six-bit indices -> 8 concatenated 5-sample segments of table 0x10021bd8 scaled by 1/32" for any
   tested index split (first8/last8, last8/first8, evens/odds, odds/evens), sign (+-1) or scale
   (1/32, 1/64, 1/16, 1), nor is each 5-sample position explained by any single table segment
   (`tools/oracle_cb_probe.py` prints the best segment per position: residuals 0.4-4.7 relative, scales
   0.03-0.6). So the true mapping is of a different kind (e.g. filtered/interpolated codebook vectors, a
   different arrangement of the 40 samples, or the writes at 0x10009f3e/0x10009ff1 applying a
   multiply-accumulate rather than a plain add). The golden dataset above is the target to fit.
1d. **Consolidated state after the closing push** (all measured):
   * The innovation codebook mapping and the gain law are **exact**: with the golden dataset the measured
     CB1/CB2 increments equal `gain * codebook_vector` position by position (frame 38 sf0: port vector
     [-0.09,-2.12,0.16,1.09,0.22] x 1245 = the measured [-116.74,-2646.17,194.57,1362.0,272.4]), so the
     8 six-bit indices -> 8 concatenated 5-sample segments of table 0x10021bd8 at 1/32, times
     `gain = C(g8)*q[b3]`, is confirmed (my earlier negative result was a bad fit that ignored the known
     gain). The fitted `exc_scale` (3.5) is removed - the excitation now carries no fitted constant, and the
     output is correspondingly ~4x quiet, i.e. the missing gain is in the **output path**, not in the loop.
   * The real 8k history is **bounded and carried**, never reset (frames 30..41: history rms 0.6/0.7 ... 1336
     /1879/2434/1869 against excitation rms 0.6/0.7 ... 1866/2327/1786/1070), while a port that injects too
     much innovation diverges - the reason the fitted 3.5 was fatal inside the recursive loop.
   * Real A32/B32 amplitudes vs the port (agent measurement, frames 37/38/39): real
     rms(A32)=617.5/2382.0/2539.1, rms(B32)=83.2/53.3/30.6, rms(2(A-B))=1246.6/4765.1/5078.5 (matching the
     reference exactly => the combine is right) versus port pcm 675.9/1954.4/890.9 - i.e. 1.8x/2.4x/5.7x
     low **and not a constant ratio**, so the A path differs in *content* (the excitation residual), not by a
     gain. B32 is 3-13% of A32, so it is not the main error.
   * S gate (my measurement, frame 38, real window read at the pitch call's return): real window rms
     545/2509/2539/515 versus port 1234/1559/1542/1845 with corr 0.03-0.37 - the port's *window* differs
     because its per-subframe state has drifted; the full-buffer comparison after 38 frames gives corr 0.739
     (frame part) / 0.849 (history part) with no index shift, so the port tracks the real state but with a
     ~26% shape error that accumulates from the fitted gain law and the missing bands.
   * Port status: excitation vs golden corr 0.66/0.69/0.70/0.03 with matching rms; end-to-end corr 0.51 over
     frames 0..119; envelope tracks the reference. Ordered next steps: exact `C(g8)` (a table/derived law
     rather than the 0.2%-fit) to stop the state drift, the A-path amplitude (dump real A16 and check each
     band_filter stage's gain), then B32 and the 16k coded branch.
3. **32 kHz noise branch** - mode word `+0x28 == 0`: `read(5)` -> dequantiser `FUN_10011aec` +
   energy `FUN_10002ec0` + noise source + ramp `_DAT_100242f8` + tilt gain.
3. **16 kHz coded branch** - `read(4)` + 2x segmented codebook `FUN_100029c0` with descriptor
   `0x10023a5c` = {dim 8, count 5, bits 7, sign, table 0x10022470}.
4. **Exact 5-bit frame-energy dequantiser** (currently a fitted `A*B^g8` mapping) and the exact
   cross-frame state: the port and the oracle must agree from frame 0 (silence frames 0..36, ramp 37..42),
   not from a cold start mid-file.

Acceptance for 1-4: correlation >= 0.9 (target ~1.0) between `Codec210().decode_frame(raw, key)` and
`/tmp/uv/bin/python tools/codec210_oracle.py <first> <count> 0x6d out.raw` over frames 0..40, RMS within
+-5%. The A path dominates (`corr(2*A32, out) = 0.991/0.9997`), so step 1 alone should already lift the
end-to-end correlation sharply.

## 16.2 Linguistic leftovers (needed for OOV/foreign words and non-Spanish languages)

* `Spanish.lex` / `Spanish Automotive.lex` / `SISpanish.lex`** are compiled binary lexicons/rules
  (common 16-byte header `ca fe db 60 df e3 dc a4 c9 a5 85 f3 96 e4 97 fe`; neither bit-7 clearing nor
  XOR `d[0]^d[1]` yields text). They implement the regular grapheme->phoneme rules and the say-as styles
  (`AddressSpanishEs.ycf` -> `Spanish Automotive.lex`). A reimplementation can substitute a rule-based or
  statistical G2P producing the documented phoneme alphabet (`specs/SpanishLanguage.md`).
* Other languages' `.gpr` rule files (English/German/... present in the engine distribution) are an
  un-reversed format; Spanish ships none.

## 16.3 Optional fidelity items

* The `Patch.exe` voice-licensing crack (S8) - documented, not needed for a reimplementation.
* Director GUI pixel-detail: the behaviour, menus, dialogs and file formats are specified in S4/S6; the
  recovered Java sources in `src/` are the reference if exact widget fidelity is wanted.

## 16.4 CLOSED: the 8 kHz excitation chain is exact (this pass)

Two structural bugs were found and fixed in the port (`tools/codec210.py`), both by emulator measurement:

1. **The LTP window is three overlapping 40-float windows, not one contiguous 120-float slice.**
   Memory scans place the scratch's three blocks at `w0`, `w0+1`, `w0+2` (w0 = h-(lag+1)) for every
   subframe - i.e. the FIR is the plain 3-tap predictor at lags `lag+1, lag, lag-1`.
   Fix: `out[i] = g[2]*buf[w0+i] + g[1]*buf[w0+1+i] + g[0]*buf[w0+2+i]` (probe: `tools/oracle_find_window.py`).
2. **The exact innovation gain law** (`specs/GainLaw.md`): `gain = float32(EXC_Q[b3] * float32(exp(g8/3.5)))`
   with the real 8-entry Q table at VA 0x10023db8, second pass scaled by the exact double `5/11`
   (0.45454545454545453 at VA 0x10023ee8), and every stored sample rounded to float32.
   Verified to 9.8e-08 over 284 sub-frames.
3. **The missing 16 kHz level combine** (`out16 = 2*(A16-B16)`, APath task): band_filter has an intrinsic
   flat gain of 1/2 per call, so the port was exactly 2x low; fix adds `out16 = [2*v for v in a16]`
   (probe/evidence: `specs/APath.md`).

Results (pure-Python decoder vs the real DLL under Unicorn; harness `tools/verify_codec.py`):

| range | global corr | amplitude ratio |
|---|---|---|
| frames 0..119 | **+0.9925** | 0.983 |
| frames 0..299 | **+0.9894** | 0.983 |
| loud windows (e.g. 40-49) | **+0.9993** | 1.000 |
| quiet/noise windows (0-39) | 0.51-0.82 | ~0.4 |

The S gate (`tools/oracle_sgate.py`) now reports **corr +1.0000 on all four subframes** with window rms
matching to 0.05% - i.e. the adaptive-codebook history, the LTP, the innovation gains and the float32
rounding all reproduce the real decoder.

**Upper bands CLOSED (same pass, `specs/UpperBands.md`).** B16 (16 kHz coded) and B32 (32 kHz noise) are now
ported: 16 kHz gain `(E+1)*exp(g4*0.27027027-0.15556)/norm16` with `norm16=(d8+0.01)/(0.01+d16)`, codebook
desc 0x10023a5c (128x8 table 0x10022470, x1/32, sign, second pass x0.4), 32 kHz gain
`exp((idx5-10)*0.125)/norm32` with the noise `(-1)^i` ramp, x0.7, source `2*exc16` zero-interleaved, plus
the 16 kHz level combine `out16 = 2*(A16-B16)` and the first-frame LSF rule (obj[+0x1c]).  Every DLL buffer
is reproduced at corr 1.000000 (frames 37/38/39) and the patched port now measures:

| range | global corr | amplitude ratio |
|---|---|---|
| frames 0..119 | 0.9995 | 0.995 |
| frames 0..299 | **0.9975** | **0.991** |
| loud windows | 0.9949-1.0000 | 0.99-1.00 |
| silence windows 0..39 | 0.90-0.96 | 0.6-0.8 (dither level, +-1 int16 LSB) |

**Remaining residual:** 20 of 299 frames still show an 8 kHz-chain drift (worst window 120-129: 0.6538;
frames 119-129, 150-179).  The upper-band stages track the 8 kHz input at 0.999+ even there, so the drift is
in the 8 kHz LSF/interp/LPC path or its per-frame state (frame 119 exc8 = 0.948 but sig8 = 0.926, frame 120
exc8 = 0.922 and sig8 = 0.636 - i.e. the *synthesis* diverges more than the excitation).  This is the last
open item; a follow-up task targets exactly those frames (dump the real LSF/LPC arrays and the synthesis
state and diff against the port).

## 16.5 CLOSED: the 8 kHz LTP ring rule and the final acceptance numbers

The last drift (20 of 299 frames) was root-caused in `specs/DriftFrames.md`: the DLL's tap windows are a
**cyclic read of the `lag` samples ending just before the current sub-block** - the current (cleared)
sub-block is never read:

```
w0 = p-(lag+1)
RING[k] = buf[w0+k]                    for k <= lag
          buf[w0 + 1 + ((k-1) % lag)]  for k >  lag
out[i]  = g2*RING[i] + g1*RING[i+1] + g0*RING[i+2]
```
For `lag >= 41` the ring does not wrap inside the 42 taps used, which is why only `lag <= 40` sub-frames
drifted. Evidence: the DLL's own 120-float tap scratch (0x3000e0a4) - e.g. frame 118 sf1 (lag 20), tap k=21
equals `buf[w0+1]` while the plain form reads `buf[w0+21]`. LSF VQ, interp weights, stabilisation margin,
VQ ramps, LSF history, LPC state and layout were all checked and are **exact** (DLL arrays 0x300128a0 LSF,
0x30012870 LPC, 0x30012a20 tilt match at corr 1.000000 on every frame, including the drift frames); the
first diverging array was always the excitation, and inside it only the LTP (CB1/CB2 exact everywhere).
Boundary variants were measured (wrap threshold and modulus); the DLL-matching best is threshold `lag`,
modulus `lag` (global 0.99965 vs 0.99913 for modulus `lag+1`).

**Final acceptance (pure-Python decoder vs the real DLL under Unicorn, harness `tools/verify_codec.py`):**

| metric | value |
|---|---|
| global correlation, frames 0..299 | **0.99965** |
| amplitude ratio (rms) | **1.001** |
| speech 10-frame windows (>= frame 40) | min **0.9991**, median **1.00000**, **19 of 26 exactly 1.00000** |
| silence windows (frames 0..39) | 0.90-0.97 (dither level; +-1 int16 LSB floor) |
| stage-local gates | S gate 1.0000 (4/4 sub-frames); every band buffer 1.000000 (16 kHz/32 kHz) |

The remaining difference is float32 rounding in near-cancelling sums and the int16 clamp floor - i.e. the
codec is reproduced to the limit of the DLL's own arithmetic. All fitted constants are gone: the gain law,
Q table, ring rule, band gains, codebooks, tilt terms and ramp constants all come from measured DLL values
with their addresses recorded in `specs/GainLaw.md`, `specs/UpperBands.md` and `specs/DriftFrames.md`.


---

# APPENDIX: specs/GainLaw.md

# The exact 8 kHz innovation gain law of LTTS7Codec210 (Jorge build)

Scope: replace the fitted law `gain = 0.430 * 1.3305**g8 * q_fit[b3]` in
`tools/codec210.py::Codec210.exc_gain()` with the **exact** law measured from the shipped
`LTTS7Codec210.dll`. Target file: `tools/codec210.py` (function `exc_gain`, plus the CB2
factor in `decode_frame`). Everything below is measured against the real DLL running under
Unicorn (`tools/codec210_oracle.py`, interpreter `/tmp/uv/bin/python`).

---

## 1. Result

The 8 kHz core innovation gain is computed **once per sub-frame** as

```
X    = float32( exp( g8 / 3.5 ) )                       # g8 = 5-bit frame energy field
gain = float32( q[b3] * X )                             # b3 = 3-bit sub-frame field (the gain index)
gain_CB2 = float32( gain * 0.45454545454545453 )        # double 5/11 = 0x10023ee8
```

with

```
q = [0.06112999841570854, 0.16354599595069885, 0.3104130029678345,
     0.4282200038433075,  0.55588698387146,     0.7190549969673157,
     0.9386940002441406,  1.326874017715454]
```

* `q` **is** the 8-entry float32 table at VA `0x10023db8` (bytes
  `73637a3d 9a78273e 74ee9e3e a73fdb3e 9c4e0e3f fd13383f 404e703f 02d7a93f`).
* the divisor `3.5` **is** the double at VA `0x10023e70` (`0000000000000c40`); the exponentiation
  is the CRT `_exp` reached through the intrinsic dispatcher at VA `0x10011aec`, and its result is
  rounded to float32 (`fstp DWORD PTR [esp+0x5c]`, VA `0x100099b1`).
* `0.45454545454545453` **is** the double at VA `0x10023ee8` (`175d74d14517dd3f`), applied with
  `fmul QWORD PTR ds:0x10023ee8` at VA `0x10009fba`.
* there is **no** per-sub-frame LPC-tilt / normaliser factor on the coded innovation
  (the `gden` term the port used is wrong — see §7).
* the innovation is the *only* thing this law scales; the excitation is then
  `dst = LTP; dst += CB1*gain; dst += CB2*gain_CB2` accumulated in float32.

Only the `read(3)` branch is used by the Jorge DB: the mode descriptor's `+8` field is **3** in
every frame measured, so the 8-entry table at `0x10023db8` is selected. The `read(1)` branch
(two-entry float32 table at `0x10023ddc` = `0.7046899795532227, 1.0512700080871582`) is dead code
for this voice.

---

## 2. What was measured and how

### 2.1 Probe (method requested by the task)

For **frames 0..70** (71 frames = **284 sub-frames**), all inside the same streaming decoder
instance (state carried from frame 0):

1. Instrumented **write capture** on the 8 kHz excitation buffer
   `EXC = 0x30012364`, 160 floats (4 sub-frames × 40: sub-frame `sf` occupies
   `EXC + 40*sf`), with a global `UC_HOOK_CODE` hook that keeps the last executed address and a
   `UC_HOOK_MEM_WRITE` hook that stores the written bytes (from the hook's `val` argument —
   **the Unicorn write hook fires *before* the store, so `mem_read` inside it returns stale data**).
   The four writers of that buffer per sub-frame, in this fixed order:

   | stage | code address(es) | meaning |
   |---|---|---|
   | `clear` | `0x10009b6f` | `dst[i] = 0` (VA `0x10009b6d` `fldz`) |
   | `ltp` | `0x10006f94`, `0x10006fb2`, `0x10006fd4`, `0x10006ff7` (inside `FUN_10006bb0`), and `0x10009c0d` (the `call` itself) | the 3-tap LTP output stores |
   | `cb1` | `0x10009f3e` | `dst[i] = dst[i] + scratch[i]` (VA `0x10009d9f` scaled the scratch by `gain`) |
   | `cb2` | `0x10009ff1` | `dst[i] = dst[i] + scratch[i]` (VA `0x10009fd5` scaled by `gain*5/11`) |

   Coverage was **160/160 floats at every stage in every frame** for the run reported here.
   (Caveat for anyone re-running this: the LTP stores are attributed to the four
   `FUN_10006bb0` addresses above; whether they are also seen at `0x10009c0d` depends on the
   Unicorn translation-block cache, so whitelist *both*.)
2. Increments: `inc1 = value_after_cb1 - value_after_ltp`, `inc2 = value_after_cb2 - value_after_cb1`.
3. Codebook vector: the port's own `Codec210().codebook(idx)` built from
   `Codec210().parse_frame(block)["sub8"][sf][3]` (first 8 six-bit indices for CB1, last 8 for CB2).
4. `gain_measured = <inc, v> / <v, v>` per sub-frame and per pass, plus the relative projection
   residual `||inc - gain*v|| / ||inc||`.
5. Independently: the **real gain argument** was read straight off the stack at the
   `FUN_10002da0` call sites — `float32 [esp+0x1c]` at VA `0x10009d94` (CB1) and
   `float32 [esp+0x30]` at VA `0x10009fb6` (CB2, pre-`5/11`) — and `X` at VA `0x10009d56`
   (`float32 [esp+0x5c]`), together with the branch taken (VA `0x10009d18`/`0x10009d38`/`0x10009d48`)
   and the index read (`eax` at those lookups).

`gain_measured` (from step 4, i.e. the emulator's own excitation buffer) and the real gain
argument (step 5) agree to ≤1e-7 in every one of the 284 sub-frames: the increment *is* the
scaled codebook vector.

### 2.2 The code path (disassembly, all VA)

```
10009993  push 5 / push <reader> / call read            ; g8 = read(5)   (frame level)
1000999f  fild  [esp+0x64]                              ; g8 as float
100099a6  fdiv  qword [0x10023e70]                      ; g8 / 3.5
100099ac  call  0x10011aec                              ; _exp
100099b1  fstp  dword [esp+0x5c]                        ; X = float32(exp(g8/3.5))
   ...  (LTP call at 10009c0d, scratch cleared at 10009ced)
10009d08  cmp   eax,3 ; jne 10009d28                    ; mode descriptor [+8] == 3 ?
10009d13  push 3 / push <reader> / call read            ; i = read(3)
10009d18  fld   dword [eax*4 + 0x10023db8]              ; q[i]
10009d1f  fmul  dword [esp+0x64]                        ; q[i] * X        (esp+0x64 == esp0+0x5c)
10009d23  add   esp,8 ; jmp 10009d4c
10009d38  fld   dword [eax*4 + 0x10023ddc] ;  (read(1) branch, unused)
10009d48  fld   dword [esp+0x5c]                        ; else branch (=X)
10009d52  fstp  dword [esp+0x1c]                        ; gain = float32(q[i]*X)
10009d9f  call  0x10002da0(scratch, scratch, gain, 40)  ; FUN_10002da0: dst[i] = src[i]*gain
10009f3e  dst[i] += scratch[i]                          ; CB1 accumulated into the excitation
10009fb4  call  <codebook #2>                           ; second FUN_100029c0 pass
10009fba  fmul  qword [0x10023ee8]                      ; gain * (5/11)
10009fd5  call  0x10002da0(scratch2, scratch2, gain*5/11, 40)
10009ff1  dst[i] += scratch2[i]                          ; CB2 accumulated
```

`FUN_10002da0(dst, src, k, n)` is a plain `dst[i] = src[i] * k` with `dst == src` here
(float32 store per sample). Because `dst == src`, the CB1/CB2 accumulations are
"rounded to float32 at every sample".

Mode note: the 8 kHz core object's mode index `[obj+0x80]` is **7** (mode array `0x10023a0c`,
descriptor `0x10023978`), so the `if (mode == 1)` noise-mixing branch in `FUN_10009520` is
**not** taken: the excitation is exactly `LTP + CB1 + CB2`, which is what the increments show.

---

## 3. Measured tables

### 3.1 `q` fixed by gain-law-independent ratios (within-frame, same `g8`)

Within one frame `g8` (and therefore `X`) is constant — verified for all 71 frames — so the ratio
of two sub-frame gains in the same frame is exactly `q[b3_a]/q[b3_b]`. Over all frames:

```
max | gain_measured(b3)/gain_measured(b3_0)  -  q[b3]/q[b3_0] | = 3.80e-07
```

i.e. the 8-value table §1 is confirmed without using the exponential at all.

### 3.2 The full `q` dependence (representative rows, 284 records total)

| frame | sf | g8 | b3 | gain_measured (from increments) | gain (real arg) | model from §1 | projection resid |
|---|---|---|---|---|---|---|---|
| 0  | 0 | 0  | 2 | 0.31041 | 0.31041 | 0.31041 | 4.9e-14 |
| 0  | 2 | 0  | 5 | 0.71906 | 0.71905 | 0.71905 | 2.4e-08 |
| 31 | 1 | 0  | 5 | 0.71906 | 0.71905 | 0.71905 | 3.9e-08 |
| 38 | 0 | 27 | 4 | 1245.25489 | 1245.25488 | 1245.25488 | 4.6e-08 |
| 38 | 1 | 27 | 1 |  366.36304 |  366.36304 |  366.36304 | 3.1e-08 |
| 38 | 2 | 27 | 7 | 2972.36011 | 2972.36011 | 2972.36011 | 2.8e-08 |
| 38 | 3 | 27 | 1 |  366.36303 |  366.36304 |  366.36304 | 3.4e-08 |
| 55 | 2 | 24 | 6 |  892.36655 |  892.36664 |  892.36664 | 1.1e-07 |
| 60 | 0 | 14 | 7 |   72.44486 |   72.44486 |   72.44486 | 3.3e-08 |

`f32(q[4] * f32(exp(27/3.5))) = 1245.25488` reproduces the 1245.3 the earlier work measured at
frame 38 sub-frame 0 — that number was already right; the fit's error was in `q_fit` and in the
base of the exponential, which only shows up when `g8` varies (the recursion in the port).

### 3.3 `C(g8) = exp(g8/3.5)` — exact table for `g8 = 0..31`

`float32(exp(g8/3.5))` computed with Python's `math.exp` is **bit-identical** for all 32 values to
the value produced by the DLL's own x87 `_exp` path (checked by calling `0x10011aec` from a
hand-written stub `fild [esp+4]; fdiv qword [3.5]; call 0x10011aec; fstp dword [scratch]`).
Column "fit" is the old `0.430*1.3305**g8`; the last column is the **shape** error of the fit,
`C(g8)/C(0) / 1.3305^g8 - 1`.

| g8 | C(g8) | fit | fit shape err | g8 | C(g8) | fit | fit shape err |
|---|---|---|---|---|---|---|---|
| 0  | 1.0                | 0.43        | 0           | 16 | 96.68212890625     | 41.4673725  | +0.256% |
| 1  | 1.3307121992111206 | 0.572115    | +0.016%     | 17 | 128.6560821533203  | 55.1723391  | +0.272% |
| 2  | 1.7707949876785278 | 0.761199    | +0.032%     | 18 | 171.2042236328125  | 73.4067971  | +0.287% |
| 3  | 2.3564183712005615 | 1.01277528  | +0.048%     | 19 | 227.82354736328125 | 97.6677436  | +0.304% |
| 4  | 3.1357147693634033 | 1.34749751  | +0.064%     | 20 | 303.1675720214844  | 129.946933  | +0.320% |
| 5  | 4.172733783721924  | 1.79284544  | +0.080%     | 21 | 403.4288024902344  | 172.894394  | +0.336% |
| 6  | 5.552707672119141  | 2.38538085  | +0.096%     | 22 | 536.8475952148438  | 230.035991  | +0.352% |
| 7  | 7.389056205749512  | 3.17374922  | **+0.112%** | 23 | 714.3896484375     | 306.062887  | +0.368% |
| 8  | 9.832707405090332  | 4.22267334  | +0.128%     | 24 | 950.6470336914062  | 407.216671  | +0.384% |
| 9  | 13.084503173828125 | 5.61826688  | +0.144%     | 25 | 1265.03759765625   | 541.80178   | +0.400% |
| 10 | 17.41170883178711  | 7.47510409  | +0.160%     | 26 | 1683.4010009765625 | 720.867269  | +0.416% |
| 11 | 23.169971466064453 | 9.94562599  | +0.176%     | 27 | 2240.122314453125  | 959.113901  | +0.432% |
| 12 | 30.832565307617188 | 13.2326554  | +0.192%     | 28 | 2980.9580078125    | 1276.10105  | +0.448% |
| 13 | 41.02927017211914  | 17.606048   | +0.208%     | 29 | 3966.797119140625  | 1697.85244  | +0.464% |
| 14 | 54.598148345947266 | 23.4248468  | +0.224%     | 30 | 5278.66552734375   | 2258.99267  | +0.480% |
| 15 | 72.65442657470703  | 31.1667587  | +0.240%     | 31 | 7024.38427734375   | 3005.58975  | +0.496% |

**Does `C(g8) = 0.430*1.3305**g8` match within 0.1%? NO.** Two independent failures:

* the base: `exp(1/3.5) = 1.3307121992111206` vs `1.3305` → `-0.016%` **per step**, i.e.
  `-0.016·g8 %`; the fit's shape error exceeds 0.1% from `g8 = 7` and reaches **+0.50% at
  `g8 = 31`**;
* the scale: `0.430` is off by a factor **2.3256** — it absorbed the old `q_fit[3] = 1.0`
  (`0.430 ≈ q_true[3] = 0.428220`). The old `q_fit` was therefore `gain/C_fit(g8)` and is wrong
  by up to 9% per entry (`q_fit/q_true` = 2.405, 2.336, 2.223, 2.335, 2.338, 2.335, 2.546, 2.335).

Because the innovation feeds the adaptive-codebook history, `g8`-dependent errors are the ones
that accumulate in the port's recursive loop — use the table/formula in §1.

### 3.4 Coverage

`g8` observed in frames 0..70 (284 sub-frames): 0×144, 1×4, 12×4, 14×4, 15×4, 17×4, 18×4, 20×4,
21×4, 22×8, 23×12, 24×8, 25×48, 26×12, 27×16, 28×4. `b3` observed: 1×25, 2×27, 3×25, 4×30,
5×127, 6×39, 7×11 (b3 = 0 never occurred in this range but is a legal value of `read(3)`).
`X` and `g8` are constant across the 4 sub-frames of a frame in **all 71** frames (0 exceptions).

The frames asked for in the task, **30..70**, are a strict subset of the run: **164 sub-frames**,
`g8 ∈ {0,1,12,14,15,17,18,20,21,22,23,24,25,26,27,28}`, worst
`|gain_model - gain_measured|/gain_measured = 9.82e-08` — the same worst case as the full run
(it occurs at frame 55, inside 30..70).

### 3.5 `g8 == 0` is **not** gated

`g8 = 0` gives `X = 1.0` and a **non-zero** gain `q[b3]` (frames 0, 1, 2, 31 measured:
`gain = q[5] = 0.719055` for `b3 = 5`, `q[2] = 0.310413` for `b3 = 2`). The CB1/CB2 increments are
non-zero and match the codebook vector exactly (frame 0 sub-frame 0: the captured LTP stage is
`0.0` on every sample — the stream starts on a zero history, the codec's `+1e-15` floor aside —
`inc1[:6] = [-0.029101, -0.0097, 0.019401, 0.019401, 0.0, -0.029101]`,
`gain_measured = 0.310413 = q[2]`, projection residual 4.9e-14). So the innovation is emitted for
`g8 = 0`; the near-silence of frames 0..29 comes from the LTP/lower-band path, not from gating
this gain.

---

## 4. Stage-local acceptance result (emulator = ground truth)

All 284 sub-frames of frames 0..70:

| check | worst case |
|---|---|
| `\|gain_model - gain_measured\| / gain_measured` (CB1, model = §1) | **9.82e-08** (frame 55 sf 2, g8=24 b3=6) — criterion ≤1e-3 ⇒ PASS |
| `\|gain_model - gain_(real stack arg)\| / gain` (CB1) | **0.000e+00** (bit-identical float32) |
| `\|gain_model*5/11 - gain_measured(CB2)\| / gain_measured(CB2)` | 8.0e-08 |
| codebook projection residual `\|\|inc1 - gain*v1\|\|/\|\|inc1\|\|` | 1.15e-07 |
| codebook projection residual `\|\|inc2 - gain_CB2*v2\|\|/\|\|inc2\|\|` | 2.87e-07 |
| `\|gain_measured(CB1) - gain_(real stack arg)\| / gain` | 9.8e-08 |
| `\|gain_measured(CB2) - gain_(real stack arg)\| / gain` | 9.6e-08 |

Every residual is at the float32 rounding level, i.e. the excitation increments are exactly
`gain × (port codebook vector)` and `gain·5/11 × (port codebook vector)` — which also
re-confirms the port's codebook scale (the port's `codebook()` output equals the decoder's own
scratch, scale included, to ~1e-7).

---

## 5. Upper bands (16 kHz / 32 kHz): the same C/q machinery does **not** apply

Checked once, on frame 38, at the upper-band scale site `0x1000e70a`
(`call 0x10002da0`, block length 40, 4 sub-frames, object `0x30007fe0`):

```
1000e671  push 4 / call read(4)                ; i4 = the upper band's 4-bit energy field
1000e68c  call 0x10002ec0(codebook, 40)        ; Σ x²  -> the codebook energy
1000e695  fild  i4                             ; (the 4-bit field, as int)
1000e69c  fmul  qword [0x100242b0]             ; i4 * 0.27027027027027023
1000e6a2  fsub  qword [0x100242c0]             ; - 0.15556
1000e6a8  call  0x10011aec                     ; _exp
1000e6b4  cmp   [esi+0x10],0x50 ; jne ...      ; if block length == 80 (32 kHz): 
1000e6bd    fmul qword [0x100242a8]            ;    * 1.4142
1000e6ce  fdiv  [esp+0x1c]                     ; / codebook energy   (D2)
1000e6e7  fld   [esp+0x24] ; fadd 1.0          ; * (adaptive energy + 1.0)
1000e70a  call  0x10002da0(scratch, scratch, gain, 40)
```

Measured gains vs the model
`gain = exp(i4*0.27027027027027023 - 0.15556) * (E_adapt + 1.0) / E_codebook`
(frame 38, `E_adapt` = `[esp0+0x24]`, `E_codebook` = `[esp0+0x1c]`):

| sf | i4 | E_codebook | E_adapt | real gain | model | rel |
|---|---|---|---|---|---|---|
| 0 | 3 | 1.02654 | 638.397 | 1199.412354 | 1199.412299 | 4.5e-08 |
| 1 | 1 | 1.23648 | 606.470 |  551.004333 |  551.004327 | 1.1e-08 |
| 2 | 0 | 1.46465 | 585.227 |  342.588776 |  342.588774 | 6.2e-09 |
| 3 | 0 | 1.71094 | 2312.065 | 1157.161377 | 1157.161361 | 1.4e-08 |

and the four 4-bit values are *exactly* the port's `f["sub16"][sf][0]`
(frame 37 `[3,1,0,0]`, 38 `[0,1,0,2]`, 39 `[0,2,0,0]`, 40 `[2,0,0,0]` — all four frames match).

Conclusions:

* the upper bands use an **exponential energy dequantiser + codebook-energy normalisation**
  (`exp(i4*A - B)`, per-step base `exp(0.27027027027027023) = 1.3103185430275461`), with **no
  8-entry `q` table** and **no `g8/3.5`** — so `C(g8)`/`q[b3]` must not be reused there;
* the same code handles 80-sample blocks (the 32 kHz path) via the `*1.4142` branch at
  `0x1000e6b4`; in frames 37..40 the site was only reached with block length 40 (the 16 kHz band);
* the 32 kHz band's other energy fields (`read(5)`, the port's `ref32`) belong to its noise
  branch (ramp constant at `0x100242f8` = double `-1.0`), not to this site.

---

## 6. Minimal patch for `tools/codec210.py`

### 6.1 Module level (once)

`struct` is already imported; add `math` and the two constants + helper next to the other
module constants:

```python
import math
import struct

def _f32(x):
    return struct.unpack("<f", struct.pack("<f", x))[0]

# float32 table at DLL VA 0x10023db8 (the read(3) branch of the 8 kHz gain index)
EXC_Q = (0.06112999841570854, 0.16354599595069885, 0.3104130029678345,
         0.4282200038433075, 0.55588698387146, 0.7190549969673157,
         0.9386940002441406, 1.326874017715454)

# double at DLL VA 0x10023ee8, used as `fmul QWORD PTR ds:0x10023ee8` for the 2nd pass
CB2_RATIO = 0.45454545454545453          # == 5/11
```

### 6.2 Replace `Codec210.exc_gain` (currently lines ~353-366)

```python
    def exc_gain(self, g8, b3, gden=None):
        """Exact 8 kHz innovation gain (measured; see specs/GainLaw.md).

        The decoder computes, once per frame:
            X    = (float)exp((double)g8 / 3.5)     ; VA 0x10009993..0x100099b1
            gain = (float)(EXC_Q[b3] * X)           ; VA 0x10009d18..0x10009d52
        `g8` is the 5-bit frame energy (`parse_frame["energy8"]`), `b3` the 3-bit
        sub-frame field (`sub8[sf][2]`, == the decoder's read(3) gain index).
        The `gden` LPC-tilt factor does not exist for this stage and is ignored.
        """
        X = _f32(math.exp(g8 / 3.5))
        return self.exc_scale * _f32(EXC_Q[b3 & 7] * X)
```

### 6.3 `Codec210.decode_frame` — one verbatim hunk

Delete these 8 lines (they compute the bogus `gden`; the comment is stale):

```python
            # LPC tilt terms used by the innovation gain (FUN_10009520)
            lsf_i = lsf_stabilise(lsf_interp(self.lsf8_prev, f["lsf10"], 10, sf, 4), 0.05)
            a = lsf_to_lpc(lsf_i)
            sump = sum(a[i] + a[i + 1] for i in range(0, len(a) - 1, 2))
            sumd = sum(a[i + 1] - a[i] for i in range(0, len(a) - 1, 2))
            gden = (sump + 0.01) / (0.01 + sumd) if sumd else 1.0
            gain = self.exc_gain(g8, b3, gden)
```

and put in their place

```python
            gain = self.exc_gain(g8, b3)              # exact law, float32
```

then replace

```python
            exc = [ltp[i] + gain * cb1[i] + (gain / 2.2) * cb2[i] for i in range(40)]
            self.buf[p:p + 40] = exc
```

with

```python
            g1 = gain                                 # float32 (exc_gain)
            g2 = _f32(g1 * CB2_RATIO)                 # float32, exact 5/11
            for i in range(40):                       # float32 store per sample,
                v = _f32(ltp[i] + _f32(g1 * cb1[i]))
                self.buf[p + i] = _f32(v + _f32(g2 * cb2[i]))
```

(The scalar `2.2` was a fitted approximation of `1/0.45454545454545453`; it is right to
2e-16 in double, so that part is a correctness-of-form change. The float32 rounding *is*
significant: the excitation buffer is the adaptive-codebook history, and the DLL rounds every
stored sample to float32, which the old list-comprehension did not.)

`exc_scale` stays as-is (it is an output-domain calibration unrelated to this law).

One further fidelity note on the same recursion (not part of the gain law, but it costs one
`_f32` call): the DLL's LTP output is stored as float32 too (the four `fstp DWORD` stores at
`0x10006f94/0x10006fb2/0x10006fd4/0x10006ff7`), so returning
`[_f32(g[2]*S[i] + g[1]*S[40+i] + g[0]*S[80+i]) for i in range(40)]` from `Codec210.ltp()`
matches the emulator bit-for-bit where the current double-precision return matches only to
~1e-7. Since `self.buf` *is* the adaptive-codebook history for the next sub-frame (and the next
frame), that rounding is visible in long recursions.

### 6.4 Delete

* the old `q = (0.147, 0.382, 0.69, 1.0, 1.30, 1.679, 2.39, 3.098)` tuple in `exc_gain`,
  the `0.430 * 1.3305 ** g8` expression and the `gden` parameter's dead computation (superseded
  by `EXC_Q` / `_f32(math.exp(g8/3.5))`).

---

## 7. Notes / why the old fit drifted

* The 8 kHz innovation is the only consumer of `C(g8)`; both codebook passes use the *same*
  `gain` (the second scaled by the exact double `5/11`), so there is exactly one place to fix.
* The old `gden` normaliser was derived from the 32 kHz band's decompilation and does not exist
  in `FUN_10009520`. It was already removed from the value but is still computed in
  `decode_frame`; it can go.
* The fit failed in two independent ways (§3.3): base `1.3305` vs `exp(1/3.5) = 1.3307121992`
  (−0.016%/step, i.e. +0.5% by `g8 = 31`) and the constant `0.430` = `q_true[3]` (a 2.3256×
  scale error absorbed into the fitted `q`). At the three frames the fit was tuned on
  (`g8 = 27` over three frames, per `Codec210.md` §10.6/§10.8) both errors partly cancelled, and
  the ramp between `g8 = 27` and `g8 = 0` was never exercised — which is exactly the
  `g8`-dependent error that accumulates in the recursive excitation loop.
* No other hidden factor is applied to the coded innovation: the increment/codebook projection is
  exact to float32 (≤1.15e-07) for all 284 sub-frames, so the `if (obj[+8] != 0)` scaling block at
  `0x10009c12`, if it ever fires, only rescales the LTP output (it cancels out of the increment).

## 8. Reproduce

Probe (throwaway, uses the oracle): `/tmp/gl_measure.py <first> <last> <out.json>`
with `/tmp/uv/bin/python`; it installs the code/write hooks listed in §2.1 and writes one JSON
record per sub-frame (fields: `g8, b3, idx_read, path, gain (real arg), X, gain_meas_cb1,
gain_meas_cb2, resid_cb1, resid_cb2, ...`). The full run for frames 0..70 used here:
`/tmp/uv/bin/python /tmp/gl_measure.py 0 70 /tmp/gl_meas.json` (~60 s).
The `exp` table in §3.3 was read by calling VA `0x10011aec` from a stub
`fild dword [esp+4]; fdiv qword [0x10023e70]; call 0x10011aec; fstp dword [scratch]; ret`.


---

# APPENDIX: specs/APath.md

# specs/APath.md — the A path: `8 kHz synthesis → A16 → A32 → out = 2·(A32 − B32)`

Status: **measured against the real `LTTS7Codec210.dll` under Unicorn** (tools/codec210_oracle.py).
Verdict: `band_filter` (FUN_10003960) is **amplitude-correct (exact factor ½ per call)**; every real
band-filter call is reproduced with **corr 1.000000**. The port's quietness is **not** a filter-gain
bug — it is one **missing ×2** stage in the middle of the chain: the 16 kHz level's reconstruction
`out16 = 2·(A16 − B16)` is never formed, so the second `band_filter` is fed `A16` instead of `2·A16`.
With `B16 = B32 = 0` the port is **exactly 2× too small**; the non-constant end-to-end ratios
(1.8× / 2.4× / 5.7×) come from the port's own 8 kHz synthesis (upstream of this path), not from the
A path.

Also answered: **the 16 kHz coded branch does NOT contribute to the A16 input.** The A16 filter input
is *bit-for-bit the 8 kHz core LPC-synthesis output* (corr `+1.000000`, equal rms). The 16 kHz branch
feeds the **B16** (high-band) filter instead.

---

## 1. What was measured and how

Instrumentation: `tools/codec210_oracle.py`'s `Oracle`, plus `UC_HOOK_CODE` hooks on the exact `call`
opcodes (found with `objdump -d -M intel`). At a `call` instruction ESP still points at the first
stack argument. Call-site semantics (confirmed disassembly vs. observed values):

* `FUN_10003960` is **`__cdecl`**; at the call, `[ESP+0]=src  [ESP+4]=coef  [ESP+8]=dst
  [ESP+12]=outcount(int, = 2·len(src))  [ESP+16]=64 (ntaps)  [ESP+20]=tail  [ESP+24]=work`.
  (Ghidra's signature `FUN_10003960(int src,int coef,int dst,float outcount,int ntaps,int tail,
  undefined4 *work)`; `outcount` is an **int**, not a float.)
* `FUN_1000c290` is **`__fastcall`**: `ECX = out`, `EDX = A`, `[ESP+0] = B`;
  `out[i] = clamp(round(2·(A[i]−B[i])))` — the ×2 is the double constant `_DAT_10022e58 = 2.0`.

Hooked sites (all inside `FUN_1000e170`, the per-level band driver):

| site | role |
|---|---|
| `0x1000e87b` | A filter (`coef = 0x100240a8`) |
| `0x1000e898` | B filter (`coef = 0x100241a8`) |
| `0x1000e8ae` | combine `FUN_1000c290` |

`FUN_1000e170` is called **twice per frame**: first with the 16 kHz object (`esi=0x30007fe0`),
then with the 32 kHz object (`esi=0x300021a0`) — so **4 band-filter calls + 2 combines per frame**.
(The other two groups of identical call sites, `0x1000e118/…` in `FUN_1000def0` and `0x1000e300/…`
inside `FUN_1000e170`'s `mode==0` branch, **never fire** on frames 0–39; the live path is
`0x1000e87b/0x1000e898` only.)

Procedure: decode frames 0…39 with the oracle, and at the hooked sites capture the arguments, the
`tail` contents *before* the call, and a snapshot of the whole working heap
(`0x3000d000..0x30019000`). Frames 37/38/39 were then analysed as follows: (a) each real filter call
was replayed through the port's `band_filter()` with the real `src`+`tail`; (b) the port's
`Codec210` was instrumented (throwaway copy) to dump `sig8`, `a16`, `a32`.

## 2. Measured buffer wiring (frames 37–39)

Object fields read from `esi` at the combine calls (`+0x8` = outcount, `+0xc` = filter input len,
`+0x10` = sub-frame, `+0x14` = 4 sub-frames, `+0x20` = rate):

| 16 kHz object `0x30007fe0` (rate 16000, 320 out) | 32 kHz object `0x300021a0` (rate 32000, 640 out) |
|---|---|
| `+0x2c = 0x30012a30`  A input (= ring1 head) | `+0x28 = 0x30002220`  **ring = the 16 kHz combine output buffer** |
| `+0x34 = 0x30012f30`  B input (16 kHz LPC synth) | `+0x2c = 0x30014380`  A input (= copy of `ring[0:320]`) |
| `+0x38 = 0x30013430`  A out  (= **A16**) | `+0x34 = 0x30014d80`  B input (32 kHz LPC synth) |
| `+0x3c = 0x30013930`  B out  (= **B16**) | `+0x38 = 0x30015780`  A out (= **A32**) |
| `+0x40/+0x44 = 0x30013e30/0x30013f30` tails | `+0x3c = 0x30016180`  B out (= **B32**) |

At the top of `FUN_1000e170` the object copies `ring[0 : +0xc]` into `+0x2c`. For the 32 kHz object
`ring = 0x30002220`, which is exactly the buffer the **16 kHz combine wrote one step earlier**, so the
32 kHz A-filter input is the *current frame's* 16 kHz reconstruction (no delay).

Wiring verified (frames 37/38/39):

| relation | corr | rms ratio |
|---|---|---|
| `A16` input (`0x30012a30`) vs the 8 kHz core LPC-synthesis output (`o8+0x30 = 0x30011ea0`) | **+1.000000** | **1.000000** |
| `A16` input vs the 16 kHz branch synth `0x30012f30` | +0.107 / +0.064 / −0.077 | — |
| 32 kHz ring head `0x30002220[0:320]` vs `2·(A16−B16)` | **+1.00000000** | **1.000000** |
| `2·(A32−B32)` vs the oracle PCM | +0.99999997 / +1.0 / +1.0 (max abs diff **0**) | 1.000000 |

⇒ the chain is a **two-level QMF tree**, each level `out = 2·(A − B)` :

```
                    8 kHz core LPC synthesis (o8+0x30, 160)
                          │                       │  ── the 16 kHz coded branch ──┐
                    A16 = bf(cfA, 320)      B16 = bf(cfB, 320) ◄───────────────┘
                          └────────── out16 = 2·(A16 − B16)  (320, = ring[0:320]) ──┐
                    A32 = bf(cfA, 640)      B32 = bf(cfB, 640) ◄── 32 kHz branch ──┘
                          └────────── pcm  = 2·(A32 − B32)      (640)
```

**The port's assumption "A32 = band_filter(A16)" is wrong**: the 32 kHz A-filter input is the
*combined 16 kHz signal* `out16 = 2·(A16 − B16)`, not `A16` itself. (This also corrects the framing
in the task: the "16 kHz object's `+0x38`" is `A16` = the low-band filter output; the actual input of
the 32 kHz band filter is `out16 = 2·(A16−B16)`, i.e. the 32 kHz object's `+0x28/+0x2c`.)

## 3. Per-stage tables (real DLL, frames 37/38/39)

RMS of every stage (from the heap snapshots):

| f | sig8 (A16 in) | A16 | B16 | synth16 | out16 | A32 | B32 | synth32 | pcm |
|---|---|---|---|---|---|---|---|---|---|
| 37 | 2775.82 | 605.85 | 178.79 | 442.51 | 1262.11 | 617.50 | 83.24 | 181.78 | 1246.60 |
| 38 | 4088.00 | 2384.16 | 159.41 | 184.30 | 4779.32 | 2381.98 | 53.31 | 82.38 | 4765.15 |
| 39 | 5111.09 | 2549.55 | 92.30 | 184.48 | 5102.34 | 2539.10 | 30.64 | 54.90 | 5078.49 |

Per-call gain `rms(dst)/rms(src)`:

| call | f37 | f38 | f39 |
|---|---|---|---|
| A16 ← sig8 | 0.2183 | 0.5832 | 0.4988 |
| B16 ← synth16 | 0.4040 | 0.8649 | 0.5003 |
| A32 ← out16 | 0.4893 | 0.4984 | 0.4976 |
| B32 ← synth32 | 0.4579 | 0.6471 | 0.5581 |

Net level gains: `pcm/A16` = 2.058 / 1.999 / 1.992 ; `A32/A16` = 1.019 / 0.999 / 0.996.
The A16 ratio varies per frame (0.22 at the frame-37 silence→speech transient) because the filter
spreads an in-frame transient across the frame boundary (energy is conserved over *contiguous*
frames, not per window); the average over frames 37–39 is √((0.2183²+0.5832²+0.4988²)/3) = 0.460.

Shape (already known, re-confirmed): every one of the 4 real calls is reproduced by the port's
`band_filter()` with the real `src`+`tail` at **corr 1.000000** (max abs diff 8e-5 … 3e-3).

## 4. The exact gain of one `FUN_10003960` call

Fed the port's `band_filter()` with long (N=2048…4096) stationary inputs and `tail=0`, using the real
coefficient tables `0x100240a8` (=A) and `0x100241a8` (=B):

* `|H_A| = |H_B| = 0.4979 … 0.5015` for **every** input frequency swept (f/fs = 0.0005 … 0.4995;
  measured with cosines, steady-state rms ratio);
* DC input: `A → 0.49998`, `B → 0.00000` (Σh_A = 0.999967, Σh_B = 0.000000, Σ|h_A| = Σ|h_B| =
  1.982200);
* the A and B tables are the same 64-tap prototype with alternating taps negated.

**⇒ the exact factor of one call is ½** (flat amplitude response; the ÷2 is the polyphase
upsampling factor). The level combine `×2` is what restores the level's amplitude, so **each QMF
level is amplitude-preserving** and the two-level A path is amplitude-transparent:
`pcm/A16 ≈ 2.0` (measured 2.058 / 1.999 / 1.992).

Therefore a correct A path must contain **two** `×2` factors (one per level). `tools/codec210.py`
currently contains only the final one → **its output is exactly 2× too small** whenever
`B16 = B32 = 0` and the upstream 8 kHz synthesis is right.

## 5. Does the 16 kHz coded branch contribute to the A16 input?

**No.** The 16 kHz object's A-filter input (`0x30012a30`) is bit-for-bit the 8 kHz core
LPC-synthesis output (`0x30011ea0`): corr **+1.000000**, rms 605.85/2384.16/2549.55 identical to
7 digits, and it is uncorrelated with the 16 kHz branch synth (`0x30012f30`). The 16 kHz coded
branch is the **B16** input (high band), which the combine *subtracts*.

## 6. Minimal patch for `tools/codec210.py`

Function `Codec210.decode_frame`, the A-path block (currently the last ~7 lines). **Only insertion:
form `out16 = 2·a16` before the second `band_filter`.** Nothing else changes (the final
`2.0 * a32` already supplies the second ×2).

```python
        # ---- 8 kHz synthesis -> A16 -> out16 -> A32 -> out = 2*(A32 - B32) ----
        sig8 = self.synth8(f["lsf10"])
        a16 = band_filter(sig8, self.cf_a, 320, 64, self.tail_a16, [0.0] * 1088)
        # 16 kHz QMF reconstruction: out16 = 2*(A16 - B16).  B16 (the 16 kHz coded
        # branch) is not ported yet -> 0.  Skipping this factor made the output
        # exactly 2x too small (see specs/APath.md).
        out16 = [2.0 * v for v in a16]
        a32 = band_filter(out16, self.cf_a, 640, 64, self.tail_a32, [0.0] * 2048)

        # B32 (the 32 kHz noise branch) is not ported; A dominates the output.
        pcm = [clamp_int16(2.0 * v) for v in a32]
```

Equivalent one-liner (the filter is linear and its tail state is scaled consistently):
`a32 = band_filter([2.0 * v for v in a16], self.cf_a, 640, 64, self.tail_a32, [0.0] * 2048)`.

Do **not** compensate this missing ×2 with `exc_scale`: the ×2 belongs to the synthesis path and does
not exist in the excitation, so scaling `exc_scale` would corrupt the adaptive-codebook history
(`self.buf`) and change the waveform. Keep `exc_scale = 1.0` (the measured excitation amplitudes are
already the real decoder's; see §10.6 of `Codec210.md`).

`__init__`/`reset` can stay as-is (only the two A tails are needed while `B16 = B32 = 0`). When the
upper bands are ported, add `self.cf_b = T["band_filters_qmf"]["bandB_64tap"]["f32"]`,
`self.tail_b16`/`self.tail_b32` and the two lines
`b16 = band_filter(synth16, self.cf_b, 320, 64, self.tail_b16, work)` /
`b32 = band_filter(synth32, self.cf_b, 640, 64, self.tail_b32, work)`, then use
`out16 = [2.0*(x-y) for x, y in zip(a16, b16)]` and `pcm = [clamp_int16(2.0*(x-y)) for x, y in
zip(a32, b32)]`.

## 7. Acceptance

**(a) Stage-local, port's A path fed the real 8 kHz synthesis output** (isolates the A path):

| stage | corr(port, real) | rms ratio |
|---|---|---|
| `a16` vs real `A16` (f37/38/39) | **+1.000000** | **1.000000** |
| `a32` old (`bf(a16)`) vs real `A32` | +0.9578 / +0.9963 / +0.9952 (identical to the patched corr: the difference is a pure 2× scale) | 0.479 / 0.498 / 0.498 |
| `a32` **patched** (`bf(2·a16)`, B16=0) vs real `A32` | +0.9578 / +0.9963 / +0.9952 | 0.958 / 0.996 / 0.995 |
| `a32` patched fed the real `out16` (= with B16) vs real `A32` | **+1.00000000** | **1.000000** |

The residual at f37 is entirely the **unported B16** (`2·bf(B16)`, B16 rms 179 vs A16 606); with B16
supplied the A32 is exact.

**`rms(2·A32)` after the patch vs the real PCM:**

| f | patched `rms(2·A32)` | real `rms(pcm)` | ratio | corr vs real PCM |
|---|---|---|---|---|
| 37 | 1183.02 | 1246.60 | 0.949 | +0.9493 |
| 38 | 4745.85 | 4765.15 | 0.996 | +0.9961 |
| 39 | 5053.62 | 5078.49 | 0.995 | +0.9951 |

(fed the *emulator's* 8 kHz synthesis; `B16 = B32 = 0`)

**(b) End-to-end port** (its own, still-imperfect 8 kHz synthesis; frames 0…39 carried):

| f | port `rms(pcm)` OLD | port `rms(pcm)` PATCHED | real `rms(pcm)` | real/OLD | real/PATCHED |
|---|---|---|---|---|---|
| 37 | 675.92 | 1352.27 | 1246.60 | 1.844 | 0.922 |
| 38 | 1954.43 | 3909.15 | 4765.15 | 2.438 | 1.219 |
| 39 | 890.91 | 1782.16 | 5078.49 | 5.700 | 2.850 |

The pre-patch ratios reproduce the ticket's **1.8× / 2.4× / 5.7×** exactly. After the patch the
remaining error is dominated by the port's 8 kHz synthesis, not the A path: with the port's own
`sig8`, `corr(a16_port, A16_real)` = 0.746 / 0.709 / 0.330 and `rms(sig8_port)/rms(sig8_real)` =
0.922 / 0.808 / 0.338 — i.e. the 8 kHz chain (LTP/excitation history, §10.9 of `Codec210.md`) is the
next blocker, together with `B16`/`B32`.

## 8. Remaining A-path gap (not this task)

`B16 = band_filter(synth16, 0x100241a8, …)` and `B32 = band_filter(synth32, 0x100241a8, …)` are the
only unportable inputs; they need the 16 kHz coded branch and the 32 kHz branch syntheses
(inputs `0x30012f30` = `esi(16k)+0x34`, outcount 320, and `0x30014d80` = `esi(32k)+0x34`, outcount
640). With them the A path closes at corr 1.000000 / max-diff 0 (verified end to end above).

## 9. Reproduce

* `/tmp/measure4.py` — oracle hooks, heap snapshots + tail capture → `/tmp/snaps2.json`
* `/tmp/measure3.py` — L1-call snapshot of the 8 kHz synth → `/tmp/snaps_apath.json`
* `/tmp/analyze2.py`, `/tmp/analyze4.py` — per-call replay, wiring correlations, stage tables
* `/tmp/run_port.py` — runs `tools/codec210.py` and `/tmp/codec210_patched.py`, dumps
  `sig8/a16/a32/pcm` per frame
* `/tmp/verify_combine.py` — `out = clamp(round(2·(A32−B32)))` vs the oracle PCM (max diff 0)

(Run all of them with `/tmp/uv/bin/python`.)


---

# APPENDIX: specs/UpperBands.md

# Codec 210 — the two upper sub-bands: the 16 kHz *coded* band (B16) and the 32 kHz *noise* band (B32)

Scope: port the two branches that stand between the (now exact) 8 kHz core and the PCM:
the **16 kHz coded band** (which produces `B16`) and the **32 kHz noise band** (which
produces `B32`), plus the exact re-combination of the four-QMF-level tree.
Everything below was measured by running the real `LTTS7Codec210.dll` under Unicorn
(`tools/codec210_oracle.py`) and by re-implementing the two functions in Python and
comparing buffers **exactly** (`tools/`-independent scripts under `/tmp/ub_*.py`).

Status: **CLOSED** — every stage of both bands reproduces the real DLL's own buffer with
correlation **1.000000** (frames 37/38/39: `exc16`, `o16[+0x34]`, `out16=2*(A16-B16)`,
`exc32`, `o32[+0x34]`, `B32`, `A32`).  Applying the patch of §6 verbatim to the current
`tools/codec210.py` gives, against the oracle producing the same 300 frames:
**frames 0..299 PCM corr = 0.997496, rms ratio 0.9910** (frames 37/38/39 =
0.999999/1.000000/1.000000, `exc16` corr = 1.000000).  The residual is (a) ±1 LSB int16
rounding (two independent implementations of the same formulas differ from each other and
from the DLL only in which side of the `(int16)(v+0.5)` boundary the sub-LSB float rounding
order lands) and (b) the 8 kHz chain's own residual on a few frames (e.g. frame 120, where
the *8 kHz* excitation itself is corr 0.922, `sig8` 0.636 — not an upper-band error; the
upper bands then track it at 0.9992/0.9994).  The near-silent frames 0..36 have max abs
sample difference = **1** LSB over all 640 samples.

---

## 1. Where the two bands live (measured object/buffer map)

The decoder instance for 32 kHz is a three-level object chain, built by `FUN_1000db20`:
`ctx+0x28 = o32`, `o32[+0x04] = o16`, `o16[+0x04] = o8`.  Each object is 0x74 bytes and owns
its own `calloc`'d buffers (addresses as observed for the Jorge DB, `ctx = 0x30000010`):

| field | o32 (`0x300021a0`) | o16 (`0x30007fe0`) | o8 (`0x3000de20`) | meaning |
|---|---|---|---|---|
| `+0x08` | 640 | 320 | 0 | `2*samples/sub-block` |
| `+0x0c` | 320 | 160 | 160 | count (samples per object per frame) |
| `+0x10` | 80 | 40 | 40 | samples per sub-block |
| `+0x14` | 4 | 4 | 4 | sub-blocks per frame |
| `+0x18` | 8 | 8 | 10 | LPC order |
| `+0x24` | 0 | 0 | 8000 | rate (0 for the 16/32 kHz classes → **plain** LPC synthesis; the 8 kHz class has 8000 here → its expanded path) |
| `+0x28` | `0x30002220` | `0x30008060` | — | per-object scratch (24000 B): `[0..4*count) = child output mailbox`, then the child tilt / block2 / block3 |
| `+0x2c` | `0x30014380` | `0x30012a30` | — | copy of the child-output mailbox (= the child level's final signal) |
| `+0x34` | `0x30014d80` | `0x30012f30` | `0x30011ea0` | **this level's LPC synthesis output** (the B source) |
| `+0x38` | `0x30015780` | `0x30013430` | — | A output (band filter of `+0x2c` with coefA) |
| `+0x3c` | `0x30016180` | `0x30013930` | `0x30012364` (o8: excitation) | B output / excitation |
| `+0x40`,`+0x44` | `0x30016b80`,`0x30016c80` | `0x30013e30`,`0x30013f30` | — | QMF tails for A / B |
| `+0x48` | `0x30016d80` | `0x30014030` | `0x300128d0` | **this level's excitation** |
| `+0x4c`,`+0x50`,`+0x54` | `0x30017280`,`0x300172a0`,`0x300172c0` | `0x300142b0`,`+20`,`+40` | — | current LSF / previous LSF / interpolated LSF |
| `+0x58`,`+0x5c`,`+0x60` | `0x300172e0`,`0x30017310`,`0x30017300` | `0x30014310`,`0x30014340`,`0x30014330` | (o8: scalars / `0x30012a20` tilt) | LPC / LPC state / per-sub-frame tilt |
| `+0x68`,`+0x6c`,`+0x70` | 1, `0x10023cd0`, mode | 1, `0x10023c20`, mode | 1, …, mode | read-mode flag, mode array, current mode |

Mode arrays (only non-null entries listed):

* 32 kHz `0x10023cd0` = `[0, 0x10023a70, 0, …]` → the Jorge stream's 32 kHz mode is **1**
  → mode object `0x10023a70`, whose `+0x28 == 0` selects the **noise branch**;
* 16 kHz `0x10023c20` = `[0, 0x10023a70, 0x10023ae8, 0x10023b60, 0x10023bb0, 0,0,0]` →
  the Jorge stream's 16 kHz mode is **4** → mode object `0x10023bb0`
  (`+0x28 = FUN_100029c0`, `+0x2c = 0x10023a5c`, `+0xc = 1` → **two** codebook passes);
* 8 kHz mode array `0x100239ec/f0` → mode 7 → `0x100238f8`.

Both upper levels run the *same* function `FUN_1000e170` (`obj`, `ctx` = the bit reader,
`arg3` = the mailbox/out pointer).  It (1) recursively decodes its child
(`FUN_1000f530`, in the reverse order of the bit stream: 8 kHz → 16 kHz → 32 kHz),
(2) copies the child mailbox to `obj+0x2c`, (3) reads its flag+3-bit mode
(`read1`+`read(3)`, always 1/4 and 1/1 for this stream), (4) the 2-stage order-8 LSF VQ
(`modeObj[+0x14]` = `FUN_1000c0d0`), (5) a 4-sub-block loop, (6)
`A = band_filter(obj+0x2c, 0x100240a8, obj+0x38, outcount, 64, tail obj+0x40, work)`,
`B = band_filter(obj+0x34, 0x100241a8, obj+0x3c, outcount, 64, tail obj+0x44, work)`,
`FUN_1000c290(out, A, B)` = `out[i] = clamp_f32(2*(A[i]-B[i]))` (store instructions
`0x1000e87b`/`0x1000e898`/`0x1000e8ae`; writes to `+0x34` at `0x1000e7ca`, to `+0x48` at
`0x1000e65b` / `0x1000e7ab`).

### 1.1 The sub-object scratch/parameter protocol (`FUN_1000f550(sub, cmd, buf)`)

At the top of `FUN_1000e170` the parent asks its **child** for three buffers, placed into
the parent's own scratch (measured: `base = obj[+0x28] + 4*obj[+0xc]`):

| cmd | destination | handler (16/32 kHz class, `FUN_1000f0e0` @ `0x1000f34a/0x1000f374/0x1000f3b5`) | handler (8 kHz class, `0x1000a820` @ `0x1000a9da/0x1000aa04/0x1000aa27`) |
|---|---|---|---|
| 100 (`0x64`) | `base` | copy `obj[+0x60][0..3]` → the **child's tilt array** | copy `obj[+0x58][0..3]` → the 8 kHz tilt array |
| 101 (`0x65`) | `base+0x10` ("block2") | `dst[0..2*obj[+0xc]) = 0` then `dst[2i] = 2.0*obj[+0x48][i]` (×2, zero-interleaved upsample) | plain copy `dst[i] = obj[+0x3c][i]` (the **8 kHz excitation**, 160 floats, no ×2) |
| 102 (`0x66`) | `base+0x10+4*obj[+0xc]` ("block3") | same as 101 | plain copy `dst[i] = obj[+0x40][i]` |

The two class handlers are **different code** — this is the single most easily-missed fact
in the whole chain:

* the **16 kHz** level's own energy comes from **block2 = a plain copy of the 8 kHz
  excitation** (`o8+0x3c`), because the child is the *8 kHz* object;
* the **32 kHz** level's noise source comes from **block3 = `2 * o16[+0x48]`
  zero-interleaved** (320 floats), because the child is the *16 kHz* object.

Measured proof: `o32` scratch block2/block3 (`0x30002730`/`0x30002c30`) =
`[886.774, 0, 1232.832, 0, 724.559, 0, …]` = `2*[443.387, 616.416, 362.280, …]` = exactly
`2*exc16` at the even positions (`exc16 = [443.387, 616.416, 362.280, …]`), while the
16 kHz energy probe reads `p = 0x300082f0 + 160*sf` (a plain copy of `o8[+0x3c]`).

---

## 2. Bit fields consumed (already parsed by `tools/codec210.py`)

The frame layout (880/880 bits, verified) already exposes all four fields:

| band | field | width | `parse_frame` key |
|---|---|---|---|
| 16 kHz | flag + mode | 1 + 3 | `f["f16"]`, `f["mode16"]` (4 for Jorge) |
| 16 kHz | LSF 2 × 6 | 12 | `f["lsf16"]`, `f["lsf16_idx"]` |
| 16 kHz | per sub-block: gain, 10 × (sign, 7-bit index) | 4 + 10·8 | `f["sub16"][sf] = (g4, [(sign, idx)×10])` |
| 32 kHz | flag + mode | 1 + 3 | `f["f32"]`, `f["mode32"]` (1 for Jorge) |
| 32 kHz | LSF 2 × 6 | 12 | `f["lsf32"]`, `f["lsf32_idx"]` |
| 32 kHz | per sub-block: 5-bit noise index | 4 × 5 | `f["ref32"] = [idx5 × 4]` |

Order inside a frame: 8 kHz core (492 bits) → 16 kHz flag/mode/LSF/sub-blocks → 32 kHz
flag/mode/LSF/4×5 bits.  For the 16 kHz sub-blocks the **first 5 (sign,idx) pairs are the
first codebook pass and the last 5 the second pass** (`FUN_100029c0` reads them in order).

---

## 3. The 16 kHz coded band

Per sub-block `sf` (order 8, 40 samples):

1. **LSF**: `lsf = lsf_stabilise(lsf_interp(prev, cur, 8, sf, 4), 0.05)`,
   `lpc = lsf_to_lpc(lsf)` (both already in the port).  The frame's `prev` is the previous
   frame's `cur`; on the **first** frame `prev := cur` (the `obj[+0x1c]` copy at
   `0x1000e3e8`, *after* the LSF VQ) — measured: at frame 0 all four sub-blocks have the
   same LPC (`tilt16 = 1.54544` constant).
2. **tilt**: `s(lpc) = 1 + Σ_{i even<8}(lpc[i]+lpc[i+1])`,
   `d(lpc) = 1 + Σ_{i even<8}(lpc[i+1]-lpc[i])`.
   `s` is stored in `obj[+0x60]` (the child tilt for the 32 kHz level); the 8 kHz level's
   own tilt array (`obj8[+0x58]`, seen by cmd 100) is `d(lpc8)` — the loop at
   `0x10009b30..0x10009b65` computes `1 + Σ(lpc[i+1]-lpc[i])`.
3. **energy** (`FUN_10002ec0(p, n)`, VA `0x10002ec0`):
   `E = sqrt( Σ_{i<n} p[i]² / n + 0.1 )` (the `0.1` is the double at `0x10022120`;
   the plain `Σx²` reading in the old §10.4 was incomplete — the function also divides by
   `n`, adds 0.1 and takes a square root at `0x100105c0`).
   `p = block2 + 4*obj[+0x10]*sf` = **the 8 kHz excitation at that sub-block**
   (`o8[+0x3c]`, 40 samples), `n = 40`.
4. **gain**: `gg = exp(g4 * 0.27027027027 - 0.15556)` (doubles at `0x100242b0`/`0x100242c0`;
   the library call `FUN_10011aec` on that argument returns `exp` — measured: the four
   frame-38 gains reproduce the DLL's internal ones to ≤0.05 %),
   `norm16 = (d_tilt8[sf] + 0.01) / (0.01 + d(lpc16_sf))`,
   `gain = (E + 1.0) * (gg / norm16)`.
5. **codebook** (`FUN_100029c0` with descriptor `0x10023a5c` = `{dim 8, count 5,
   table VA 0x10022470, bits 7, sign 1}`, scale `0.03125` (double `0x10021260`),
   sign multiplier `-1.0` (float `0x10021268`)):
   pass 1 = `v1 = 5 vectors` (40 samples, `v1[j*8+i] += ±table[idx*8+i]/32`),
   pass 2 = `v2` from the last 5 pairs (the mode object's `+0xc = 1` enables it), scaled by
   `0.4` (double `0x10023660`):
   `exc16 = v1*gain + v2*(gain*0.4)`.
   The table row 43 is **all zeros** — the encoder's silence codeword (frame 0, first three
   sub-blocks).
6. **synthesis**: plain `FUN_100030e0(lpc, state, x, 40, 8)` in place (because
   `obj[+0x24] == 0`; the `FUN_10002f80` 3-filter path is *not* taken for the upper bands);
   `state = obj[+0x5c]` is 8 floats and carries across sub-blocks and frames.
   Output `o16[+0x34]`.

Measured table (frame 38, `tools/codec210_oracle.py` vs the Python re-implementation):

| sf | g4 | `E` (mine) | `gg` | `norm16` | gain (mine) | gain (measured in the DLL) |
|---|---|---|---|---|---|---|
| 0 | 0 | 1272.7 | 0.855936 | 2.52055 | 432.526 | **432.573** |
| 1 | 1 | 431.24 | 1.12155 | 3.95995 | 122.42 | **122.42** |
| 2 | 0 | 3429.07 | 0.855936 | 6.79812 | 431.872 | **432.02** |
| 3 | 2 | 601.52 | 1.46959 | 13.2961 | 66.595 | **66.6155** |

The gains were read *inside the DLL* at the `FUN_10002da0` call site (`0x1000e70a`,
`param_3`); the residual ≤0.05 % is float32-vs-double rounding.
For frames 37/38/39, feeding the DLL's own 8 kHz excitation/tilt/LPC state into the Python
code gives `exc16`, `o16[+0x34]`, `B16`, `out16` and the DFT `A16` at **corr 1.000000**.

---

## 4. The 32 kHz noise band

Per sub-block `sf` (order 8, 80 samples):

1. LSF/LPC exactly as above but with the 32 kHz LSF fields (`prev`/`cur` per frame, first
   frame `prev := cur`).
2. `norm32 = (s(lpc16_sf) + 0.01) / (0.01 + d(lpc32_sf))` — the *numerator* is the
   **16 kHz** level's `s` tilt (the value the 16 kHz level stored in `obj[+0x60]` and that
   its parent read via cmd 100).
3. `gain5 = exp((idx5 - 10) * 0.125)` (`idx5 = f["ref32"][sf]`, doubles `0x10022e10 = 10.0`
   and `0x10024300 = 0.125`; `ln(gain5)` measured exactly `0.125, 1.75, -1, 2` for frame 38
   → `idx5 = 11, 24, 2, 26`).  `amp = gain5 / norm32`.
4. source: `src = block3` = `2 * exc16` zero-interleaved (320 floats, `src[2i] = 2*exc16[i]`).
5. per sample `i = 0..79`:
   `exc32[80*sf+i] = ((ramp*amp) * 0.7) * src[80*sf+i]`, `ramp *= -1.0`
   (`ramp` starts at `1.0` for every sub-block; the factor `0.7` is `*(float*)(0x10023ca8+0x24)`
   = `0.699999988079071`; the ramp constant is the double `-1.0` at `0x100242f8`).
   (So the "noise" is a sign-alternating, per-sub-block-gain-scaled band replication of the
   16 kHz excitation — this is what fills the 16–32 kHz band and provides the silence
   noise floor: in silence `exc16` is zero except for the sub-blocks with a real codeword.)
6. synthesis: plain `FUN_100030e0` in place, state `obj[+0x5c]`.

Measured table (frame 38; the norms were read inside the DLL at `0x1000e623` as
`[esp+0x1c]`, the gains at `0x1000e602`):

| sf | idx5 | ln(gain5) | gain5 (mine) | gain5 (DLL) | norm32 (mine) | norm32 (DLL) |
|---|---|---|---|---|---|---|
| 0 | 11 | 0.125 | 1.133148 | **1.13315** | 6.51341 | 6.51323 |
| 1 | 24 | 1.75 | 5.754603 | **5.7546** | 6.83603 | 6.83571 |
| 2 | 2 | −1.0 | 0.367879 | **0.367879** | 7.10982 | 7.10934 |
| 3 | 26 | 2.0 | 7.389056 | **7.38906** | 7.30798 | 7.3074 |

With the DLL's own `exc16` injected, the Python code reproduces `exc32` (`o32[+0x48]`),
`o32[+0x34]` and `B32` at **corr 1.000000** on frames 37/38/39.

---

## 5. The recombined chain (all four levels)

```
o8: exc8 = LTP + CB1 + CB2                      (now exact in tools/codec210.py)
    sig8 = LPC_order10(exc8)                    = o8[+0x30]
o16: exc16 = gain16*(v1 + 0.4*v2)               (section 3)
    b16  = LPC_order8(exc16)                    = o16[+0x34]
    A16  = band_filter(sig8, coefA, 320, 64, tail o16[+0x40], work)
    B16  = band_filter(b16 , coefB, 320, 64, tail o16[+0x44], work)
    out16 = clamp_f32(2*(A16 - B16))            = the 32 kHz level's mailbox (32k obj+0x2c)
o32: exc32 = noise branch (section 4)
    b32  = LPC_order8(exc32)                    = o32[+0x34]
    A32  = band_filter(out16, coefA, 640, 64, tail o32[+0x40], work)
    B32  = band_filter(b32  , coefB, 640, 64, tail o32[+0x44], work)
    pcm  = int16(clamp_f32(2*(A32 - B32)))      (FUN_1000f640: (int16)(v+0.5), ±32767/-32768)
```

Verified facts (oracle, frames 37/38/39): `pcm == clamp(2*(A32-B32))` corr 1.000000;
`o32[+0x2c] == clamp(2*(A16-B16))` corr 1.000000; `o16[+0x2c] == o8[+0x30]` corr 1.000000.
`band_filter`'s intrinsic gain is a flat 1/2 per call, so each level's `×2` is real.

---

## 6. Patch instructions for `tools/codec210.py`

### 6.1 New module-level helpers (place next to `_f32`)

```python
# doubles at DLL VA 0x100242b0 / 0x100242c0 / 0x10024300 / 0x10022e10 / 0x10022120
GG_A, GG_B = 0.27027027027027022976, 0.15556000000000000383   # 16 kHz gain law
NZ_STEP, NZ_OFF = 0.125, 10.0                                  # 32 kHz gain law
EC0_EPS = 0.1                                                  # FUN_10002ec0 (+ sqrt)
CB2_PASS2 = 0.4                                                # double 0x10023660
UPSAMPLE_GAIN = 2.0                                            # FUN_1000f0e0 cmd 0x65/0x66
NOISE_MUL = 0.699999988079071                                  # *(float*)(0x10023ca8+0x24)

def _tilt_pair(lpc):
    """(s, d) = (1 + sum_even(lpc[i]+lpc[i+1]), 1 + sum_even(lpc[i+1]-lpc[i]))."""
    s = d = 1.0
    for i in range(0, len(lpc) - 1, 2):
        s += lpc[i] + lpc[i + 1]
        d += lpc[i + 1] - lpc[i]
    return s, d

def _f32_ec0(p, n):
    """FUN_10002ec0(p, n) = sqrt(sum(p[i]**2)/n + 0.1)  (VA 0x10002ec0)."""
    return _f32(math.sqrt(sum(_f32(x * x) for x in p) / n + EC0_EPS))

def _codebook16(ids, table):
    """FUN_100029c0 with descriptor 0x10023a5c {dim 8, count 5, bits 7, sign}."""
    out = [0.0] * (8 * len(ids))
    for k, (sign, idx) in enumerate(ids):
        f = (-1.0 if sign else 1.0) * (1.0 / 32.0)      # _DAT_10021260 / _DAT_10021268
        b = idx * 8
        for j in range(8):
            out[k * 8 + j] += _f32(table[b + j] * f)
    return out
```

The 128×8 int8 table is already extracted: `T["codebooks"]["innovation"]["cb_128x8_16k"]["int8"]`
(VA `0x10022470`, file offset `0x21870`, 1024 bytes).  In `__init__` add
`self.cb16 = T["codebooks"]["innovation"]["cb_128x8_16k"]["int8"]`.

### 6.2 New state in `Codec210.reset()`

```python
        self.lsf8_first = True          # obj[+0x1c]: on the first frame prev LSF := current
        self.lsf16_prev = None; self.mem16 = [0.0] * 8     # 16 kHz band
        self.lsf32_prev = None; self.mem32 = [0.0] * 8     # 32 kHz band
        self.tilt8 = [0.0] * 4          # d(lpc8) per sub-frame (the 8 kHz obj[+0x58])
        self.tail_b16 = [0.0] * 64     # 16 kHz B QMF tail (obj16+0x44)
        self.tail_b32 = [0.0] * 64     # 32 kHz B QMF tail (obj32+0x44)
        self._exc16_pre = [0.0] * 160   # obj16+0x48 kept for band32
```

### 6.3 `synth8` must also record the 8 kHz tilt and use the first-frame LSF rule

Replace the body of `synth8` (keep the signature) by:

```python
    def synth8(self, lsf_cur):
        """8 kHz core LPC synthesis -> o8[+0x30]; also fills self.tilt8 = d(lpc) per sub-frame.

        obj[+0x1c] ("first frame") makes the LSF history equal the current LSF, so frame 0
        does not interpolate (measured: tilt16/tilt8 constant over the 4 sub-blocks of f0).
        """
        out = []
        mem = list(self.lpc_mem8)
        prev = lsf_cur if self.lsf8_first else self.lsf8_prev
        for sf in range(4):
            lsf_i = lsf_stabilise(lsf_interp(prev, lsf_cur, 10, sf, 4), 0.05)
            a = lsf_to_lpc(lsf_i)
            self.tilt8[sf] = _tilt_pair(a)[1]          # obj8[+0x58] = 1 + sum(lpc[i+1]-lpc[i])
            x = self.buf[HIST + 40 * sf: HIST + 40 * sf + 40]
            y, mem = lpc_synth(a, mem, x)
            out.extend(y)
        self.lpc_mem8 = mem
        self.lsf8_prev = lsf_cur
        self.lsf8_first = False
        return out
```

with `self.lsf8_first = True` added in `reset()` (the port currently starts
`lsf8_prev = RAMP10`; the DLL starts from the current LSF, which is a 1-frame-only
difference).

### 6.4 The two new band methods

```python
    def band16(self, f, exc8):
        """16 kHz coded band (B16).  exc8 = the 8 kHz excitation (160)."""
        lsf_cur = f["lsf16"]
        prev = lsf_cur if self.lsf16_prev is None else self.lsf16_prev
        ps = []
        for sf in range(4):
            lsf_i = lsf_stabilise(lsf_interp(prev, lsf_cur, 8, sf, 4), 0.05)
            a = lsf_to_lpc(lsf_i)
            ps.append((a,) + _tilt_pair(a))
        exc = [0.0] * 160
        for sf in range(4):
            a, _s, d16 = ps[sf]
            norm = (self.tilt8[sf] + 0.01) / (0.01 + d16)     # child(=8k) d-tilt / own d
            e = _f32_ec0(exc8[40 * sf:40 * sf + 40], 40)       # block2 = plain copy of exc8
            gg = math.exp(f["sub16"][sf][0] * GG_A - GG_B)
            gain = (e + 1.0) * (gg / norm)
            ids = f["sub16"][sf][1]
            v1 = _codebook16(ids[0:5], self.cb16)
            v2 = _codebook16(ids[5:10], self.cb16)
            exc[40 * sf:40 * sf + 40] = [_f32(v1[i] * gain + v2[i] * (gain * CB2_PASS2))
                                         for i in range(40)]
        self._exc16_pre = list(exc)             # obj16+0x48: the 32 kHz source
        mem = list(self.mem16)
        for sf in range(4):
            y, mem = lpc_synth(ps[sf][0], mem, exc[40 * sf:40 * sf + 40])
            exc[40 * sf:40 * sf + 40] = y
        self.mem16 = mem; self.lsf16_prev = lsf_cur
        return exc, ps

    def band32(self, f, exc16, tilt16):
        """32 kHz noise band (B32).

        `exc16`  = the 16 kHz *excitation* (pre-synthesis), block3 source;
        `tilt16` = the 16 kHz level's per-sub-block `s` tilt (obj16+0x60, read by cmd 100).
        """
        lsf_cur = f["lsf32"]
        prev = lsf_cur if self.lsf32_prev is None else self.lsf32_prev
        ps = []
        for sf in range(4):
            lsf_i = lsf_stabilise(lsf_interp(prev, lsf_cur, 8, sf, 4), 0.05)
            a = lsf_to_lpc(lsf_i)
            ps.append((a,) + _tilt_pair(a))
        src = [0.0] * 320
        for i in range(160):
            src[2 * i] = UPSAMPLE_GAIN * exc16[i]        # FUN_1000f0e0 cmd 0x66
        exc = [0.0] * 320
        for sf in range(4):
            a, _s32, d32 = ps[sf]
            norm = (tilt16[sf] + 0.01) / (0.01 + d32)    # 16k s-tilt / own d-tilt
            amp = math.exp((f["ref32"][sf] - NZ_OFF) * NZ_STEP) / norm
            ramp = 1.0
            for i in range(80):
                exc[80 * sf + i] = _f32((ramp * amp) * NOISE_MUL * src[80 * sf + i])
                ramp = -ramp                              # double -1.0 at 0x100242f8
        mem = list(self.mem32)
        for sf in range(4):
            y, mem = lpc_synth(ps[sf][0], mem, exc[80 * sf:80 * sf + 80])
            exc[80 * sf:80 * sf + 80] = y
        self.mem32 = mem; self.lsf32_prev = lsf_cur
        return exc
```

(The `s16` in `band32` is the *16 kHz* `s` tilt from `band16`'s `ps`, i.e. the value the
16 kHz level stores in `obj[+0x60]` and its parent reads by cmd 100.  `band32` must be
called with `self._exc16_pre`, the pre-synthesis 16 kHz excitation, **not** `band16`'s
return value — that one is the synthesized `o16[+0x34]`.)

### 6.5 `decode_frame`: replace the tail from `sig8` onwards

```python
        exc8 = self.buf[HIST:HIST + 160]                     # o8[+0x3c]
        sig8 = self.synth8(f["lsf10"])                       # o8[+0x30]

        exc16, ps16 = self.band16(f, exc8)                   # o16[+0x34] (B16)
        a16 = band_filter(sig8,  self.cf_a, 320, 64, self.tail_a16, [0.0] * 1088)
        b16 = band_filter(exc16, self.cf_b, 320, 64, self.tail_b16, [0.0] * 1088)
        out16 = [max(-32768.0, min(32767.0, 2.0 * (x - y))) for x, y in zip(a16, b16)]

        exc32 = self.band32(f, self._exc16_pre, [p[1] for p in ps16])   # o32[+0x34] (B32)
        a32 = band_filter(out16, self.cf_a, 640, 64, self.tail_a32, [0.0] * 2048)
        b32 = band_filter(exc32, self.cf_b, 640, 64, self.tail_b32, [0.0] * 2048)
        pcm = [clamp_int16(2.0 * (x - y)) for x, y in zip(a32, b32)]
```

`self.exc_scale` stays where it is (it is only used by the 8 kHz gain); with both bands
ported no output-domain calibration is needed (measured rms ratio 0.9910 over 0..299).
Update the `stages` dict: `band_B_32k_noise` / `band_16k_coded` → `"ported+verified"`.

---

## 7. Validation

Scripts (throwaway, in `/tmp`): `ub_stage.py` (stage-local, DLL buffers injected),
`ub_chk2.py`, `apply_patch.py` (applies the §6 patch to a copy of `tools/codec210.py`),
`e2e_patched.py`, `e2e_ranges.py` (end-to-end vs `/tmp/oracle_pcm_0_299.json`, produced by
`tools/codec210_oracle.py`).  All correlations are over the buffers themselves (float) /
the decoded int16 PCM.

**(a) Stage-local with the DLL's own inputs injected** (the DLL's 8 kHz excitation, its
`o8[+0x58]` tilt array, its LPC states and QMF tails are read out of the emulator and fed to
the Python code, so only the newly ported stages are under test):

| frame | exc16 | o16[+0x34] | A16 | B16 | out16 | exc32 | o32[+0x34] | A32 | B32 |
|---|---|---|---|---|---|---|---|---|---|
| 37 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |
| 38 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |
| 39 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |

The frame-38 energies `E = [1272.7, 431.24, 3429.07, 601.52]` reproduce the DLL's own
`FUN_10002ec0` results `[1272.877, 431.233, 3429.84, 601.521]` read at `0x1000e691`.

**(a2) The patch generated *directly* from the §6 code blocks**
(`/tmp/gen_from_spec.py` stitches the spec's five code blocks into a copy of
`tools/codec210.py` → `/tmp/codec210_specpatch.py`) has every buffer of the running port
compared against the DLL's own buffers, frames 37/38/39 (no injected inputs — this is the
whole port, 8 kHz chain included):

| frame | exc8 | sig8 | tilt8 | exc16 | o16[+0x34] | A16 | B16 | o32[+0x34] | A32 | B32 | PCM |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 37 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.999999 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.999999 |
| 38 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |
| 39 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |

**(b) The patched port end-to-end** (`/tmp/codec210_specpatch.py`, i.e. the patch generated
from the §6 code blocks as in (a2); the module is imported directly, no subclassing):

| range | corr | rms / reference | ratio |
|---|---|---|---|
| 0..299 | **0.997496** | 2805.2 / 2830.35 | 0.9910 |
| 37..299 | 0.997496 | | 0.9910 |
| 40..299 | 0.997443 | | 0.9908 |
| 100..299 | 0.997039 | | 0.9922 |

| frame | 0 | 37 | 38 | 39 | 120 |
|---|---|---|---|---|---|
| PCM corr | 0.8975 | 0.999999 | 1.000000 | 1.000000 | 0.6538 |
| PCM rms | 0.401 / 0.659 | 1245.8 / 1246.6 | 4764.0 / 4765.1 | 5077.6 / 5078.5 | 123.3 / 137.4 |
| `exc16` corr | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.9992 |

Frame 0 (0.8975) and frames 0..36 are the near-silent floor: the port and the DLL differ by
at most **1** int16 LSB on every one of the 640 samples, so the correlation number there is
quantisation noise, not a modelling error.  Frame 120 is an 8 kHz-chain residual (`exc8`
corr 0.922, `sig8` 0.636), not the upper bands.

**(c) Every remaining low-correlation frame traced to the *8 kHz* chain, not the upper
bands.**  56 of the 299 frames score < 0.99; 36 of them are the silent frames 0..36 above,
the other 20 (68, 87, 118–124, 148, 170, 171, 193, 208, 209, 225, 228, 241, 254, 271) are
low-amplitude passages where the 8 kHz excitation itself drifts from the DLL.  Stage trace
on four of them (my buffers vs the DLL's own, same run):

| frame | `exc8` | `sig8` | `tilt8` | `exc16` | `o32[+0x34]` | PCM |
|---|---|---|---|---|---|---|
| 38 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |
| 68 | 0.998471 | 0.992588 | 1.000000 | 0.999332 | 0.998147 | 0.985652 |
| 119 | 0.947833 | 0.926021 | 1.000000 | 0.999526 | 0.999031 | 0.927798 |
| 241 | 0.967982 | 0.968961 | 1.000000 | 0.999790 | 0.999944 | 0.968775 |

i.e. the 16/32 kHz stages track whatever the 8 kHz chain hands them at 0.999+ even when the
8 kHz excitation is only 0.95–0.97 correlated; the PCM loss is inherited, not generated.

**(d) Rounding sensitivity:** the same patch with the three `_f32` helpers in the new code
removed (every intermediate kept in Python double) scores *identically*
(0.997496 / 0.9910 over 0..299, 0.999999/1.000000/1.000000 at frames 37/38/39).  So the
explicit `_f32` calls in §6 only document the DLL's float32 storage; nothing in the metric
depends on them.

Per-frame PCM correlation over frames 37..298: mean **0.995918**, median 1.000000 (the
low frames are exactly those listed in (c)).

## 8. Closed / unclosed

* **16 kHz coded band (B16): CLOSED.** `exc16`, `o16[+0x34]`, `B16`, `out16` reproduce the
  DLL's own buffers at corr **1.000000** (frames 37/38/39); the four frame-38 gains match
  the DLL's internal values to ≤0.05 %; the norm/energy identities are exact.
* **32 kHz noise band (B32): CLOSED.** `exc32`, `o32[+0x34]`, `B32` at corr **1.000000**;
  the four frame-38 `gain5 = exp((idx5-10)/8)` values match the DLL's measured gains exactly
  (1.133148/5.754603/0.367879/7.389056) and the four norms to ≤3e-5.
* **Chain/combine: CLOSED** (`out16 = clamp(2*(A16-B16))`, `pcm = clamp(2*(A32-B32))`,
  corr 1.000000).
* **End-to-end with the current 8 kHz chain: corr 0.997496, rms ratio 0.9910 over frames
  0..299 for the §6 patch verbatim** (the reference port without these two bands scores
  0.9894 with ratio 0.983 on the same basis, so the two bands account for essentially the
  whole remaining gap).  The remaining error is the ±1 LSB int16 rounding on the silent
  frames plus the 8 kHz chain's own residual on a few frames (frame 120: `exc8` 0.922,
  `sig8` 0.636), not the upper bands.


---

# APPENDIX: specs/DriftFrames.md

# The remaining 8 kHz drift frames — root cause and fix

Scope: the ~20 non-silent frames where the (otherwise exact) port drifted from the DLL
(worst: 118–130, 170–179, 68, 94–97).  Delivered for the parent's follow-up request.

**Result: the drift is in the 8 kHz adaptive-codebook (LTP) tap read, not in the
LSF/interpolation/stabilisation/LSF→LPC path.**  The DLL's tap window is a *cyclic* read of
the `lag` samples that end just before the current sub-block; for `lag <= 40` a plain
3-tap read from the (cleared) excitation buffer reaches into the current sub-block and is
wrong.  With the rule below applied, the port's numbers become:

| range | before | after |
|---|---|---|
| frames 0..299 PCM corr | 0.997496 | **0.999648** |
| rms ratio | 0.9910 | **1.0010** |
| frames 170..179 (10-frame window) | 0.9863..0.9999 | **1.000000** |
| frames 118..130 | 0.6538 (f120) | 0.995993 (window 120–129 = 0.9958) |
| non-silent 10-frame windows < 0.999 | 4 | **1** (only 120–129 = 0.9958) |

All measurements are `tools/codec210_oracle.py` (the real DLL under Unicorn) vs a throwaway
copy of `tools/codec210.py` (`/tmp/codec210_ring.py`, patched per §4); scripts under `/tmp`.

---

## 1. Which stage drifts — per-frame state table

For frames N the DLL's post-frame 8 kHz work arrays are compared with the corresponding
port state (same decoder state, frames 0..N replayed in both):

| DLL array | port state | what it is |
|---|---|---|
| `0x300128a0` | `lsf8_prev` | 5-stage VQ accumulator = the frame's LSF |
| `0x30012870` | LSF→LPC of the last sub-block | the LPC coefficients |
| `0x30012a20` | `tilt8` | per-sub-block tilt (`1+Σ(lpc[i+1]-lpc[i])`) |
| `0x30012930` | `lpc_mem8[:10]` | LPC synthesis state (delay line) |
| `0x30011ea0` | `synth8()` output | the level signal `sig8` |
| `0x30012364` | `buf[HIST:HIST+160]` | the excitation |

| frame | lsf | lpc | tilt | state | sig8 | exc |
|---|---|---|---|---|---|---|
| 37, 38 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |
| 116, 117 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 1.000000 |
| 118 | 1.000000 | 1.000000 | 1.000000 | 0.968563 | 0.958879 | 0.974426 |
| 119 | 1.000000 | 1.000000 | 1.000000 | 0.984884 | 0.926021 | 0.947833 |
| 120 | 1.000000 | 1.000000 | 1.000000 | -0.670792 | 0.635583 | 0.922091 |
| 121 | 1.000000 | 1.000000 | 1.000000 | 0.985930 | 0.934315 | 0.926513 |
| 122 | 1.000000 | 1.000000 | 1.000000 | 0.999902 | 0.993853 | 0.999286 |
| 123 | 1.000000 | 1.000000 | 1.000000 | 0.998732 | 0.961643 | 0.988090 |
| 124 | 1.000000 | 1.000000 | 1.000000 | 0.999864 | 0.958588 | 0.991140 |
| 125..130 | 1.000000 | 1.000000 | 1.000000 | 0.9985..1.0 | 0.990..0.999 | 0.997..0.9996 |
| 170 | 1.000000 | 1.000000 | 1.000000 | 0.979304 | 0.989400 | 0.995176 |
| 171 | 1.000000 | 1.000000 | 1.000000 | 0.947077 | 0.990556 | 0.996511 |
| 172..179 | 1.000000 | 1.000000 | 1.000000 | 0.981..1.0 | 0.995..0.9998 | 0.998..0.9995 |

So: **lsf, lpc and tilt are identical to the DLL on every frame** (the LSF VQ, the
interpolation, the stabiliser, LSF→LPC and the VQ ramps are all exact, and nothing is
re-seeded or reset wrongly); the first quantity to leave the rails is the **excitation**,
with the LPC *state* and `sig8` following it (a resonant LPC in these quiet passages
amplifies the excitation error).  This *disproves* the "sig8 worse than exc8 ⇒ LSF path"
inference: `sig8` is worse only because it is the *filtered* excitation.

## 2. Which excitation component — decomposition at frame 118

For frame 118 the DLL's writes to the excitation buffer (`0x30012364`) were attributed by
code address (cache-clear at `0x10009b6f`, LTP output at `0x10009c0d`, CB1 accumulate at
`0x10009f3e`, CB2 at `0x10009ff1`), giving the DLL's LTP / CB1 / CB2 separately; the port's
single-pass components are computed on the same state (the state before frame 118 is exact,
frames ≤ 117 were exact):

| sf | lag | source | DLL rms | port rms | corr |
|---|---|---|---|---|---|
| 0 | 60 | LTP | 62.444 | 62.447 | 1.000000 |
| 0 | 60 | CB1 / CB2 | 119.518 / 57.897 | identical | 1.000000 |
| 1 | 20 | LTP | 55.952 | 40.952 | 0.705 |
| 1 | 20 | CB1 / CB2 | 55.328 / 27.271 | identical | 1.000000 |
| 2 | 109 | LTP | 45.817 | 45.818 | 1.000000 |
| 3 | 32 | LTP | 28.653 | 26.521 | 0.924 |
| 3 | 32 | CB1 / CB2 | 41.127 / 24.565 | identical | 1.000000 |

**CB1/CB2 (the innovation codebooks and their gains) are exact in every sub-frame; only the
LTP is wrong — and only when `lag <= 40`.**  (The taps span indices `w0 .. w0+41` with
`w0 = p-(lag+1)`, so they reach the current sub-block iff `w0+41 >= p` ⟺ `lag <= 40`.)

## 3. The rule: the tap window is a cyclic read of the previous `lag` samples

The LTP call's argument 10 is a 120-float scratch (`0x3000e0a4`) that the DLL fills with the
three 40-float tap windows before the FIR.  Reading it at the call's return gives the DLL's
*tap values* directly.  Comparing window 0 with the port's buffer `b[w0+k]` (frame 118,
sf1, `lag=20`, `w0 = p-21`):

| k | DLL `S[k]` | port `b[w0+k]` | match |
|---|---|---|---|
| 0 | 203.17763 | 203.17886 | ✓ |
| 1 | 173.39688 | 173.39948 | ✓ |
| … | … | … | ✓ |
| 20 | -109.34928 | -109.37252 | ✓ |
| **21** | **173.39688** | **-272.98111** | **✗ = `b[w0+1]`** |
| **22** | **121.79175** | **-274.10583** | **✗ = `b[w0+2]`** |
| … | … | (port has the cleared/stale values) | |
| 40 | 173.39688 | -272.98111 | ✗ (a second wrap) |

i.e. the DLL's window is **periodic with period `lag`** once it passes the end of the valid
history: it *wraps back* instead of entering the current sub-block.  The equivalent
statement for the taps (`w0 = p-(lag+1)`, tap index `k`):

```
RING[k] = buf[w0+k]                    if k <= lag
RING[k] = buf[w0 + 1 + ((k-1) % lag)]  if k >  lag
out[i]  = g2*RING[i] + g1*RING[i+1] + g0*RING[i+2]
```

Verification (frame 118 sf1, `lag=20`): the port's ring LTP vs the DLL's LTP recomputed from
its *own* scratch window, all 40 samples, max |difference| = **0.014** (≈1e-4 relative, the
float32 accumulation order); per-sub-frame correlations vs the DLL's written LTP output
(state exact):

| frame | sf | lag | current port (3-tap from the cleared buffer) | ring rule |
|---|---|---|---|---|
| 117 | 0..3 | 144,144,43,108 | 1.000000 | 1.000000 |
| 118 | 0,2 | 60,109 | 1.000000 | 1.000000 |
| 118 | 1 | 20 | 0.705330 | **0.990723** |
| 118 | 3 | 32 | 0.923512 | **1.000000** |
| 119 | 1 | 21 | 0.691752 | **1.000000** |
| 119 | 2 | 39 | 0.996394 | **1.000000** |
| 121 | 0 | 21 | 0.560543 | **1.000000** |
| frame total (excitation) | 118 | | 0.910706 | **0.997013** |
| frame total (excitation) | 119 | | 0.891144 | **1.000000** |

("current port" = the materialised 3-tap read after the clear; checked alternative
hypotheses — pre-clear/stale values, live in-place outputs, tap-base offsets ±160 —
are all *worse*: 0.02–0.85, and the offset scan peaks at offset 0.)

## 4. Minimal patch for `tools/codec210.py`

Replace the body of `Codec210.ltp` (the signature and the rest of the class are unchanged):

```python
    def ltp(self, p, lag, idx):
        """FUN_10006bb0 — 8 kHz adaptive codebook (lag-periodic tap window).

        The DLL's tap windows are a cyclic read of the `lag` samples ending just before the
        current sub-block: tap index k (relative to w0 = p-(lag+1)) reads buf[w0+k] while
        k <= lag, else buf[w0 + 1 + ((k-1) % lag)] — the current sub-block is never read.
        For lag >= 41 the ring does not wrap inside the 42 taps used, so this reduces to the
        plain 3-tap predictor.
        """
        tbl = self.pitch_tbl
        g = [tbl[idx * 3 + k] / 64.0 + 0.5 for k in range(3)]
        w0 = p - (lag + 1)
        buf = self.buf
        out = []
        for i in range(40):
            v = 0.0
            for j, coef in ((i, g[2]), (i + 1, g[1]), (i + 2, g[0])):
                if j > lag:
                    j = 1 + ((j - 1) % lag)
                a = w0 + j
                v += coef * (buf[a] if a >= 0 else 0.0)
            out.append(_f32(v))
        return out
```

To apply it programmatically to a copy (as done for the numbers here):

```python
s = open('tools/codec210.py').read()
i = s.index('    def ltp(self, p, lag, idx):')
j = s.index('    def codebook(self, idxs, base):')
s = s[:i] + <the function above> + s[j:]
```

## 5. Candidates checked and ruled out

| candidate | verdict |
|---|---|
| `lsf_interp` weights (is the first weight 0 or (sf+1)/nsub?) | **exact** — the port's interpolated LSF/LPC reproduce the DLL's LPC array `0x30012870` at corr 1.000000 on every frame incl. all drift frames |
| stabilisation margin (port uses 0.05, double `0x10023ec4`) | **exact** (same evidence; the margin is also confirmed in the disassembly at `0x10009a91`) |
| VQ ramp re-seeding per frame (RAMP10) | **exact** — the LSF array (`0x300128a0`) matches on every frame |
| LSF history reset on frame/mode boundaries | **exact** — ditto |
| LPC synthesis state initialisation / layout | **exact** — with the DLL's own state the port's `sig8` matches at corr 1.000000 (frames 37/38/39) and the state evolves identically once the excitation is right |
| the interpolation/`FUN_10002cc0`/`FUN_10002f80` band-expansion path | **not used** for 8 kHz per-frame synthesis (`obj8[+0x24] == 8000` selects it in the *parent* code, but the 8 kHz object uses its own path; all evidence comes from the LPC/state arrays themselves) |
| the **LTP tap read** | **wrong for lag ≤ 40** — this is the drift; see §3 |

## 6. Closed / unclosed

* **Root cause: CLOSED.** The 8 kHz LTP tap window is a cyclic read of the last `lag`
  samples (`RING` rule, §3), verified against the DLL's own 120-float tap scratch to
  ≈1e-4 (float32) and against the written LTP output per sub-frame (0.99–1.000 on the
  previously failing sub-frames; the residual 0.99 at frame 118 sf1 is float32 ordering in
  the near-cancelling 3-term sum).
* **End-to-end: frames 0..299 corr 0.999648, rms ratio 1.0010** (was 0.997496 / 0.9910).
  All non-silent 10-frame windows are ≥ 0.999 except **120–129 = 0.9958** (and 160–169 =
  0.9996); frames 170..179 are now exactly 1.000000.  The silent frames 0..36 are the
  ±1-LSB int16 rounding floor (unchanged; max abs sample diff = 1).
* **Not fully closed:** the window 120–129 (0.9958) still has a small residual — the same
  LTP rule with the exact float32 operation order and, possibly, the exact wrap boundary
  (`k > lag` vs `k >= lag+1`) should close it; everything else in that window traces back
  to the state error accrued at frames 118–119 by the previous (pre-fix) code path.


---

# APPENDIX: specs/Codec210.md

# LTTS7Codec210.dll — codec 210 format & decoder specification

Scope: the Loquendo TTS 7 **codec 210** speech decoder plugin, as shipped in the voice package
`jorge/pf/Loquendo/LTTS7/`. Primary target is the **Jorge build**
`bin/LTTS7Codec210.dll` (198 656 B, PE32, ImageBase `0x10000000`, TimeDateStamp `0x4b8f966f`,
MD5 `c02f0bd4329fc8f860407180ea1383c4`).
Cross-reference: `LTTS7CodecMsx.dll` (see §9).

All addresses below are **VA** (ImageBase + RVA). File offsets for every table are in
`tools/codec210_tables.json`. The raw decompilation used is the Ghidra auto-decomp of the Jorge DLL
(`/tmp/c210/decomp_codec210_jorge.txt`, 439 functions) plus a forced disassembly of the small
entry-point thunks Ghidra did not create (`/tmp/c210/missing210.txt`).

**Ground truth.** Besides the decompilation, every claim about the *stream* was validated by running
the real DLL code under an x86 emulator (Unicorn, `tools/codec210_oracle.py`) and comparing with the
pure-Python re-implementation (`tools/codec210.py`). See §10 for the validation protocol.

---

## 1. The two binaries at a glance

| | Jorge `LTTS7Codec210.dll` | Jorge `LTTS7CodecMsx.dll` |
|---|---|---|
| size | 198 656 B | 112 128 B |
| single export | `LTTS7Codec210` @ RVA 0x4760 | `LTTS7CodecMsx` |
| imports | **KERNEL32 only** | KERNEL32 + … |
| Util symbols | bound at runtime via `LoadUtilSymbols` | same mechanism |

The Jorge 210 build is **statically linked** against the compact MSVC 2008 CRT. It imports *no*
Loquendo library; the five utility entry points it needs are handed to it by the engine through
`LoadUtilSymbols` (see §2.2). This is the whole reason that entry point exists — for the older
`engine_re` build, `LTTS7Util.dll` was a real import table dependency instead.

---

## 2. Plugin ABI

### 2.1 Dispatcher export

`LTTS7Codec210` (RVA `0x4760`, i.e. VA `0x10004760`) is a **name→function-pointer dispatcher**.
It is called as `void *LTTS7Codec210(const char *name)` and returns the address of one of the plugin
entry points, or `0`.

It implements the comparison inline: for `uVar5 = 0..7` it walks the table at **VA `0x1002e028`**
(8 entries, stride 8 = `{const char *name; void *func;}`) and byte-compares `name` with
`entry->name`; on a full match it returns `entry->func`. The literal `if (7 < uVar5) return 0;`
proves the table has **8** entries.

| idx | name | func VA | role |
|---|---|---|---|
| 0 | `LoadUtilSymbols` | `0x10004130` | bind ELQ* helpers from the host (not a decoder entry point) |
| 1 | `GetVersion` | `0x100041f0` | decoder version |
| 2 | `ELQOpenDecoder` | `0x100045e0` | create a decoder instance |
| 3 | `ELQCloseDecoder` | `0x10004730` | destroy it |
| 4 | `ELQGetDecodedFileSize` | `0x10004220` | — |
| 5 | `ELQGetDecoderDescription` | `0x100041c0` | — |
| 6 | `ELQDecoderFileChanged` | `0x100041d0` | notify "current stream changed" |
| 7 | `ELQDecode` | `0x10004530` | decode PCM |

The **7 entry points** the engine resolves by name (via `ELQPluginGetProc`) are indices 1..7.

### 2.2 `LoadUtilSymbols` (`0x10004130`) — runtime binding of the util API

Walks a 5-entry table at **VA `0x1002e000`**, stride 8 = `{const char *name; void **slot;}` and for
each entry calls the helper `FUN_10004100(moduleHandle)`, which does
`*slot = GetProcAddress(moduleHandle, name)`. It stops at the first failure and prints
`WARNING: Symbol "%s" not found in utility library`.

| name | slot VA | meaning |
|---|---|---|
| `ELQBinGetBuffer` | `0x1002f624` | map/read `size` bytes at `offset` from the shared `.bin` resource |
| `ELQLogWrite` | `0x1002f628` | logger |
| `ELQfree` | `0x1002f62c` | free |
| `ELQmalloc` | `0x1002f630` | alloc (used for the 0x11E8-byte context) |
| `ELQstricmp` | `0x1002f634` | case-insensitive compare (not used after the dispatcher) |

These 5 slots are zero in the file's `.data` and are filled at load time. `ELQstricmp` is what the
engine-build dispatcher used; the Jorge dispatcher open-codes the comparison instead.

### 2.3 Entry-point signatures

| entry | VA | signature | behaviour |
|---|---|---|---|
| `GetVersion` | `0x100041f0` | `int GetVersion(void *out7)` | writes the 7 bytes at `0x10022db8` = `"7.14.0"` (`37 2e 31 34 2e 30 00`) → `out7[0..2]` as dword+word+byte. Returns 0. |
| `ELQOpenDecoder` | `0x100045e0` | `int ELQOpenDecoder(void **pCtx, int sampleRate, int logHandle)` | allocates and initialises the 0x11E8-byte context. Returns 0 ok, 4 `SampleRate not supported`, 5 out-of-memory. |
| `ELQCloseDecoder` | `0x10004730` | `int ELQCloseDecoder(void *ctx)` | frees the bit-reader buffer, the decoder object and the context. Returns 0. |
| `ELQGetDecodedFileSize` | `0x10004220` | `int ELQGetDecodedFileSize(void *, int *pSize)` | `*pSize = -1` (size not known up-front — the codec is streamed). Returns 0. |
| `ELQGetDecoderDescription` | `0x100041c0` | `const char *ELQGetDecoderDescription(void)` | returns the literal `"Loq210"` (`0x10022db0`). |
| `ELQDecoderFileChanged` | `0x100041d0` | `int ELQDecoderFileChanged(void *ctx, int streamOffset)` | `if (ctx) { ctx[0x11E5] = 0; *(int*)(ctx+0x4C) = streamOffset; }`. Returns 0. |
| `ELQDecode` | `0x10004530` | `int ELQDecode(void *ctx, void *io, void *binHandle, int maxSamples, void *pcmOut)` | see §6.1. |

`ELQDecoderFileChanged` is the important one: it **invalidates the cached stream sub-header**
(`ctx+0x11E5 = 0`) and stores the byte offset of this stream inside the shared `.bin`
(`ctx+0x4C = streamOffset`). For the Jorge voice DB this offset is the 122-byte
`LOQUENDOTTS7` header size — which is exactly why frame *i* is read at
`streamOffset + 28 + i*bytesPerFrame`. The engine derives it from the container header.

---

## 3. Decoder context layout (size `0x11E8` = 4584 bytes)

Allocated by `ELQOpenDecoder` through `ELQmalloc(0x11E8)` and zeroed. Only the fields listed are
used; the rest are scratch float buffers (LPC states, codebooks) addressed by the decoder object.

| byte offset | type | set by | meaning |
|---|---|---|---|
| `+0x00` | `u8*` | `FUN_100012e0` | bit-reader input buffer (own copy, `_calloc(2000)`) |
| `+0x04` | `u32` | `FUN_10001040` | **total bits** available (= `8 * bytesPerFrame`) |
| `+0x08` | `u32` | bit reader | current byte index |
| `+0x0C` | `u32` | bit reader | current bit index inside the byte (0..7) |
| `+0x10` | `u32` | `FUN_100012e0` | "owns the buffer" flag (1) |
| `+0x14` | `u32` | bit reader | **error/overrun flag** (1 = past end) |
| `+0x18` | `u32` | `FUN_100012e0` | buffer capacity (2000) |
| `+0x24` | `void*` | `ELQOpenDecoder` | pointer to the per-rate **class descriptor / vtable** (32 kHz → `0x10023b2c`) |
| `+0x28` | `void*` | `FUN_10004230` | the decoder **instance object** (see §3.1), 0 until first decode |
| `+0x2C` | `int` | `ELQOpenDecoder` | `logHandle` (host logger) |
| `+0x30` | `int` | `ELQOpenDecoder` | `sampleRate` (32000) |
| `+0x34` | `int` | `ELQOpenDecoder` | 509 for 32 kHz (table/index stride constant, used as the sample-position step in `ELQDecode`) |
| `+0x38` | `int` | `ELQOpenDecoder` | 6 for 32 kHz (frames of "history" the streaming wrapper keeps) |
| `+0x3C`,`+0x40` | `int` | `FUN_100042f0` | sample window currently in the output buffer (first/last) |
| `+0x44`,`+0x48` | `int` | `FUN_100042f0` | same for the previous-frame buffer |
| `+0x4C` | `int` | `ELQDecoderFileChanged` | **byte offset of this stream in the `.bin`** (= 122 for Jorge) |
| `+0x11D0` | `u16` | `ELQDecode` | **bytes per frame** = `110` (read from sub-header byte `0x13`) — also the XOR length |
| `+0x11D2` | `u16` | `ELQOpenDecoder` | **samples per frame** = `640` (0x280) |
| `+0x11D4` | `void*` | `ELQOpenDecoder` | output PCM buffer (points at `ctx+0x410`) |
| `+0x11D8` | `void*` | `ELQOpenDecoder` | previous-frame PCM buffer (`ctx+0xCD0`) |
| `+0x11DC`,`+0x11E0` | `int` | streaming wrapper | current/previous frame indices (`-2` initially) |
| `+0x11E4` | `u8` | `ELQDecode` | **per-frame XOR key** = `0x6D` (sub-header byte `0x1B`) |
| `+0x11E5` | `u8` | `ELQDecode` | sub-header cache-valid flag |

### 3.1 Rates

`ELQOpenDecoder` switches on `sampleRate` (`0x100045e0`, disasm `0x10004617`):

| rate (Hz) | samples/frame `+0x11D2` | `+0x34` | `+0x38` | class descriptor `+0x24` | out buf `+0x11D4` | prev buf `+0x11D8` |
|---|---|---|---|---|---|---|
| 8000 (`0x1f40`) | 160 (`0xa0`) | 110 | 3 | `0x1002393c` | `ctx+0x50` | `ctx+0x910` |
| 16000 (`0x3e80`) | 320 (`0x140`) | 224 | 3 | `0x10023ab4` | `ctx+0x190` | `ctx+0xa50` |
| 32000 (`0x7d00`) | **640 (`0x280`)** | 509 | 6 | **`0x10023b2c`** | `ctx+0x410` | `ctx+0xCD0` |
| other | — | — | — | — | — | returns 4, logs `Unable to create LoqCodec210 decoder (SampleRate not supported)` |

Every rate supports exactly 20 ms frames; the 32 kHz rate is the one used by the voice DBs
(`Freq=32000` TLV).

### 3.2 Decoder instance object (0x74 bytes)

Created lazily on the first decode by `FUN_10004230` (the "reset" routine) through
the virtual factory `FUN_1000f4f0(ctx+0x24)` → `ctx[+0x24][+0x20]` = **`FUN_1000db20`**
(the constructor). Destroyed by `FUN_1000f510(obj)` → `obj[0][+0x24]` = `FUN_1000de40`.

`FUN_1000db20(classDesc, ...)`:

```
obj = calloc(0x74); memset(obj, 0, 0x74)
obj[+0x28] = calloc(24000)                 ; scratch work area
obj[+0x00] = classDesc                     ; == 0x10023b2c for 32 kHz  (the object's vtable)
sub = *classDesc                           ; == 0x10023ca8 (32 kHz sub-descriptor)
obj[+0x68] = 1
obj[+0x04] = FUN_1000f4f0(sub[+0x00])      ; construct the synthesis/filter sub-object
obj[+0x08] = sub[+0x04] * 2    ; = 640     ; samples per FUN_1000e170 invocation
obj[+0x0C] = sub[+0x04]        ; = 320
obj[+0x10] = sub[+0x08]        ; = 80      ; samples per sub-block
obj[+0x14] = sub[+0x04]/sub[+0x08] ; = 4   ; number of sub-blocks per call
obj[+0x18] = sub[+0x0C]        ; = 8       ; **LPC order**
obj[+0x6C] = sub + 10 (dwords)             ; == 0x10023cd0 : mode pointer array
obj[+0x70] = sub[+0x12]        ; = 1       ; current mode index (overwritten by the bitstream)
... + a dozen calloc'd work buffers indexed by order/samples ...
obj[+0x19] = 1000
```

The **class descriptor** for 32 kHz, `0x10023b2c`, is a table of 24 function/field pointers:

| off | value | |
|---|---|---|
| `+0x00` | `0x10023ca8` | per-rate sub-descriptor (see below) |
| `+0x04` | `0x1000f5d0` | class query / name helper |
| `+0x08` | `0x10023d54` | string pool (`"ultra-wideband sub-band CELP"` etc.) |
| `+0x0C` | 2 | rate index |
| `+0x10` | 4 | sub-block count |
| `+0x14` | `0x1000c310` | per-band setup |
| `+0x18` | `0x1000cb20` | |
| `+0x1C` | `0x1000cc90` | 32 k analysis/quantiser helper |
| `+0x20` | `0x1000db20` | **constructor** (called by `FUN_1000f4f0`) |
| `+0x24` | `0x1000de40` | **destructor** (called by `FUN_1000f510`) |
| `+0x28` | `0x1000e170` | **per-call decode** (called by `FUN_1000f530`) |
| `+0x2C` | `0x1000e8f0` | |
| `+0x30` | `0x1000f0e0` | called by `FUN_1000f550` before each decode |
| `+0x44` | `0x1000bdd0` | band parameter decode |
| `+0x48` | `0x1000c0d0` | band parameter decode (LSF) |
| `+0x58` | `0x10001b60` | |
| `+0x5C` | `0x100029c0` | |

Sub-descriptor `0x10023ca8` (32 kHz): `+0x00 = 0x10023ab4` (16 kHz descriptor), `+0x04 = 320`,
`+0x08 = 80`, `+0x0C = 8` (LPC order), `+0x10 = 1280`, then float constants
`0.9, 0.6, 0.002, 0.0001, 0.7`, `+0x2C = 0x10023a70` (band descriptor, funcs
`FUN_1000bdd0`@+0x10, `FUN_1000c0d0`@+0x14), and at `+0x28..` the **mode pointer array**
(`0x10023cd0`) = `[0, 0x10023a70, 0, 0, 0, 0, 0, 0, 1, 0, 1, 2, 3, 4, …]`.
A mode index `m` is valid iff `modeArray[m] != 0`; for 32 kHz only **m = 1** is non-null
(m = 0 selects the special "no new data" path, any other non-zero m triggers
`"Invalid mode encountered: corrupted stream?"` and returns −2).

The virtual-call thunks are tiny `jmp` stubs:
`FUN_1000f4e0(x) = jmp [x+0x14]`, `FUN_1000f4f0(x) = jmp [x+0x20]`,
`FUN_1000f500/510/520/530/540/550(x) = jmp [[x]+0x18/0x24/0x1C/0x28/0x2C/0x30]`.

---

## 4. Container, stream sub-header and frame-size arithmetic

The `.bin` file is a `LOQUENDOTTS7` container (see `specs/ELQBinContainer.md`).
For `Jorge.32000.LTTS7Codec210.44000.10.bin` (29 144 430 bytes):

* header size `122` (TLV `Freq=32000`, `Coding=LTTS7Codec210`, `BitRate=44000`, `Rank=10`,
  `Version=7.1.0`);
* at offset 122 the codec expects a **28-byte stream sub-header** = **7 big-endian `u32`**
  (`ELQOpenDecoder` reads them via the `ELQBinGetBuffer` binding in `ELQDecode`, size `0x1C`):

| sub-header off | BE u32 | value (Jorge) | meaning | consumed by |
|---|---|---|---|---|
| 0x00 | BitRate | 44000 | nominal bit rate (bits/s) | — |
| 0x04 | Rank | 10 | rank/quality class from the TLV | — |
| 0x08 | samples/frame | **640** | PCM samples per frame | — |
| 0x0C | Freq | 32000 | sample rate (must match `ELQOpenDecoder`) | — |
| 0x10 | bytes/frame | **110** | stored bytes per frame | `ELQDecode`: `ctx+0x11D0 = (u16)(s8)seed[0x13]` |
| 0x14 | frame count | **264 948** | number of frames | — |
| 0x18 | cookie | `0x1FE90B6D` | per-file scramble cookie | `ELQDecode`: `ctx+0x11E4 = (u8)seed[0x1B]` |

Exact code (`ELQDecode`, VA `0x10004530`, disasm `0x1000457e`–`0x100045ac`):

```
; if ctx->cache_valid(0x11E5) == 0:
p = ELQBinGetBuffer(bin, ctx->streamOffset(0x4C), 0x1C, 1, 0, &flag)
ctx->bytesPerFrame(0x11D0) = (int16)(int8)p[0x13]    ; 110
ctx->xorKey(0x11E4)        = p[0x1B]                 ; 0x6D
ctx->cache_valid(0x11E5)   = 1
```

### 4.1 Frame-size derivation (exact sources)

* **samples/frame = 640** — `ELQOpenDecoder` `mov WORD PTR [esi+0x11d2],0x280` (`0x10004698`), and
  independently the sub-header word at offset 0x08 (`0x00000280`).
* **frame duration = 20 ms** — 640 samples / 32 000 Hz.
* **bytes/frame = 110** — sub-header word at offset 0x10 (`0x0000006E`) copied to `ctx+0x11D0` by
  `ELQDecode` (`0x10004594`); consistent with 44000 bit/s × 20 ms / 8 = 110.
* **frame count = 264 948** — sub-header word at offset 0x14 (`0x00040AF4`).
* **data region starts at 122; first frame at 122 + 28 = 150.**

Cross-check against the shipped DB size (29 144 430 B):

```
122 (header) + 28 (sub-header) + 264948 * 110 = 122 + 28 + 29144280 = 29144430   ✔ exact
```

The same identity holds for the other two shipped DBs
(`JorgeGildedPhrases`: 148 + 28 + 8889·110 = 977 966; `JorgeGildedParalinguistics`:
164 + 28 + 9958·110 = 1 095 572).

---

## 5. Per-block layout and the XOR key

A **block** (frame) is **110 bytes** at file offset `150 + 110*i`, `i < 264948`.
Frames are stored **scrambled**, and the decoder un-scrambles each block before bit-unpacking.

### 5.1 The XOR fields at `+0x474` / `+0x479`

In the decompiled code the context pointer is typed `int*`, so the Ghidra expressions `ctx[0x474]`
and `ctx[0x479]` are **pointer-scaled** and denote the byte offsets **`+0x11D0`** and **`+0x11E4`**:

```c
/* FUN_10004290 @ 0x10004290  (the decode driver; EDI = block buffer, ESI = ctx) */
if ((char)ctx[0x479] != 0 && 0 < (short)*(u16*)(ctx + 0x474)) {   /* key != 0 && len > 0 */
    len = *(u16*)(ctx + 0x474);                                   /* ctx+0x11D0 = 110 */
    do { *p ^= *(u8*)(ctx + 0x479); p++; } while (--len);         /* ^= ctx+0x11E4 = 0x6D */
}
FUN_10001020(ctx);                          /* reset bit reader                 */
FUN_10001040(ctx, buf, *(short*)(ctx+0x474));/* set input = 110 bytes           */
FUN_1000f640(ctx[10], ctx, ctx[0x475]);      /* decode -> ctx+0x11D4 (int16 PCM) */
```

So:

* **length field** `+0x11D0` (`u16`) = 110 = the whole block; set by `ELQDecode` from
  sub-header byte `0x13` (sign-extended).
* **key field** `+0x11E4` (`u8`) = `0x6D`; set by `ELQDecode` from sub-header byte `0x1B`.
* The mask is applied to the **whole 110-byte block, in place**, before bit-unpacking.

**Empirically confirmed**: decoding any block with key `0x6D` yields well-formed speech, while
key `0x00` or `0xFF` makes the decoder read a malformed mode/field and crash
(§10). `0x6D` is just `cookie & 0xFF` for this file, so the whole DB uses one constant key.

Consequence: a re-implementation must do `block[i] ^= 0x6D` for `i in range(110)` (or XOR with
`(cookie & 0xFF)` for a generic file) before parsing.

---

## 6. Decode pipeline

### 6.1 `ELQDecode` and the streaming wrapper

`ELQDecode(ctx, io, binHandle, maxSamples, pcmOut)` (VA `0x10004530`):

1. validate args;
2. if the sub-header cache is invalid, read it (see §4) and set the XOR fields;
3. else `io += ctx->0x34` (509 for 32 kHz);
4. loop calling `FUN_10004340(ctx, &outPtr, &samplePos, maxSamples, binHandle)` until it reports
   nothing left to do.

`FUN_10004340` is the frame-streaming wrapper (analogue of the older build's `FUN_10001170`).
For frame index `n = samplePos / samplesPerFrame`:

* `n == ctx->curFrame(0x11DC)` → copy the remaining samples out of the cached output buffer;
* `n == ctx->curFrame + 1` → advance (`FUN_100042f0` = copy output→previous), read the block with
  `ELQBinGetBuffer(bin, bytesPerFrame*n + 28 + ctx->streamOffset, bytesPerFrame, 1, 0, &flag)`,
  run `FUN_10004290` (XOR + decode) and cache it; if `flag` says out of range, emit zeros;
* otherwise (random seek) → `FUN_10004230` (reset), then decode blocks
  `max(0, n-6) .. n` in order so the codec state (LPC memory, adaptive codebook) matches the
  target, then copy the requested samples.

This is why the decoder is *stateful*: a block cannot be decoded in isolation unless the previous
~6 blocks were decoded first (mode + filter memory).

### 6.2 `FUN_1000f640` — top of the DSP, float→int16

`FUN_1000f640(decObj, ctx, int16 *out)`:

```c
FUN_1000f550(decObj);                       /* decObj->vtbl[+0x30] = FUN_1000f0e0, pre-frame init */
r = (*(decObj->vtbl[+0x28]))(decObj, ctx, floatbuf, 3, ...);   /* FUN_1000e170 */
for (i = 0; i < count; i++) {                /* count is returned in a stack slot */
    double v = floatbuf[i];
    if (v >  32767.0) out[i] =  32767;                 /* _DAT_10023658 = 32767.0 */
    else if (v < -32768.0) out[i] = -32768;            /* _DAT_1002364c = -32768.0 */
    else out[i] = (int16)(v + 0.5);                    /* rounds via a CRT float->int helper */
}
```

Constants: `_DAT_10023658` = `32767.0` and `_DAT_1002364c` = `-32768.0` are **doubles**
(`0x10023658`, `0x1002364c`).

### 6.3 Bit reader (MSB-first)

Ported verbatim:

| VA | function | semantics |
|---|---|---|
| `0x10001020` | reset | `buf[0]=0; total=byte=bit=err=0` |
| `0x10001040` | set input | copies `n` bytes into the internal buffer, `total_bits = 8n`, `byte=bit=0` |
| `0x100011d0` | `read(n)` | MSB-first read of `n` bits; sets `err` on overrun and returns 0 |
| `0x10001240` | `peek1()` | one bit **without consuming it** (it only tests availability) |
| `0x10001280` | `skip(n)` | advance `n` bits |
| `0x100012c0` | `bits_left()` | `total_bits - 8*byte - bit` (or −1 on error) |

### 6.4 Frame header / mode

Cross-references: this is a **layered sub-band CELP**. `FUN_1000f640` calls
`decObj->vtbl[+0x28]` = `FUN_1000e170` for the 32 kHz object; `FUN_1000e170` in turn drives the
16 kHz object (`decObj[+0x04]`) and, below it, the 8 kHz core `FUN_10009520`. Bit order is
therefore **8 kHz core first, then the 16 kHz band, then the 32 kHz refinement**.

**Mode selection.** The 8 kHz core (`FUN_10009520`) reads

```
wideband_flag = read1()          ; observed 0 in every Jorge frame
mode8         = read(4)          ; observed 7 in every Jorge frame
```

The 16/32 kHz driver `FUN_1000e170` reads

```
f = read1(); if (f) { skip(1); m = read(3) }   /* 32 kHz: m = 1 (band table 0x10023cd0) */
if (m != 0 && modeArray[m] == 0) log("Invalid mode encountered: corrupted stream?"); return -2
```

`modeArray` for 32 kHz is `0x10023cd0` = `[0, 0x10023a70, 0, 0, …]`, so **m = 1** is the only
valid coded mode; m = 0 selects the "no new data" concealment path.
The 8 kHz mode table (indexed by `mode8` = 7) is the 8-entry array at `0x100239ec/0x100239f0`
whose mode-7 object is `0x100238f8` (5-stage LSF decoder `0x1000b510`, 3-tap pitch `0x10006bb0`
with descriptor `0x100237e4`, segmented codebook `0x100029c0` with descriptor `0x10023834`).

### 6.4.1 Exact bit-field layout (verified)

A live trace of the real decoder's bit-reader calls for one frame gives the complete sequence of
field widths below.  The parser in `tools/codec210.py` reproduces this and consumes **all 880
bits** of the 110-byte block with no overrun, for every frame tested.

| # | field | width | call site | meaning |
|---|---|---|---|---|
| 8 kHz core (`FUN_10009520`) | | | | |
| 1 | wideband flag | 1 | `0x100095aa` | 0 = narrowband core |
| 2 | mode8 | 4 | `0x10009677` | 7 |
| 3-7 | LSF stage indices | 5 × 6 | `0x1000b54e/b64a/b6d2/b75a/b7e4` | 5-stage order-10 VQ (`FUN_1000B510`) |
| 8 | **frame energy** | 5 | `0x1000999b` | drives the frame gain (§6.6) |
| 9-… | ×4 sub-frames: | | | |
| | pitch index | 7 | `0x10006bdd` | 3-tap LTP gain table index |
| | pitch lag | 7 | `0x10006bf1` | integer lag |
| | extra | 3 | `0x10009d18` | |
| | codebook indices | 16 × 6 | `0x10002a56` | segmented innovation (`FUN_100029C0`) |
| 16 kHz band (`FUN_1000e170` 16 kHz object) | | | | |
| | skip | 0 | `0x1000e228` | |
| | flag | 1 | `0x1000e237` | 1 |
| | mode | 3 | `0x1000e23f` | (3 or 4 observed) |
| | LSF indices | 2 × 6 | `0x1000c118/c1d5` | 2-stage order-8 VQ (`FUN_1000C0D0`) |
| | ×4 sub-frames: | | | |
| | sub-frame gain | 4 | `0x1000e679` | 4-bit gain index (0..15) |
| | innovation | 10 × (1 sign + 7 index) | `0x10002a33` / `0x10002a56` | 10 × 8-sample vectors = 80 samples |
| 32 kHz refinement | | | | |
| | skip | 0 | `0x1000e228` | |
| | flag | 1 | `0x1000e237` | 1 |
| | mode | 3 | `0x1000e23f` | 1 |
| | LSF indices | 2 × 6 | `0x1000c118/c1d5` | 2-stage order-8 VQ |
| | refinement | 4 × 5 | `0x1000e5e6` | |

Total: 40 + 4·113 + 16 + 4·84 + 16 + 20 = **880 bits = 110 bytes exactly**.

### 6.5 Spectral (LPC/LSF) stage — verified

* **LPC order 8** at 32/16 kHz (`decObj[+0x18]`, from sub-descriptor `0x10023ca8[+0x0C]`;
  *not* the file-header `Rank=10`); order 10 in the 8 kHz core.
* **LSF dequantisers.** Two of them, both fully recovered and checked against the decoder's own
  LSF arrays:
  * 8 kHz core, `FUN_1000B510`, order 10, 5 stages:
    `lsf[i] = ramp10[i] + s1[i1][i]/256 + s2lo[i2][i]/512 + s3lo[i3][i]/1024` for `i < 5`, and
    `+ s2hi[i4][i-5]/512 + s3hi[i5][i-5]/1024` for `i >= 5`, with the table set
    `0x10022e60 (64×10), 0x100230e0, 0x10023220, 0x10023360, 0x100234a0 (64×5 each)` and
    `ramp10[i] = 0.25·(i+1)`.
  * 16/32 kHz band, `FUN_1000C0D0`, order 8, 2 stages:
    `lsf[i] = ramp8[i] + t1[i1][i]/256 + t2[i2][i]/512`, tables `0x10022870` / `0x10022a70`
    (64×8 each), `ramp8[i] = 0.75 + 0.3125·i`.
  The ramps were recovered by requiring the residual to be exactly linear; the reconstruction
  then matches the decoder's arrays to float precision on every frame tested.
* **LSF → LPC** (`FUN_10005080`) — standard P/Q sum/difference:
  `P(z) = (1+z⁻¹)·Π_{even i}(1 − 2cos(w_i)z⁻¹ + z⁻²)`, `Q(z) = (1−z⁻¹)·Π_{odd i}(…)`,
  `A(z) = ½(P(z)+Q(z))`. The LSF array holds **radians in (0,π)**; `FUN_10004af0` is literally
  `cos` (double constants `0x10022e18` = π, `0x10022e40` = π/2), and `2.0` at `0x10022e58` is
  the recurrence factor. **Verified**: the port reproduces the decoder's `obj+0x58` coefficient
  array (e.g. `[1.2427, 1.0604, 0.5535, 0.3029, 0.719, 0.723, 0.4204, 0.13]`) exactly.
* Between sub-frames the LSF is interpolated (`FUN_10005520`, `prev·(1−t) + cur·t`,
  `t = (sf+1)/nsubf`) and stabilised (`FUN_10005390`, minimum spacing `0.05`).
* Synthesis is a direct-form all-pole filter (`FUN_100030e0` / `FUN_10002f80`), with bandwidth
  expansion (`FUN_10002cc0`, factors `mode[0x30/0x34/0x38]`).

`FUN_100047c0` (Levinson-Durbin, regulariser `0.003`) and `FUN_10004a00` (autocorrelation, noise
floor `10.0`) belong to the encoder-side helpers; `FUN_10004b80`/`FUN_10004cb0` are the LPC→LSF
analysis direction.

### 6.6 Excitation / gains / synthesis

**Architecture.** Two 64-tap QMF/polyphase filters `FUN_10003960` (coefficient tables
`0x100240a8` and `0x100241a8`, an exact quadrature pair — identical magnitudes, sign-alternating
taps) split/recombine the signal.  **Verified** final combine (`FUN_1000c290`):
`out[i] = clamp(round(2·(A[i] − B[i])))` (factor `2.0` at `0x10022e58`; clamps `32767.0` /
`−32768.0` at `0x10023658` / `0x1002364c`) where `A` = the 32 kHz object's `obj+0x38` buffer and
`B` = `obj+0x3C`, each **640 floats**.  A direct read of those two buffers reproduces the real
decoder's 640 output samples with correlation **1.000000**.  The port cannot yet construct `A`/`B`
(§10.2), so it substitutes a direct wideband LPC synthesis of the 32 kHz band with 2×
interpolation.

**Frame energy.** The 5-bit field read at `0x1000999b` right after the 8 kHz LSF is the frame's
transmitted energy/gain index.  It correlates 1:1 with the reference decoder's output level
(`g8 = 0` → RMS ≈ 1.5; `g8 = 27` → RMS ≈ 4900), i.e. the log-gain quantiser is at the *frame*
level, while the 4-bit per-sub-frame index only moderates it.

**Adaptive codebook (pitch).** `FUN_10006bb0(hist, baseLag, _, _, pitchDesc, blockLen, pOutLag,
gains, bitreader, _, normFlag, normCond, normLimit, mul)`, blockLen = 40:

```
lagDelta = read(7)                     ; pitchDesc[2] = bits_lag
lag      = lagDelta + baseLag          ; baseLag = 0x11 (17) for the 8 kHz core
idx      = read(7)                     ; pitchDesc[1] = bits_idx
g0 = int8[tbl + 3*idx    ] / 64 + 0.5  ; tbl = pitchDesc[0] = 0x10022150, scale 1/64 = _DAT_100235e8
g1 = int8[tbl + 3*idx + 1] / 64 + 0.5
g2 = int8[tbl + 3*idx + 2] / 64 + 0.5
if normFlag and normCond < lag:        ; optional gain normalisation
    if normLimit > 0.95: normLimit = 0.95
    limit |g0|+|g1|+|g2| (negatives scaled by _DAT_10022148) to <= normLimit
outLag = lag
```

The synthesis is a **3-tap integer-lag LTP** applied in place over the history `h` (`param_1`),
reading the three samples behind the lag (zero outside the valid range):

```
for i in 0..blockLen-1:
    out[i] = g2*h[i-lag-1] + g1*h[i-lag] + g0*h[i-lag+1] + eps     ; eps = _DAT_10023618
```

i.e. `h[-lag-1..-lag+1]` are the three taps, so `h` points into a ring that already holds at least
`lag+1` samples of the previous synthesis output.  The three tap buffers are materialised
(`local_c[0..2]`) before the in-place write, which is why the function copies the history first.

**Fixed codebook.** `FUN_100029c0` — segmented vector codebook (see §6.4.1); the 8 kHz core calls it
**twice** per sub-frame with descriptor `0x10023834` = `{dim 5, count 8, table 0x10021bd8, bits 6,
sign 0}` (no sign bits → 8 indices of 6 bits per call, 16 total = 40 samples of excitation), each
followed by `FUN_10002da0` scaling.

**Gain.** The real per-sub-frame dequantiser is hidden behind MSVC floating-point helper mangling
in the decompilation (`FUN_10011aec` = the 4-bit/5-bit index dequantiser).  This is the one stage
that had to be **fitted** rather than ported: the port uses `gain = A·B^g8 · sub[gidx]` with
`A = 2.82843`, `B = 1.30` and a 16-entry `sub[]` refinement, obtained by least-squares fitting of
the port's output RMS to reference PCM from the real DLL over frames 0..199.

**Concealment / mode 0.** `FUN_1000def0` synthesises a whole frame of uniform noise
(`FUN_100072a0` = LCG `s = s·0x19660D + 0x3C6EF35F`) through the LPC and band filters; it is used
when the mode array entry is null ("no new data").  `FUN_1000e8f0` is the decoder control entry
(mode index, post-filter on/off, reset).


---

## 7. Tables

`tools/codec210_tables.json` (regenerate with `tools/codec210_extract.py`) contains, for every
entry, both its VA and its file offset:

* `plugin_dispatch_table` — the 8 `{name, func}` entries at `0x1002e028`;
* `util_symbols` — the 5 `{name, slot}` entries at `0x1002e000`;
* `vtables` — the 8/16/32 kHz class descriptors `0x1002393c`, `0x10023ab4`, `0x10023b2c`
  (24 pointer slots each) with the rate index and sub-block count;
* `class_substructures` — the sub-descriptors `0x10023ca8` / `0x10023bf8`, the band descriptors
  `0x10023a70` / `0x10023a90` and the mode arrays `0x10023cd0` / `0x10023c38`;
* `mode_table_32k` / `mode_objects` — the 8 mode objects `0x100236b8 … 0x10023970`;
* `codebooks` — every int8 DSP codebook with its full contents:
  * LSF VQ: `0x10022e60` (64×10, ×1/256), `0x100230e0` (64×5, ×1/512), `0x10023220` (64×5, ×1/1024),
    `0x10023360` (64×5, ×1/512), `0x100234a0` (64×5, ×1/1024), `0x10022870` / `0x10022a70` (64×8,
    ×1/256 and ×1/512);
  * innovation: `0x10021278` (16×10), `0x10021318` (32×10), `0x10021458` (32×20),
    `0x10021bd8` (64×5), `0x100216d8` (256×5), `0x10021d18` (256×8);
  * pitch 3-tap gains (×1/64, +0.5): `0x100222d0`, `0x10022150`, `0x10022330`, `0x10022470`;
* `band_filters_qmf` — the 64-float QMF pair `0x100240a8` / `0x100241a8`;
* `fixed_codebook_descriptors` (`0x10023708`, `0x1002376c`, `0x100237d0`, `0x10023834`,
  `0x1002388c`, `0x100238e4`) and `pitch_descriptors` (`0x100236fc`, `0x1002371c`,
  `0x100237c4`, `0x100237e4`), each 8 dwords `{dim, count, table, bits/index, sign-flag, …}`;
* `referenced_globals` — all 452 `_DAT_/DAT_` globals referenced by the codec, each given as
  `u32`/`i32`/`f32`/`f64`;
* `annotations` — the constants whose *type* matters (the `.rdata` block at
  `0x10022exx`/`0x1002127x` is **doubles**, at `0x10023exx`/`0x10024xxx` **floats**).

There are **no runtime-generated DSP tables**: everything the decoder needs is static `.rdata`
(the mode arrays are static pointer tables into the class descriptors).  The only runtime-built
state is the 0x74-byte decoder instance (§3.2) and its `calloc`'d float buffers.

---

## 8. Msx comparison (summary)

`LTTS7CodecMsx.dll` (Jorge build, MD5 `bcb605086bbdc213a0a936823c73c54d`) has the **same plugin
shape** — a single named export that is a name→pointer dispatcher over an 8-entry `{name,func}`
table with the same eight names in the same order (`LoadUtilSymbols` first). Differences:

* dispatcher RVA `0x2A90` / table VA `0x10015ae0` (210: `0x4760` / `0x1002e028`);
* larger, different context; the streaming-header fields sit at different offsets
  (rate/byte/sample fields around `+0x11D0..+0x11D4`, XOR key at `+0x47A`, and a pointer to a
  separate bit-layout sub-object at `+0x11EC`);
* it exposes sub-band (narrow/wide/ultra-wideband) mode-query strings;
* it does **not** use the 28-byte 210 sub-header: its per-frame byte length comes from the main
  0x7C container header (`+0x10`) and its XOR key from `ctx+0x47A`.

Msx is therefore *not* bit-compatible with 210; both are independently addressable members of the
same plugin family. (Jorge `LTTS7CodecMsx.dll` is a *different, newer* binary than the older
`engine_re/LTTS7CodecMsx.dll`; the REPORT.md Msx column predates it.)

---

## 9. Validation protocol (oracle)

`tools/codec210_oracle.py` maps `LTTS7Codec210.dll` into Unicorn, fills the five Util slots with
Python implementations of `ELQmalloc`/`ELQfree`/`ELQLogWrite`/`ELQBinGetBuffer`/`ELQstricmp`, maps
a TEB/page 0 for the MSVC SEH prologues, replaces the CRT allocator entry points
(`0x100071e0`, `0x10011111`, `0x10011151`, `0x100071f0`, `0x1001136c`, `0x10007200`) with a Python
allocator (their SEH prologues do not emulate), and sets `FPCW = 0x037F` (Unicorn starts with all
x87 exceptions unmasked, which makes the MSVC math helpers raise). It then

1. calls `ELQOpenDecoder(&ctx, 32000, 0)`,
2. calls the reset routine `FUN_10004230(ctx)` to build the decoder object,
3. per frame: copies 110 raw bytes into a buffer and calls the register-based driver
   `FUN_10004290` with `ESI = ctx`, `EDI = buffer`,
4. reads 640 `int16` from `ctx+0x11D4`.

Reference RMS (Jorge DB, frames 0..199, per 10 frames): frames 0–29 ≈ 2 (silence), then
2 200–3 900 (speech) — a plausible envelope. Decoding the same block with the XOR key forced to
`0x00` or `0xFF` produces an illegal mode and crashes, confirming key `0x6D`.

---

## 10. Porting status of `tools/codec210.py`

| stage | status | evidence |
|---|---|---|
| container header + TLV parsing | **ported & verified** | matches ELQBinContainer facts; size identity exact |
| sub-header (7 BE u32) parse | **ported & verified** | vs `ELQDecode` disasm |
| block extraction (`150 + 110*i`) | **ported & verified** | `ELQBinGetBuffer` offset math |
| per-block XOR (`^ cookie&0xFF`) | **ported & verified** | oracle A/B: key `0x6D` decodes, `0x00`/`0xFF` crash |
| MSB-first bit reader (+ `peek1` = `FUN_10001240`) | **ported & verified** | 1:1 with `FUN_100011d0`/`0x10001240`/`0x10001280`/`0x100012c0` |
| frame bit-field layout (§6.4.1) | **ported & verified** | consumes 880/880 bits, `err == 0`, every frame |
| LSF VQ (order 10 / order 8) | **ported & verified** | reproduces the decoder's LSF arrays exactly |
| LSF interpolation / stabilisation (`FUN_10005520` / `0x10005390`) | **ported** | verbatim from the decompilation |
| LSF → LPC | **ported & verified** | reproduces the decoder's `obj+0x58` coefficients exactly |
| LPC synthesis (`FUN_100030e0`, transposed DF-II) | **ported** | verbatim from the decompilation |
| segmented fixed codebook (`FUN_100029c0`) | **ported** | descriptor `0x10023a5c` = {dim 8, count 5, bits 7, sign} for the 16 kHz band; `0x10023834` = {dim 5, count 8, bits 6, no sign} for the 8 kHz core |
| final combine (`FUN_1000c290`) | **verified** | `out = clamp(round(2·(A−B)))`, corr 1.000000 vs the real DLL |
| frame energy / sub-frame gain | **speculative (fitted)** | `A·B^g8` fitted to reference PCM; real dequantiser hidden behind FP-helper mangling |
| band filter `FUN_10003960` | **ported & verified** | polyphase 2× QMF; reproduces the real DLL's output with corr 1.000000 on all four calls of frame 37 |
| sub-band cascade / excitation wiring | **not ported** | ring window + noise/coded excitation of each level (§10.2) |
| 3-tap pitch / adaptive codebook | **not ported** | structure documented from `FUN_10006bb0` |

The decoder returns a `stages` dict in its trace marking each of these explicitly.

### 10.1 Prototype results (acceptance evidence)

`python3 tools/codec210.py` decodes real blocks from
`Jorge.32000.LTTS7Codec210.44000.10.bin`, returns exactly 640 int16 per block without exception,
and prints RMS per 10 frames.  Compared with reference PCM produced by the real DLL
(`tools/codec210_oracle.py`):

| frames | this port | reference DLL |
|---|---|---|
| 0–9 | 1.5 | 2.0 |
| 10–19 | 1.6 | 1.6 |
| 20–29 | 1.9 | 1.7 |
| 30–39 | 1428 | 2237 |
| 40–49 | 2865 | 2985 |
| 50–59 | 4200 | 2797 |
| 100000–100009 | 2384 | 2118 |
| 100010–100019 | 1854 | 2567 |

The silence→speech transition and the energy envelope are reproduced to within about 2×.

### 10.2 Waveform accuracy — correlation 0.51 (target 0.9 not yet reached)

After the 8 kHz chain was completed (exact LTP + the clear→LTP→CB1→CB2 accumulation with the
measured gain law `C(g8)·q[b3]`), the end-to-end correlation against the real DLL rose from **−0.05
to +0.51** over frames 0..119, with the energy envelope tracking the reference closely (port 1.5 /
1823 / 2223 / 3400 / 3556 / 2108 versus reference 1.8 / 1582 / 2893 / 3125 / 3163 / 2699 per
20-frame block).  The remaining gap is the two unported upper bands:

* **B32 — the 32 kHz noise branch** (`read(5)` + its dequantiser + noise source + ramp
  `_DAT_100242f8` + LPC-tilt gain): ≈13 % of A32 on voiced frames.
* **the 16 kHz coded branch** (`read(4)` + 2 × codebook, descriptor `0x10023a5c`).

`tools/codec210.py` currently computes `out = clamp(round(2·A32))` with B32 omitted, so those two
branches are the whole remaining error.  Everything below them is exact or measured (§10.3, §10.6);
the write-region map needed to port them is in §10.7.

(Historical note: before the 8 kHz chain was completed the port measured an overall correlation of 0.006 over frames 37..42; those numbers are superseded by the table in §10.6.)

### 10.3 Per-stage validation table (measured against the real DLL)

Every stage below was measured with the oracle, feeding **the real decoder's own buffers** into the
Python implementation where a stage is a pure function.  This localises exactly where the chain
breaks.

| stage | test | measured |
|---|---|---|
| bit reader + frame parse | bits consumed / error flag | 880/880, `err=0` — exact |
| LSF VQ (order 10 / 8) | vs the decoder's own LSF arrays | exact (float) |
| LSF → LPC | vs the decoder's own `obj+0x58` | exact (float) |
| **band filter `FUN_10003960`** | oracle `src`/`tail` → oracle `dst` | **corr 1.000000** (4/4 calls, max abs diff ~5e-4) |
| **output combine** | oracle `obj+0x38`/`obj+0x3C` → reference PCM | **corr 1.000000** |
| 16 kHz filter input | oracle `o16+0x2C[:160]` vs oracle `o8+0x30[:160]` | corr **1.0000** — the 16 kHz A-filter input *is* the 8 kHz core synthesis output |
| 32 kHz filter input | oracle `obj32+0x2C[:320]` vs oracle `A16` | corr 0.958 (f37) / 0.998 (f38) — the ring copy is near-exact |
| A-path contribution | `2·A32` vs reference PCM | corr 0.991 (f37) / 0.9997 (f38) — B is small on voiced frames |
| 8 kHz excitation (first unported stage) | oracle excitation vs oracle pitch-output buffer | corr **1.0000**, ratio 1.0 — **the 8 kHz excitation *is* the LTP (pitch) output**; the two `FUN_100029c0` passes write to separate scratch buffers and are not added to it |
| LTP reproduction | my 3-tap LTP from the buffer preceding `h` vs oracle pitch output | corr **0.39–0.69** |
| LTP free fit | optimal 3-tap least squares over all (lag, tap-offset) pairs | only **0.57–0.61** |
| LTP single-tap scan | best single delayed tap over ±1500 samples | only **0.69** |
| LTP window search | best-matching 40-sample window anywhere in `0x3000e000..0x30013000` | corr **0.58** |
| full port | my PCM vs reference PCM | corr **0.006** |

**Where the chain breaks.** The cascade is
`8 kHz core synthesis (o8+0x30) → A16 = band_filter(...) → A32 = band_filter(...) → out = 2·(A32 − B32)`
and everything from the 8 kHz synthesis output upwards is exact and validated.  The **first unported
stage is the 8 kHz core LTP** (`FUN_10006bb0`), characterised as follows:

* **the 8 kHz excitation *is* the LTP output** — the oracle's `LPCsynth` input (`0x30011ea0 + 40·sf`)
  equals the buffer the pitch writes (`o8+0x3C + 40·sf`) with correlation **1.0000** and ratio 1.0.
  The two `FUN_100029c0` passes (descriptor `0x10023834` = dim 5, count 8, bits 6, no sign, table
  `0x10021bd8`) write to *separate* scratch buffers and are **not** added to the excitation;
* complete argument list (frame 38, captured from the oracle):
  `(0x30012364+40·sf, 17, 144, 0, 0x100237e4, 40, &stack, &stack, ctx, 0x3000e0a4, 0, 40·sf,
  0x4002e000, 0)` — arg1 = history/output base, arg2 = base lag (17), arg5 = pitch descriptor,
  arg6 = block length (40), arg9 = bit reader, arg10 = 120-float scratch (inside `o8+0x2C`),
  arg13 = the normalisation limit (2.04, clamped to 0.95), arg14 = 0 (so the gain table base is
  exactly `0x10022150`);
* bit fields in order: `lagDelta = read(7)`, `idx = read(7)`; `lag = lagDelta + 17`;
  gains `g0,g1,g2 = int8[0x10022150 + 3·idx + k]/64 + 0.5` (the table is 128×3 = 384 bytes — the
  extractor originally truncated it to 96).  Normalisation (`Σ|g| ≤ 0.95`) is gated on
  `arg11 != 0`, which is **0 for every sub-frame**, so it never fires;
* the disassembly confirms the three taps: three delayed windows of `arg1` are copied into the
  scratch slots (`local_c[k] = arg10 + k·40` floats) and combined as
  `out[i] = g2·h[i−lag−1] + g1·h[i−lag] + g0·h[i−lag+1] + 1e-15`;
* **unresolved contradiction**: implementing exactly that (with `h` = the buffer immediately
  preceding `0x30012364`, i.e. `o8+0x38` + the earlier sub-frames' LTP output) gives only
  corr 0.39–0.69, and a *free* 3-tap least-squares fit over all (lag, tap-offset) pairs reaches
  only 0.57–0.61; a single-tap scan over ±1500 samples peaks at 0.69; and **no** 40-sample window
  anywhere in the 8 kHz object's heap region (`0x3000e000..0x30013000`) matches the LTP output
  (best |corr| 0.58).  Since the code's own formula is optimal-but-failing, the **history signal
  supplied to `arg1` is not the excitation/ring I am reading** — i.e. the buffer at `o8+0x38`
  (160 floats immediately before the LTP output) is not the running excitation history that the
  caller maintains.  Note that at frame 37 sub-frame 0 that region held only ~1-magnitude values
  while frames 30–36 were already voiced, which supports this.  Locating the true history buffer
  (and how the caller primes it at `o8+0x38`) is the single remaining unknown.

**Concrete remaining work to reach correlation ≥ 0.9**

1. Find and reproduce the **history buffer handed to `FUN_10006bb0` as arg1** (the LTP ring).  The
   scratch slots are known (`arg10 = o8+0x2C + 33` floats, 3×40), the taps and gains are known, so
   only the ring's memory and its per-frame priming are missing.  Validate against the oracle's
   LTP-output buffer (`o8+0x3C + 40·sf`, 40 floats) across frames 0..40 — target corr ≥ 0.99.
2. Then the **32 kHz noise excitation** (`read(5)`, `FUN_10011aec`, `FUN_10002ec0`, ramp
   `_DAT_100242f8`, `_DAT_100242a8 = √2`, tilt normaliser) which feeds B32.
3. Then the **16 kHz coded branch** (`read(4)` + `FUN_100029c0` twice, descriptor `0x10023a5c`).
4. Replace the fitted frame-energy map with the exact dequantiser; carry state from frame 0.

Because the A path is exact above the 8 kHz LTP and A dominates the output
(`corr(2·A32, out) = 0.991`), item 1 alone should lift the overall correlation to roughly the
0.9 threshold; items 2–4 close the rest.

### 10.4 The two "gain" helpers are not codec functions

Disassembling the two helpers that the decompilation attributes the innovation gain to:

* **`FUN_10002ec0(ptr, n)` IS a plain energy**: `fldz;` then `fld [p]; fmulp st,st; fadd` over `n`
  floats — i.e. `Σ p[i]²`.  It is exact and can be ported directly (`fadd [esp+8]` accumulates into
  a float, unrolled by 4).
* **`FUN_10011aec` is an MSVC CRT intrinsic dispatcher, not a dequantiser**: its body is
  `cmp ds:0x100300cc,0; stmxcsr; and eax,0x1f80; ... fnstcw ...; jmp 0x100175d0`
  (or `mov edx,0x1002e7da; jmp 0x10017ade/0x10017cb1`), i.e. the standard `__cintrindisp` wrapper
  that selects an x87/SSE path for an intrinsic (a conversion or math helper).  It therefore cannot
  be "ported" as a gain law; the gain arithmetic must be read from the **call site inside
  `FUN_10009520`** (the 8 kHz core), where the 5-bit/4-bit index is consumed.

Consequently the innovation gain in `tools/codec210.py` is still the fitted
`exc_scale * 0.431*1.3304^g8 * q[b3] / gden` (with the 8-entry `q` table measured from the
`FUN_10002da0` scale arguments and `gden` the LPC-tilt normaliser).  The exact replacement is:
read the gain arithmetic at the `FUN_10009520` call site, using `FUN_10002ec0` (now identified as
`Σ x²`) for the energy term, and delete the fitted constants.

### 10.5 Final state after implementing the exact 8 kHz LTP

`tools/codec210.py` now implements the decode chain end to end:

```
parse 880-bit frame -> 8 kHz excitation (LTP + innovation) -> 8 kHz LPC
synthesis -> A16 = band_filter(..., coefA) -> A32 = band_filter(..., coefA)
-> out = clamp(round(2*A32))            [B32, the 32 kHz noise branch, omitted]
```

* **8 kHz LTP — EXACT**: `buf[0:145] = buf[160:305]` per frame (the `0x100096fc`
  memmove), then per sub-frame `S = buf[p-(lag+1) : +120]`,
  `out[i] = g[2]*S[i] + g[1]*S[40+i] + g[0]*S[80+i]`,
  `lag = read(7)+17`, `g[k] = int8[0x10022150+3*idx+k]/64+0.5`, `idx = read(7)`.
  Verified by the project owner with zero residual on 12/12 calls.
* **8 kHz innovation — STRUCTURE ported, gains FITTED**: the excitation is
  `LTP + gain*CB1 + (gain/2.2)*CB2` with `CB1/CB2` = two `FUN_100029c0` passes
  (descriptor `0x10023834` = dim 5, count 8, bits 6, no sign, table
  `0x10021bd8`) — the two-block split of the 16 sub-frame indices is confirmed
  by the measured scale-call arguments (the ratio CB1:CB2 gain is exactly 2.200
  in every sub-frame of every frame measured).  The gain itself is
  `exc_scale * 0.431*1.3304^g8 * q[b3] / gden` with a fitted 8-entry `q` table
  and `exc_scale = 0.5`; `g8` is the 5-bit frame energy, `b3` the 3-bit field and
  `gden` the LPC-tilt normaliser `(Σ(lpc[i]+lpc[i+1]) + 0.01)/(0.01 + Σ(lpc[i+1]−lpc[i]))`.
  The real `FUN_10011aec` (index dequantiser) and `FUN_10002ec0` (energy) are
  **not ported**, so this is the one stage that remains fitted.
* Output RMS envelope (frames 0..59, per 10): `0.0, 0.0, 0.0, 5002, 2239, 1988`
  vs the reference `2.0, 1.6, 1.7, 2237, 2985, 2797` — the silence→speech
  transition and the steady-state level now match closely.
* **End-to-end correlation is still NOT reached**: −0.14 over frames 0..59
  (per-10-frame: −0.09, −0.07, 0.00, −0.08, −0.18, −0.48).  The waveform is not
  reproduced, so the fitted innovation gain is still the blocking stage.

Honest summary of what remains: `FUN_10011aec` (the 4/5-bit innovation index
dequantiser) and `FUN_10002ec0` (the per-sub-frame excitation energy feeding the
gain) must be ported to replace the fitted `q` table and `exc_scale`; then the
32 kHz noise branch (B32) and the 16 kHz coded branch close the chain.

### 10.6 Final state: gain law fixed, correlation 0.51

**Root cause of the divergence found**: the innovation gain is exactly
`gain = C(g8) · q[b3]` with `C(g8) = 0.430 · 1.3305^g8` and
`q = [0.147, 0.382, 0.69, 1.0, 1.30, 1.679, 2.39, 3.098]` — **no per-sub-frame LPC-tilt factor**.
My earlier `gden` term (from the 32 kHz band's decompilation) made the gain negative and 3–15× too
large, which is what blew the adaptive-codebook recursion up by 50×.  With `gden` removed the
codebook RMS comes out at **973 — exactly the measured `FUN_10002da0` result** for frame 38 sf0
(gain 1245.3 × unit codebook RMS 0.782 = 973), and the port's per-sub-frame codebook unit RMS
(0.78–1.12) matches the real one (0.78).

The excitation accumulation is also confirmed against the parent's write timeline: per sub-frame the
8 kHz core clears `buf[h:h+40]`, writes the LTP output, then accumulates CB1 and CB2 into the same
buffer (which doubles as the adaptive-codebook history for the next sub-frame), and the LPC
synthesis then filters it in place.  `tools/codec210.py` reproduces that sequence.

**Codebook mapping validated against the golden dataset** (`jorge_re/exc_stages_frame38.json`, the
per-sub-frame excitation after clear / after LTP / after CB1 / after CB2).  The measured increments
are *exactly* the port's codebook vector times the measured gain:

| sf | CB1 increment[:5] | port codebook[:5] | ratio | CB2 increment[:5] | port codebook[:5] | ratio |
|---|---|---|---|---|---|---|
| 0 | −116.74, −2646.17, 194.57, 1362.0, 272.4 | −0.09, −2.12, 0.16, 1.09, 0.22 | ≈1245 | 17.69, 88.44, −265.32, 866.73, −1167.4 | 0.03, 0.16, −0.47, 1.53, −2.06 | ≈566 |

i.e. the mapping **is** `8 six-bit indices → 8 concatenated 5-sample segments of table 0x10021bd8 ×
(1/32) × gain`, with `gain_CB1 = C(g8)·q[b3]` (1245.3 measured) and `gain_CB2 = gain_CB1/2.2`
(566.0 measured).  The port's own excitation matches the golden vectors at corr 0.66–0.70 (rms
1293 vs 1273 / 524 vs 431 / 3223 vs 3430) — the residual is in the **LTP history** (my per-sub-frame
state differs from the real one), not in the codebook or the gain.

**Output-path amplitude (measured with `exc_scale = 1.0`)** — the scale is exact in the excitation, so
the remaining factor is in the A-path.  Comparing the real 32 kHz buffers with the port:

| frame | rms(A32 real) | rms(B32 real) | rms(2·(A−B)) | rms(port pcm) |
|---|---|---|---|---|
| 37 | 617.5 | 83.2 | 1246.6 | 675.9 |
| 38 | 2382.0 | 53.3 | 4765.1 | 1954.4 |
| 39 | 2539.1 | 30.6 | 5078.5 | 890.9 |

`rms(2·(A−B))` matches the reference PCM (1246.6 vs 1259.7 at frame 37), confirming the combine is
exact, but the port is 1.8× / 2.4× / 5.7× too **small** and the ratio is *not constant* — so the
A-path differs in content, not merely by a gain.  Candidates: the 8 kHz LPC synthesis absolute gain,
a per-stage ½ polyphase gain in the two `band_filter` stages (which would give ¼), or the 16 kHz
branch feeding A16 (the port feeds the 8 kHz synthesis directly).  Because the port's excitation now
matches the golden vectors at corr 0.66–0.70, the residual is the **LTP history propagation** (per
sub-frame state) plus the two unported upper bands.

With `exc_scale = 1.0` the end-to-end correlation is **0.510** over frames 0..119 (identical to the
3.5-scaled run, as expected since the correlation is scale-invariant) with the per-20-frame values
0.39 / 0.55 / 0.47 / 0.59 / 0.48 / 0.47.

| frames | port RMS | reference RMS | correlation |
|---|---|---|---|
| 0–19 | 1.5 | 1.8 | **+0.513** |
| 20–39 | 1823 | 1582 | +0.510 |
| 40–59 | 2223 | 2893 | +0.457 |
| 60–79 | 3400 | 3125 | +0.566 |
| 80–99 | 3556 | 3163 | +0.549 |
| 100–119 | 2108 | 2699 | +0.459 |
| overall | — | — | **+0.513** |

So the energy envelope now tracks the reference closely (the one calibration left is a single global
output-domain factor, `exc_scale = 3.5`, which does not affect the correlation), and the waveform
correlation rose from −0.05 to **+0.51**.  It is still below the 0.9 target: the missing energy is
the **B32 band**, i.e. the 32 kHz noise branch (`read(5)` + dequantiser + ramp `_DAT_100242f8` +
tilt) and the 16 kHz coded branch (`read(4)` + 2 × codebook, descriptor `0x10023a5c`).  Those are the
only two stages left; every stage below them (bit layout, LSF VQ, LSF interp/stabilise, LSF→LPC, the
8 kHz LTP, the 8 kHz innovation and its gain, the LPC synthesis, the A-band QMF chain and the final
combine) is exact or measured.

### 10.7 Write-region map of the 8 kHz core (frame 38) and the path to the last two bands

**The final stage (exact and closed).** `out[i] = clamp(round(2·(A[i] − B[i])))` where `A` = the
32 kHz object's `obj+0x38` and `B` = `obj+0x3C`, both 640 floats — correlation with the reference
output is `1.000000`.  `FUN_10003960` is a polyphase (2×) QMF band filter, ported verbatim as
`band_filter()` and validated (fed the reference decoder's own `src`/`tail` it reproduces its `dst`
with correlation 1.000000, max abs diff ~5e-4, on all four calls of frame 37).  The calls in
`FUN_1000e170` are `A = FUN_10003960(obj+0x2C, 0x100240a8, obj+0x38, obj+8, 0x40, obj+0x40, work)`
and `B = FUN_10003960(obj+0x34, 0x100241a8, obj+0x3C, obj+8, 0x44, work)` with `work = obj+0x28+320`,
immediately followed by `FUN_1000c290(out, obj+0x38, obj+0x3C)`.  The chain is a dyadic
8 kHz → 16 kHz → 32 kHz cascade in which each level fills its `obj+0x2C` from its `obj+0x28` ring
(`obj+0x2C[i] = ring[i]`) and `obj+0x34` with its own band synthesis.

Per-frame write counts by (code address → 256-byte bucket), whole frame = 4 sub-frames × 40 samples:

| code address | buckets written | role |
|---|---|---|
| `0x10009b6f` | `0x30012300/400/500` | clear the excitation sub-block to 0 |
| `0x10009c0d` | same | the LTP call (writes the LTP output) |
| `0x10009f3e` | same | accumulate CB1 |
| `0x10009ff1` | same | accumulate CB2 |
| `0x10009ced` | `0x30012500/600/700` | codebook build: clears the scratch |
| `0x10009d7d` | `0x30012500/600` | codebook build: writes the unit-scale vector |
| `0x10009d9f` | `0x30012500/600` | scale/gain application (`FUN_10002da0`) |
| `0x10007210` | `0x30012100/200/300` | writes the LTP history region |
| `0x1000a075` | `0x30012000/100` | LPC-related |
| `0x1000a14a` | `0x30012000/100` | LPC synthesis call site |

First-writes at `0x10009ced` are 0.00 (clear), at `0x10009d7d` small (0.22, −0.09) and at `0x10009d9f`
the scaled ones (−116.74, 272.40): i.e. the innovation path is exactly
**build in scratch (`0x300125f0+0xa0·k`) → scale by `C(g8)·q[b3]` → accumulate into the excitation**,
with the scratch reused per sub-frame.

Only two stages remain to reach waveform exactness, and they are the whole remaining gap:

1. **32 kHz noise branch** (produces B32, ≈13 % of A32): `read(5)` index + its dequantiser + the noise
   source + the per-sample ramp `_DAT_100242f8` + the LPC-tilt gain (the ratio
   `(obj+0x60[sf] + 0.01)/(0.01 + Σ(lpc[i+1]−lpc[i]))`, the term that must NOT be applied to the
   8 kHz coded branch).
2. **16 kHz coded branch**: `read(4)` + two codebook passes with descriptor `0x10023a5c` =
   `{dim 8, count 5, table 0x10022470, bits 7, sign}` (the 10 (sign, index) pairs per sub-frame are
   already parsed by `codec210.py`).

Method to close each (as used for the 8 kHz core): hook the band's LPC-synthesis call opcode, read the
in-place buffer **before** the callee, and reproduce the per-sample writer sequence
(clear → excitation branch → scale → accumulate); then validate stage-locally (corr ≥ 0.999) and
re-measure end to end.

### 10.8 Superseded composition test (kept for the trail)

The excitation-buffer identification was tested directly.  At the 8 kHz `FUN_100030e0` call
(`0x1000a14f`, frame 38) the arguments are
`(0x30012870 = LPC order-10, 0x30011ea0 = synthesis output, 40, 10, 0x30012930, 0x300082e0,
0x30007fe0, ctx)`.  Solving `exc ≈ a·ltp + b·cb1 + c·cb2` per sub-frame (ltp = `0x30012364+40·k`,
cb1 = `0x300125f0+40·k`, cb2 = `0x3000e0a4`) gives:

| candidate | rms (sf0/1/2/3) | solved (a,b,c) sf0 | residual sf0 |
|---|---|---|---|
| `0x30012930` | 1818 / 341 / 109 / 452 | (−0.32, 0.36, 0.74) | 1.1e4 (vs rms 1818) |
| `0x30007fe0` | 55.6 constant | (−0.01, 0.01, 0.02) | 348 |

So **neither is the excitation**: `0x30012930` varies per sub-frame but is not a 3-term combination
of the LTP and the two codebook outputs (residual ≫ signal), and `0x30007fe0` does not vary at all.
`0x300082e0` is constant across sub-frames and therefore also not the excitation (this supersedes the
earlier note that used it).

The verified facts about this stage are therefore: the LTP formula and its gains (zero residual
against the LTP output buffer, project-owner verified), the two codebook passes and their gain ratio
(CB2/CB1 = 0.4545 = 1/2.2, measured), and `C(g8) = 0.430 · 1.3305^g8` with the 8-entry `q` table
(ratios match measured gains exactly).

**New and decisive measurement**: hooking the *actual* call instruction `call FUN_100030e0` at
`0x1000a14a` (the parent's `0x1000a14a` is the call opcode; the argument list is
`(edi, obj+0x50 = LPC, edi, obj+0x10 = 40, obj+0x18 = 10, obj+0x54 = state)` with `edi` the in-place
buffer) and reading `edi` **before the callee writes** shows that the buffer the LPC synthesis
consumes is **exactly the LTP output**:

| sf | rms(exc) | lstsq `exc = a·ltp + b·cb1 + c·cb2` | residual |
|---|---|---|---|
| 0 | 1272.9 | (1.0, 0, 0) | 3e-12 |
| 1 | 431.2 | (1.0, 0, 0) | 4e-13 |
| 2 | 3429.8 | (1.0, 0, 0) | 2e-11 |
| 3 | 601.5 | (1.0, 0, 0) | 2e-12 |

So the 8 kHz excitation **is** the LTP output, and the innovation is **not** added to it at the LPC
input.  The innovation must therefore prime the adaptive-codebook history *before* the LTP runs (that
is the only way the LTP can start from a zero state).  Locating that priming write is the one
remaining link; everything else in the 8 kHz chain is measured.

**S-comparison gate (the decisive stage-local test)**: comparing the 120-float adaptive-codebook
span `S = buf[h-(lag+1) : +120]` that my port maintains against the real decoder's own span at the
pitch call (frame 38):

| sf | lag | corr(myS, realS) | rms(myS) | rms(realS) |
|---|---|---|---|---|
| 0 | 71 | −0.003 | 70 057 | 1 365 |
| 1 | 66 | −0.045 | 70 779 | 1 530 |
| 2 | 94 | −0.049 | 70 926 | 1 509 |
| 3 | 93 | −0.041 | 119 547 | 2 010 |

My history is ~50× too large and uncorrelated from the very first sub-frame, which is exactly what
the missing innovation priming predicts: the real `S` sits at the excitation scale (1.4–2.0 k, the
same order as the excitation itself), because the innovation (scaled CB output, measured rms 973 at
gain 1245 ⇒ unit rms ≈ 0.78) is folded into the history that the LTP copies, whereas my port keeps a
pure LTP recursion.  A second contributing factor is that my codebook unit scale is larger than the
real 0.78, so even the fitted sum diverges.

**Write-sequence timeline (parent-supplied sites, frame 38)**: hooking the three sites
`0x10009b6f` / `0x10009f3e` / `0x10009ff1` (all with `ebx = 0x30012364`, the excitation base) shows
that `0x30012364` is **cleared sample by sample** at `0x10009b6f` before the passes run (rms 639 →
638 → … with the leading samples going to 0 one at a time), while `0x30011ea0` — the buffer the LPC
synthesis consumes — holds a constant 1458.7 RMS throughout those sites, i.e. it is written later, by
a copy from the excitation base.  Each site carries two gain arguments in its stack frame
(`0x0983…`-style values plus 215.763 at the clear site and 1245.3 / 566.02 / 2.7489 at the others),
so the 8 kHz core **clears the excitation region and then accumulates the codebook passes plus the
LTP into it more than once per sub-frame**.

That is the arrangement my port is missing, and it explains the S-gate failure quantitatively: my
port keeps a pure LTP recursion on its own history (rms ≈ 70 k) where the real history is refreshed
every sub-frame by the cleared-and-rebuilt excitation (rms 1.4–2.0 k).  The remaining work is to
reproduce that clear → CB1 → CB2 → LTP accumulation sequence with the measured gains
(215.763 / 1245.3 / 566.02 as applicable) and then to re-run the S gate; everything else in the 8 kHz
chain is exact.

Measured call-site facts now recorded for the next agent: the 8 kHz core calls `FUN_10002da0` at
`0x10009da4` (×4) and `0x10009fda` (×4) and `FUN_100030e0` at `0x1000a14f` (×4, dst `0x30011ea0`);
the 16 kHz band calls `FUN_10002da0` at `0x1000e70f` and `FUN_100030e0` at `0x1000e84e`
(dst `0x30012f30`).

### 10.9 Investigation trail for the 8 kHz LTP (hypothesis → measurement)

Every entry is a real experiment run against the oracle; none of them reproduced the real LTP.

| # | hypothesis | measured result |
|---|---|---|
| 1 | history = the flat buffer immediately preceding `arg1` (`o8+0x38` + earlier sub-frames' LTP output); taps `g2·h[i−lag−1] + g1·h[i−lag] + g0·h[i−lag+1] + 1e-15` | corr 0.39–0.69 per sub-frame |
| 2 | **free** 3-tap least squares over every (lag 20..380, tap-offset −3..+3, 4 tap patterns) | best 0.57–0.61 (optimal weights still fail ⇒ the input signal is wrong, not the weights) |
| 3 | single delayed tap, scanning lag over ±1500 samples | best 0.69 |
| 4 | any 40-sample window anywhere in the 8 kHz heap region `0x3000e000..0x30013000` | best \|corr\| 0.58 (no window matches ⇒ the LTP output is a genuine filtered signal, not a delayed copy) |
| 5 | running-buffer recursion: `R` = concatenation of **all** LTP outputs of frames 0..40 (160/frame), taps read backwards from the sub-frame start | mean corr 0.43 over 160 sub-frames |
| 6 | in-place recursion within the current sub-frame (parent's hypothesis: taps read already-written samples when `i ≥ lag`) — equivalent to reading the pre-write buffer, which is what experiments 1–2 captured | same as #1/#2; no improvement |
| 7 | history = the **synthesis** buffer (`o8+0x30 = 0x30011ea0`) instead of the LTP output | single tap at the declared lag: −0.14, 0.02, −0.12, −0.02 |

Interpretation: the taps/gains/bit-fields are certainly right (they come straight from the
disassembly and the 14-argument call site is captured in full), and the excitation *is* the LTP
output (corr 1.0000).  A memory-write watchpoint on the LTP history region
(`0x30012000..0x30012364`) during frame 37 shows who fills it:

| writer pc | writes/frame | belongs to |
|---|---|---|
| `0x1001145a` | 290 | CRT `_memcpy`/`_memmove` (bulk copy into the region) |
| `0x1000ab5c` | 144 | `FUN_1000AB30` |
| `0x1000af15` | 144 | `FUN_1000AD40` |

So the 145-float window immediately before the LTP output (`o8+0x38`, `0x30012120`) is **refilled
every frame**.  The ordered event log for frame 37 identifies the mechanism exactly:

```
memmove(dst = 0x30012120, src = 0x300123a0, len = 580)   ; called from 0x100096fc (inside FUN_10009520)
PITCH sf0 (h = 0x30012364)
PITCH sf1 (h = 0x30012404)
PITCH sf2 (h = 0x300124a4)
writes at 0x1000a075 (32) and 0x100031dc (32) into the history window
PITCH sf3 (h = 0x30012544)
writes at 0x1000a075 (40) and 0x100031dc (40)
```

i.e. at the start of every 8 kHz frame the code **shifts 145 floats of the previous frame's LTP
output down into the history window** (`0x300123a0 → 0x30012120`, 580 bytes = 145 floats), which is
exactly the "running excitation buffer with leading history" model: the history is the previous
frame's LTP tail, `maxLag + 1 = 145` samples of it.  `FUN_10009520` (the 8 kHz core, called at
`0x100096fc`) performs the shift, and the window is additionally updated between sub-frames by code
at `0x1000a075` (in the `FUN_1000A230` family) and `0x100031dc` (inside `FUN_100030E0`).

**Numeric gain solve (requested) — does NOT reproduce.**  Reading the three scratch windows the
copy loops fill (`arg10 + k·40`, `arg10 = 0x3000e0a4`) and solving the 40×3 least-squares system
`dest[i] = g0·w0[i] + g1·w1[i] + g2·w2[i]` against the destination `h[0..39]` gives, for frame 38:

| sf | solved (g0,g1,g2) | residual | rms(dest) | table `0x10022150[3·idx]` | table at the other read |
|---|---|---|---|---|---|
| 0 | (0.466, 0.416, −0.984) | 7431 | 1273 | (−0.313, 0.734, 0.750) | (−0.125, 0.766, 0.484) |
| 1 | (0.070, −0.203, 0.272) | 2582 | 431 | (−0.078, −0.047, −0.031) | (0.609, 0.250, 0.156) |
| 2 | (−0.394, −1.299, 0.179) | 21520 | 3430 | (0.609, 0.250, 0.156) | (−0.328, −0.375, −0.094) |
| 3 | (0.701, 0.575, 0.468) | 3121 | 602 | (0.219, 0.391, 0.438) | (−0.063, 0.875, 0.016) |

The residual **exceeds the signal RMS**, so the 3-tap combination of those three windows is not the
model, and none of the table candidates matches the solved gains.  Re-running the solve with the
scratch captured **immediately after each call** (at the next call's entry, so it cannot have been
reused) gives the same verdict — residual 7924 / 2476 / 17950 against signal RMS 1273 / 431 / 3430.
So this is not a measurement artefact: the destination is genuinely not a 3-term linear combination
of the three scratch blocks.

Combined with the read trace this means the **copy loops do not build three shifted tap windows**:
they read **120 consecutive floats** (`h−72 … h+47`, split 30 reads × 4 unrolled instructions) into
the scratch — the span is exactly three contiguous 40-blocks, `h[−72..−33]`, `h[−32..+7]`,
`h[+8..+47]`, i.e. a **linearisation of a circular buffer whose period is ≈120**, and the final FIR
then combines the linearised blocks at offsets that are *not* the `lag−1, lag, lag+1` triple.  The
disassembly of the FIR tail (`0x10006dc0`–`0x10006e20` + the loop after the copies) confirms the
structure (`fld [edx−8] / fstp [eax−0x18]` … block copies, then the 4-accumulator FIR writing
`param_1`), but the exact tap offsets inside the linearised buffer are still not pinned down.

That reframes the remaining unknown: the LTP reads a **circular adaptive-codebook buffer of period
≈120 samples** (the 145-float history shift plus the 160-float per-frame LTP area), linearises it into
three contiguous 40-blocks, and runs a 3-tap FIR over the *linearised* index — with the taps taken at
offsets inside those blocks rather than at `lag−1, lag, lag+1`.  The next step is to single-step the
FIR loop (`0x10006e20` onward) and log the (source address within the scratch, coefficient address)
pairs; that yields the offsets and the coefficient strides directly.

* the function issues **120 reads** into the history/destination region, at 4 instruction
  addresses (`0x10006dc0/0x10006dcf/0x10006dd5/0x10006ddb`), 30 each;
* the addresses start at **`0x30012244 = h − 72` floats** and advance by 4 bytes with a repeating
  +16-byte stride, spanning `h−72 … h+47` (120 floats);
* `h − (lag+1)` with the declared `lag = 54 + 17 = 71` is exactly `h − 72` — so **the lag and the
  three-tap window offsets are confirmed**: the reads are `h[i−lag−1] ... h[i−lag+1]`, i.e. the
  model in §10.3 is right;
* the reads are performed *by the copy loops* into the three scratch slots (`arg10 + k·40`), which is
  why they appear as three 40-sample windows.

So the tap geometry, the lag, the bit-fields and the memory region are all confirmed.  The only
quantity that does not fit is the **gain magnitude**: at `idx = 17` the table yields
`(−0.078, −0.047, −0.031)`, yet the observed output RMS is 431, and a free 3-tap least-squares fit
over those very windows still only reaches 0.57–0.61.  The next measurement (not done here) is to
hook the *exit* of `FUN_10006bb0` and read the three gain floats it stores through `arg8`
(`0x201fe4b8`) — the store instructions are `mov [eax+…],` at the end of the gain computation — and
compare them with `int8[0x10022150 + 3·idx + k]/64 + 0.5`; that single comparison decides whether the
gain index is the first or the second 7-bit read and whether the table base is right.

Candidate causes, in order of likelihood, given everything measured:
(a) the gain **index** is the *first* 7-bit read and the lag delta the second (the widths are both 7
bits, so only the gain values can distinguish them); (b) the gains are read from a shifted table
base; (c) the output buffer that the caller reads is not `h[0..39]` but starts further into the
120-float span (the measured reads reach `h+47`, i.e. past the 40-sample destination).

The per-frame call graph with arguments (captured from the oracle for frame 37) is the map for
this work: 4 sub-frames of `{LSFinterp → LSFstab → LSF2LPC → [pitch] → 2×fixedCB → 2×scale →
LPCsynth}` for the 8 kHz core (order 10, 40 samples/sub-frame), the same with a single fixed-CB
pair for the 16 kHz band (order 8, 40 samples, descriptor `0x10023a5c`), and
`{LSFinterp → LSFstab → LSF2LPC → LPCsynth}` only (order 8, 80 samples, band replication) for the
32 kHz band.


---

# APPENDIX: specs/ELQBin.md

# `LOQUENDOTTS7` binary container (`.bin`) — `ELQBin*` layer of `LTTS7Util.dll`

Scope: the container that wraps every Loquendo TTS 7 voice database (`*.bin`) and is opened by the
`ELQBin*` API family in `LTTS7Util.dll`. Primary source: the **Jorge** build
`jorge/pf/Loquendo/LTTS7/bin/LTTS7Util.dll` (551 KiB) — decompiled to
`jorge_re/decomp_util_jorge.txt` (Ghidra headless, image base `0x10000000`) and disassembled with
`objdump -d -Mintel`. Where a claim comes from the **older** `engine_re/LTTS7Util.dll` (266 KiB,
`decomp_util.txt`) it is marked `[old build]`.

Evidence convention: `[decomp <fn> @ <addr>]` = quoted decompiled C, `[asm <addr>]` = quoted instruction
bytes, `[file]` = byte values observed in the shipped files, `[INFERENCE]` = a conclusion drawn from the
above but not directly printed by a tool.

Function-address map used below (Jorge build):

| Jorge | old build | name |
|---|---|---|
| `0x10001f80` | `0x10004ca0` | XOR-deobfuscate `(len, byteKey, ptr)`, reads global `BL` |
| `0x10001f60` | `0x10004c80` | read `u16` (LE) through a NULL-safe pointer |
| `0x10002160` | `0x10004de0` | header probe (`ELQBinaryHeaderIsPresent` workhorse) |
| `0x100022c0` | `0x10004ec0` | `ReadHeader` → `ELQDataDescriptor` |
| `0x10002550` | `0x10005100` | `FUN_10005100` wrapper (probe + version check + ReadHeader) |
| `0x10003510` | `0x10003ca0` | internal open (malloc handle, bind access type) |
| `0x10003960` | `0x100040c0` | exported `ELQBinOpen` (thunk, cache = 1) |
| `0x10003990` | `0x100040f0` | exported `ELQBinOpenNoCache` (thunk, cache = 0) |
| `0x100039c0` | `0x10004120` | `ELQBinClose` |
| `0x10003b00` | `0x10004240` | `ELQBinGetSize` |
| `0x10003b50` | `0x10004290` | `ELQBinInitSmartBuffer` |
| `0x10003b70` | `0x100042b0` | `ELQBinDeleteSmartBuffer` |
| `0x10003ba0` | `0x100042e0` | core get-buffer (`__fastcall`, unit size in `EAX`) |
| `0x10003f10` | `0x100046f0` | `ELQBinGetSmartBufferCore` |
| `0x10003f20` | `0x10004700` | `ELQBinGetSmartBuffer` |
| `0x10003f50` | `0x10004730` | `ELQBinResizeSmartBuffer` |
| `0x10003f90` | `0x10004770` | `ELQBinGetBuffer` |
| `0x10003fc0` | `0x100047a0` | `ELQBinSeek` |
| `0x10003110` | `0x10004820` | `ELQBinGetRawData` |
| `0x10003170` | `0x100048a0` | `ELQBinGetType` |
| `0x10003190` | `0x100048c0` | `ELQBinShell` |
| `0x10003220` | `0x10004930` | `ELQBinCloneEx` |
| `0x10003450` | `0x10004b90` | `ELQBinVirtualOpen` |
| `0x10002dd0` | `0x10003970` | `fopen` + size out-param |
| `0x10002e20` | `0x100039c0` | DiskCache init |
| `0x10002f40`/`0x10003020` | `0x10003ad0`/`0x10003bb0` | DiskCache block read |

The validity tag stored at handle `+0x00` is the address of `ELQBinOpen`, i.e. `0x10003960` in the Jorge
build `[asm 0x10003118: cmp DWORD PTR [eax],0x10003960]` (Ghidra prints it as the symbol `ELQBinOpen`).

---

## 1. File layout

```
file offset  size        content
0x00         1           key byte A          (consumed raw - not decoded first)
0x01         1           key byte B          (consumed raw, "keyish")
0x02         12          ASCII signature  ─┐
0x0E         2           u16 LE format_version ─┤ obfuscated with key K = A^B
0x10         2           u16 LE header_size  ─┤ (the reader XORs the whole [0,hs) block;
0x12         ...         TLV list              ─┘  A and B are read out before that)
header_size  ...         data region — NOT obfuscated (§4)
```

Note the self-consistency of the seed pair: the reader uses `raw[0]` and `raw[1]` as they appear on disk,
so even if the writer applied `K` to them the derived key would be unchanged
(`(a^K)^(b^K) == a^b`); nothing in the reader depends on the decoded values of bytes 0/1.

* 18-byte fixed prefix = bytes `0x00..0x11`; the probe reads exactly `0x12` bytes and only proceeds when
  the requested size was satisfied: `[decomp FUN_10002160 @ 0x10002160]`
  ```c
  if (*(int **)(param_1 + 9) ... )                       /* access type */
  in_EAX = (undefined1 *)FUN_10003ba0((int)param_1,0x12,0,&local_4,(uint *)0x0,&local_9);
  if ((in_EAX != (undefined1 *)0x0) && (local_4 == 0x12)) {
    bVar2 = in_EAX[1];                                   /* key byte B */
    if (unaff_ESI != (undefined1 *)0x0) { *unaff_ESI = *in_EAX; unaff_ESI[1] = bVar2; }
    FUN_10001f80(0x10,bVar2,in_EAX + 2);                 /* XOR 16 bytes: sig+fmt+hdr */
    iVar5 = _strncmp("LOQUENDOTTS7",in_EAX + 2,0xc);
    if (iVar5 == 0) {
      sVar3 = FUN_10001f60((undefined2 *)(in_EAX + 0xe));  /* u16 @0x0E = format_version */
      ...
      sVar4 = FUN_10001f60((undefined2 *)(in_EAX + 0x10)); /* u16 @0x10 = header_size */
  ```
  Note the argument order of the core reader in the Jorge build is `(bin, count, offset, outsize,
  smartbuf, outflag)`: `[asm 0x10002305: movsx edx,WORD PTR [esi+0x2]` (= header_size into `EDX` = count,
  `[asm 0x1000231b: mov eax,0x1` = unit size 1, `[asm 0x10002319: push 0x0` = offset 0.
* `format_version` must be `1`; anything else clears the info struct and the reader logs
  `"ReadHeader: Warning. Header format not supported."`
  `[decomp FUN_10002160]` `if (sVar3 != 1) { FUN_10001fb0(); }` and `[decomp FUN_10002550]`
  ```c
  if (local_10 == 1) { uVar1 = FUN_100022c0((int)unaff_EBX,unaff_EDI,param_1,local_14,param_2); return uVar1; }
  uVar1 = ELQLogWrite(8,param_2,"ReadHeader: Warning. Header format not supported.");
  ```
* Sanity gate: `header_size <= ELQBinGetSize(bin,1)` — `[decomp FUN_10002160]`
  `local_8 = *(undefined1 **)param_1[3];` … `if ((undefined1 *)(int)sVar4 <= local_8)`.

Measured prefixes (raw bytes at offset 0, and the decoded prefix):

| file | byte0 | byte1 | key | fmt | header_size |
|---|---|---|---|---|---|
| `Jorge.32000.LTTS7Codec210.44000.10.bin` | `0x2B` | `0x29` | `0x02` | 1 | 122 (`0x7A`) |
| `JorgeGildedPhrases.32000.…bin` | `0xFC` | `0x80` | `0x7C` | 1 | 148 (`0x94`) |
| `JorgeGildedParalinguistics.32000.…bin` | `0x8B` | `0x69` | `0xE2` | 1 | 164 (`0xA4`) |
| `payload/Ludoviko.16000.linear.256000.10.bin12` | `0xD0` | `0xE9` | `0x39` | 1 | 125 (`0x7D`) |

`[file]` e.g. Jorge raw `2b 29 4e 4d 53 57 47 4c 46 4d 56 56 51 35 03 02 78 02`:
`0x4E^0x02 = 0x4C ('L')` … `0x35^0x02 = 0x37 ('7')`, `0x03^0x02 = 0x01`, `0x02^0x02 = 0x00`,
`0x78^0x02 = 0x7A`, `0x02^0x02 = 0x00`.

---

## 2. Key derivation (settled: `key = file[0] ^ file[1]`)

`FUN_10001f80` really is `ptr[i] ^= <BL at entry> ^ param_2`, with the length in `ECX` and the second
byte-key in `DL` (System V/`__fastcall` register usage):

`[decomp FUN_10001f80 @ 0x10001f80]`
```c
undefined4 __fastcall FUN_10001f80(ushort param_1,byte param_2,byte *param_3)
{
  byte unaff_BL;
  uint uVar1;
  if (0 < (short)param_1) {
    uVar1 = (uint)param_1;
    do {
      *param_3 = *param_3 ^ unaff_BL ^ param_2;     /* key = BL ^ param_2 */
      param_3 = param_3 + 1;
      uVar1 = uVar1 - 1;
    } while (uVar1 != 0);
  }
  return 1;
}
```

**The instruction that supplies `BL` at the call site** — `[asm 0x100021fd..0x10002216]`, inside
`FUN_10002160` (the header probe), immediately around `call 0x10001f80`:

```
100021fd: 8a 07                mov    al,BYTE PTR [edi]        ; AL = file[0]      (EDI = 0x12-byte buffer)
100021ff: 8a 57 01             mov    dl,BYTE PTR [edi+0x1]    ; DL = file[1]
10002202: 3b f3                cmp    esi,ebx
10002204: 74 05                je     0x1000220b
10002206: 88 06                mov    BYTE PTR [esi],al        ; info[0] = file[0]
10002208: 88 56 01             mov    BYTE PTR [esi+0x1],dl    ; info[1] = file[1]
1000220b: 8d 6f 02             lea    ebp,[edi+0x2]            ; arg3 = buffer+2
1000220e: 55                   push   ebp
1000220f: b9 10 00 00 00       mov    ecx,0x10                 ; arg1 = 16 (sig + fmt + header_size)
10002214: 8a d8                mov    bl,al                    ; *** BL = file[0] ***
10002216: e8 65 fd ff ff       call   0x10001f80
```

So `BL = file[0]`, `param_2 = file[1]`, therefore **effective key `K = file[0] ^ file[1]`**, and the 16
bytes at `0x02..0x11` are decoded with `K`. The decompiler view of the same expression, in the *second*
(complete-header) reader, confirms the two key bytes come from the probed info struct
`[decomp FUN_100022c0 @ 0x100022c0]`:
```c
  bVar1 = param_4[1];                 /* key byte B (info struct, uint8 = file[1]) */
  local_10[0] = *param_4;             /* key byte A (info struct, uint8 = file[0]) */
  if (0 < (short)uVar2) {             /* uVar2 = header_size */
    uVar9 = (uint)uVar2;
    pbVar10 = local_4;                /* the 0..header_size buffer */
    do {
      uVar9 = uVar9 - 1;
      *pbVar10 = *pbVar10 ^ local_10[0] ^ bVar1;   /* f[i] ^= file[0] ^ file[1] */
      pbVar10 = pbVar10 + 1;
    } while (uVar9 != 0);
  }
```
and at instruction level `[asm 0x10002386..0x100023a7]`:
```
10002386: 8a 0e                mov    cl,BYTE PTR [esi]        ; CL = info[0] = file[0]
10002388: 88 4c 24 10          mov    BYTE PTR [esp+0x10],cl   ; spill file[0]
10002398: 8a 11                mov    dl,BYTE PTR [ecx]        ; loop body
1000239a: 32 54 24 10          xor    dl,BYTE PTR [esp+0x10]   ; ^= file[0]
1000239e: 41                   inc    ecx
1000239f: 32 d0                xor    dl,al                    ; ^= file[1]  (AL = [esi+1])
100023a4: 88 51 ff             mov    BYTE PTR [ecx-0x1],dl
100023a7: 75 ef                jne    0x10002398
```

Range: the whole header `[0, header_size)` is obfuscated, not only the 18-byte prefix — the TLV
tags/sizes/values decode to clean ASCII only when `K` is applied `[file]`, and the reader XORs
`header_size` bytes (`FUN_100022c0` loop above). Bytes `0x00`/`0x01` are read *before* the XOR and are used
as the seeds; whether they are themselves also XORed on disk is immaterial because they are consumed raw.

The older build expresses the same thing as a function call with a "global BL"
(`[old build decomp FUN_10004ca0 @ 0x10004ca0]` `byte unaff_BL; ... *param_3 = *param_3 ^ unaff_BL ^ param_2;`),
which is precisely the `unaff_BL` the ticket asks about: it is `file[0]` loaded into `BL` by the caller.

`[INFERENCE]` The two key bytes are just an obfuscation seed pair (A,B) — nothing derives them from the
filename or the content; `K = A^B` and the pairs differ per file (`0x02`, `0x7C`, `0xE2`, `0x39` observed).

---

## 3. TLV list (`0x12 .. header_size-1`)

Each entry is `u16 LE tag | u16 LE size | size bytes of payload`; strings are NUL-terminated ASCII
(counted in `size`). `[decomp FUN_100022c0 @ 0x100022c0]`:
```c
  while( true ) {
    if (pbVar10 == (byte *)0x0) { uVar3 = 0; } else { uVar3 = *(undefined2 *)pbVar10; }      /* tag   */
    if (pbVar10 + 2 == (byte *)0x0) { sVar6 = 0; } else { sVar6 = *(short *)(pbVar10 + 2); } /* size  */
    local_c = local_c + 4;
    _Size = (size_t)sVar6;
    pbVar10 = pbVar10 + 4;
    if ((int)uVar8 < (int)(pbVar10 + (_Size - (int)local_4))) break;   /* out of header -> fail */
    switch(uVar3) {
    case 1: pcVar7 = &DAT_10058634; break;     /* "Name"    (string in .rdata) */
    case 2: pcVar7 = "Label";       break;
    case 3: pcVar7 = "Comment";     break;
    case 4: pcVar7 = &DAT_1005864c; break;     /* "Freq"    */
    case 5: pcVar7 = "Coding";      break;
    case 6: pcVar7 = "BitRate";     break;
    case 7: pcVar7 = &DAT_10058664; break;     /* "Rank"    */
    case 8: pcVar7 = "Version";     break;
    default: goto switchD_1000243a_default;    /* unknown tag -> delete descriptor, fail */
    }
```

| tag | attribute name | data | notes |
|---|---|---|---|
| 1 | `Name` | ASCII | not used by the shipped voices |
| 2 | `Label` | ASCII | mirrors the filename stem |
| 3 | `Comment` | ASCII | `"Acoustic file <Label> of voice <voice>"` |
| 4 | `Freq` | ASCII integer | sample rate in Hz |
| 5 | `Coding` | ASCII | codec / voice-module tag (`LTTS7Codec210`, `linear`, …) |
| 6 | `BitRate` | ASCII integer | bit/s |
| 7 | `Rank` | ASCII integer | `10` in every shipped file |
| 8 | `Version` | ASCII `a.b.c` | container/voice version |

Observed TLV lists `[file]`:

**`Jorge.32000.LTTS7Codec210.44000.10.bin`** (header_size 122):
```
tag 2 "Jorge\0" (6)
tag 3 "Acoustic file Jorge of voice Jorge\0" (35)
tag 4 "32000\0" (6)
tag 5 "LTTS7Codec210\0" (14)
tag 6 "44000\0" (6)
tag 7 "10\0" (3)
tag 8 "7.1.0\0" (6)
```
(18 + Σ(4+size) = 18 + 10+39+10+18+10+7+10 = 122 ✔)

**`JorgeGildedPhrases.32000.LTTS7Codec210.44000.10.bin`** (header_size 148):
`2:"JorgeGildedPhrases"`, `3:"Acoustic file JorgeGildedPhrases of voice Jorge"`, `4:"32000"`,
`5:"LTTS7Codec210"`, `6:"44000"`, `7:"10"`, `8:"7.1.0"`.

**`JorgeGildedParalinguistics.32000.LTTS7Codec210.44000.10.bin`** (header_size 164):
`2:"JorgeGildedParalinguistics"`, `3:"Acoustic file JorgeGildedParalinguistics of voice Jorge"`,
`4:"32000"`, `5:"LTTS7Codec210"`, `6:"44000"`, `7:"10"`, `8:"7.1.0"`.

**`payload/Ludoviko.16000.linear.256000.10.bin12`** (header_size 125):
`2:"Ludoviko"`, `3:"Acoustic file Ludoviko of voice Ludoviko"`, `4:"16000"`, `5:"linear"`,
`6:"256000"`, `7:"10"`, `8:"7.3.0"`.

The consumers are `ELQBinaryHeader*`: `ELQBinaryHeaderGetValue` / `LoadInfo` copy these attributes into an
`ELQDataDescriptor` via `ELQDataDescriptorSetAttribute(...,ELQfree)`
`[decomp FUN_100022c0]`, and `ELQBinaryHeaderLoadInfo` walks the `*.bin` files found for a voice
`[decomp ELQBinaryHeaderLoadInfo @ 0x100026d0]` (`ELQBinOpenNoCache(&local_10,'d',...)` +
`FUN_10002550(pcVar4,param_3)` per file).

---

## 4. Data region (`header_size .. EOF`) — **raw, not obfuscated**

The container never transforms the data region: every read path copies straight out of the RAM image,
the memory mapping or the disk cache, with no XOR anywhere
(`[decomp FUN_10003ba0 @ 0x10003ba0]` `_memcpy((void *)*puVar5,(void *)(puVar6[2] + uVar4),_Size);`).
De-obfuscation is done *by the header layer* (`FUN_100022c0`, §2), never by the container. There is no
second key/period: scanning the first 64 KiB of the region against all 256 single-byte keys yields at most
2.8 % zeros (a real fixed-key XOR would concentrate ~100 %), `[file]`:
`Jorge 0xc6/1.9%`, `GildedPhrases 0xbe/1.7%`, `GildedParalinguistics 0x3a/2.8%`, `Ludoviko 0xff/14.6 %`
(the latter is raw 16-bit linear audio, whose samples are mostly `0x0000`/`0xFFFF`).

For all three **Jorge** databases the region starts with **seven big-endian `u32`** and then
`nframes` frames of `bpf` bytes (`[file]`, arithmetic verified exactly):

```
header_size + 28 + nframes*bpf == filesize
```

| field | Jorge value | meaning |
|---|---|---|
| 0 | `0x0000ABE0` = 44000 | BitRate (mirrors TLV 6) |
| 1 | `0x0000000A` = 10 | Rank (mirrors TLV 7) |
| 2 | `0x00000280` = 640 | samples per frame (20 ms @ 32 kHz) |
| 3 | `0x00007D00` = 32000 | Freq (mirrors TLV 4) |
| 4 | `0x0000006E` = 110 | bytes per frame (bpf) |
| 5 | `0x00040AF4` = 264948 | frame count |
| 6 | `0x1FE90B6D` | cookie / checksum-ish |

Observed first 24 bytes of the data region (raw):
`00 00 ab e0 ⋅ 00 00 00 0a ⋅ 00 00 02 80 ⋅ 00 00 7d 00 ⋅ 00 00 00 6e ⋅ [f0]` — `[file]`, identical for
all three 32 kHz codec210 files at bytes `0..20` even though their header keys differ (`0x02`/`0x7C`/
`0xE2`), which independently proves the region is not keyed by the header key.

| file | header_size | fs − hs | frames `bpf` | check |
|---|---|---|---|---|
| Jorge | 122 | 29 144 308 | 264948 × 110 = 29 144 280 | 122+28+29 144 280 = **29 144 430** ✔ |
| GildedPhrases | 148 | 977 818 | 8889 × 110 = 977 790 | 148+28+977 790 = **977 966** ✔ |
| GildedParalinguistics | 164 | 1 095 408 | 9958 × 110 = 1 095 380 | 164+28+1 095 380 = **1 095 572** ✔ |

So a frame *i* (0-based) lives at `file[header_size+28+i*110 : header_size+28+(i+1)*110]`, plain bytes,
110 B/frame = 640 samples = 20 ms @ 32 kHz @ 44 000 bit/s.

**Older/other variant (`linear`, `Version=7.3.0`)** — `payload/Ludoviko.16000.linear.256000.10.bin12`
(5 069 459 B; the `.bin12` suffix is a payload-extraction artefact of the name). The *container* parses
exactly like Jorge (key `0x39`, `"LOQUENDOTTS7"`, `fmt=1`, `header_size=125`, full TLV list above, region
**not** obfuscated), but the payload format after `header_size` differs completely:

* there is **no** 28-byte BE-u32 sub-header — the values `16000`, `256000`, `44000`/`640`/`110` do not
  appear in any endianness at/near offset 125, and the 7 hypothetical BE u32s are meaningless
  (`16842751, 4261349376, 1536, …`);
* the region is plain **signed 16-bit little-endian PCM**: `[file]` 5 069 334 bytes = 2 534 667 samples,
  `min −18469`, `max 31805`, `mean −25.5`, `stdev 2612`, with an amplitude ramp from `±12` at the start
  (`01 00 ff ff fd ff 08 00 …` = `1, −1, −3, 8, 0, 6, 9, −1, …`) to `±18000` in the middle;
  2 534 667 samples @ 16 kHz = 158.4 s, and 5 069 334 B / 158.4 s = 32 000 B/s = 256 000 bit/s, which
  matches TLV `Freq=16000` + `BitRate=256000` exactly.

So: same container, different codec payload. The container spec ends at `header_size`; for
`LTTS7Codec210` voices a 28-byte sub-header follows (verified only for `BitRate`/`Freq`/`bytes_per_frame`
series and the exact `header_size+28+nframes*bpf == filesize` identity), for `linear` voices the samples
start immediately. `tools/bin_dump.py` prints the first 256 data-region bytes for either case and flags
the "no codec sub-header" variant.
`[INFERENCE]` the `linear` payload has no self-describing header; a reader must take `Freq`/`BitRate`
from the TLV list.

---

## 5. `ELQBin*` API — access types and semantics (Jorge addresses)

Access type is a single char at handle `+0x09`: `'d'` = DiskCache, `'m'` = memory-mapped file (MMF),
`'r'` = read whole file into RAM, `'s'` = shell/virtual (no backing store).

### 5.1 Return-value summary

| API | returns | obfuscated? | offsets |
|---|---|---|---|
| `ELQBinGetBuffer(bin, offset, count, unit, outSize, outFlag)` `0x10003f90` | pointer to a buffer holding the bytes: the caller's smart buffer if one was supplied, else the access substruct's own destination buffer (`sub[3]` for `'r'`/`'d'`, `sub[4]` for `'m'`); `NULL` on error/zero size | **raw / de-obfuscated = no** | byte offset = `offset * unit` |
| `ELQBinGetSmartBuffer(bin, offset, count, unit, outSize, smartBuf, outFlag)` `0x10003f20` | same bytes, copied into the caller's smart buffer (realloc'd as needed) | raw | byte offset = `offset * unit` |
| `ELQBinGetSmartBufferCore(smartBuf)` `0x10003f10` | `*(uint*)smartBuf` = the current data pointer inside the smart buffer | raw | — |
| `ELQBinGetRawData(bin)` `0x10003110` | `bin[1]` = the whole-file image (MMF base pointer, or the RAM copy); **`0` for `'d'`** | raw | — |
| `ELQBinSeek(bin, delta, unit)` `0x10003fc0` | `0` on success, `8` on error (`unit == 0` or unknown type); **returns no buffer** | n/a | moves state by `delta * unit` bytes |
| `ELQBinInitSmartBuffer()` `0x10003b50` | a fresh 8-byte smart-buffer handle `{ptr=NULL, capacity=0}` (returns it in `EAX`) | — | — |
| `ELQBinGetSize(bin, div)` `0x10003b00` | `sub[0] / div` | raw byte size | — |
| `ELQBinResizeSmartBuffer(h, n)` `0x10003f50` | data pointer, grown to `n` bytes (no-op if capacity already ≥ n) | — | — |
| `ELQBinDeleteSmartBuffer(h)` `0x10003b70` | frees `h[0]` then `h` | — | — |

Offset units — the core multiplies both size and offset by the unit size held in `EAX`
`[decomp FUN_10003ba0 @ 0x10003ba0]`:
```c
  if (in_EAX == 0) { ELQLogWrite(8,...,"ELQBinGetBuffer: cast value error.\n"); return 0; }
  if (param_2 == 0) { return 0; }
  _Size = param_2 * in_EAX;      /* param_2 = count (EDX) */
  uVar4 = param_3 * in_EAX;      /* param_3 = offset (1st stack arg) */
```
`[asm 0x10003bf0: imul edi,eax]` (count·unit) `[asm 0x10003bf3: imul ebx,eax]` (offset·unit) — so with
`unit = 1` (every call site in Util passes 1, e.g. `mov eax,0x1` at `0x1000231b`, `0x100021d7`) all
offsets/sizes are **byte units**. The wrapper proves `EAX` carries the 4th argument
`[asm 0x10003f9e: mov eax,DWORD PTR [esp+0x18]` inside `ELQBinGetBuffer`, i.e. arg #4 = unit size).

All access types return a copy/target buffer; for `'d'` when `smartBuf == NULL` the target is the
disk-cache's own destination buffer, which is *also* the buffer the container hands back to callers
(`*local_8 = *(uint*)(sub+0xc)` `[asm 0x10003e2b: lea eax,[ecx+0xc]`).

### 5.2 Block granularity

* minimum destination buffer for every access type: **`0x2800` = 10240 bytes**
  `[decomp FUN_10003ba0]` `if (_Size < 0x2801) { local_8 = (uint *)0x2800; }` / `if (_Size < 0x2801) {
  uVar7 = 0x2800; }` and `[asm 0x10003e3c..0x10003e44: cmp edi,0x2800 / ja / mov esi,0x2800]`.
  The capacity field `sub[1]` is realloc'd up to `max(_Size, 0x2800)`; reads never grow in smaller steps.
* DiskCache read-ahead block: **`0x5000` = 20480 bytes**
  `[decomp FUN_10002e20 @ 0x10002e20]`
  ```c
  pvVar3 = _malloc(0x5000);  unaff_ESI[1] = pvVar3;          /* staging buffer */
  if (0x4fff < _Size) { _Size = 0x5000; }
  _memset((void *)unaff_ESI[1],0,_Size);
  unaff_ESI[4] = 0x5000;                                     /* staging block size */
  sVar4 = _fread((void *)unaff_ESI[1],1,_Size,unaff_EDI);
  ```
  The block reader serves a range from the staging buffer when it lies inside
  `[cached_off, cached_off+blocksize)` and otherwise `fseek`s to the absolute byte offset and reads a whole
  `blocksize` block `[decomp FUN_10003020 @ 0x10003020]`:
  ```c
  _File = *(FILE **)(unaff_ESI + 0x10);
  _Offset = param_1 + iVar1;                       /* iVar1 = *(int*)(ESI+8) = base offset */
  if ((*(uint *)(unaff_ESI + 0x18) <= _Offset) &&
     (_Offset + unaff_EDI <= *(int *)(unaff_ESI + 0x20) + *(uint *)(unaff_ESI + 0x18))) { ...cache hit... }
  _fseek(_File,_Offset,0);
  lVar2 = _ftell(_File);
  *(long *)(unaff_ESI + 0x18) = lVar2;
  ```
  `0x5000` is the *read granularity* only; the caller still gets exactly `_Size` bytes (a short read at
  EOF is zero-filled and the out-flag is set, see below).

Boundary behaviour: a read that runs past the end is clamped to the remaining bytes and/or zero-filled,
with `*outFlag = 1` and `"ELQBinGetBuffer: Out of boundaries.\n"` logged
`[decomp FUN_10003ba0]` `if (param_6 != (undefined1 *)0x0) { *param_6 = 1; } ... _memset(...0,_Size);`.
`0x2801`-style checks and the `0x2800` floor make every access type behave identically for boundary reads.

### 5.3 What each access type returns from its substruct

```c
/* 'm' (MMF) — [decomp FUN_10003ba0] */
puVar6 = *(uint **)(param_1 + 0xc);
if (param_5 == (uint *)0x0) { puVar5 = puVar6 + 4; param_5 = puVar6; }   /* dst = sub[4], cap = sub[1] */
...
_memcpy((void *)*puVar5,(void *)(puVar6[2] + uVar4),_Size);              /* from mapped base sub[2] */
/* 'r' (whole file in RAM) */
if (param_5 == (uint *)0x0) { puVar5 = puVar6 + 3; param_5 = puVar6; }   /* dst = sub[3] */
_memcpy((void *)*puVar5,(void *)(puVar6[2] + uVar4),_Size);              /* from RAM image  sub[2] */
/* 'd' (DiskCache) */
local_8 = puVar6 + 3;  param_5 = puVar6;  param_5 = param_5 + 1;         /* dst = sub[3], cap = sub[1] */
```

### 5.4 `ELQBinSeek` semantics

`[decomp FUN_10003fc0]` + `[asm 0x1000401b..0x1000402a]`:
```
1000401b: mov ecx,DWORD PTR [esp+0x8]   ; delta          (param_2)
1000401f: mov eax,DWORD PTR [eax+0xc]   ; sub = bin->sub
10004022: imul ecx,edx                  ; n = delta * unit (EDX = param_3)
10004025: add DWORD PTR [eax+0x8],ecx   ; sub[2] += n
10004028: sub DWORD PTR [eax],ecx       ; sub[0] -= n
1000402a: xor eax,eax ; ret             ; return 0
```
i.e. it re-bases the view window: `base += delta*unit`, `size -= delta*unit`. It does **not** move a
file cursor by itself. `[INFERENCE]` because the same two fields are the read base for `'m'`/`'r'`
(`sub[2]` = mapped/RAM base pointer) and the file-offset base for `'d'`, seeking is meaningful for `'d'`
and would corrupt the base pointer for `'m'`/`'r'` — consistent with the leftover log strings
`"ELQBinAssign: bin access type <%c> unknown."` / `"ELQBinAssign: cast value error."` (the code was
clearly factored out of an `ELQBinAssign` that no longer exists in this build).

### 5.5 `ELQBinGetSize(bin, 1)`

Returns the **total size of the bin in bytes** (file size), i.e. the value of the substruct's first dword
divided by the divisor argument. `[decomp ELQBinGetSize @ 0x10003b00]`
```c
  if (((param_2 != 0) && (((cVar1 = *(char *)((int)param_1 + 9), cVar1 == 'd' || (cVar1 == 'm')) || (cVar1 == 'r'))))
     && ((uint *)param_1[3] != (uint *)0x0)) {
    return *(uint *)param_1[3] / param_2;
  }
```
`[asm 0x10003b2b..0x10003b36: mov eax,[eax+0xc] / mov eax,[eax] / div esi]`.

The field is filled with the file length measured at open time for all three access types:
* `'d'`: `[decomp FUN_10003510 @ 0x10003510]` `psVar3[2] = sVar5; *psVar3 = local_10;` where `local_10`
  is the size produced by `FUN_10002dd0` (`_fseek(f,0,2); lVar1 = _ftell(f); … *unaff_EDI = size;`).
* `'r'`: `psVar3[0] = local_10` then `_fread(_Dst[1],1,local_10,_File)` reads exactly that many bytes.
* `'m'`: `*psVar3 = local_10` after `ELQMemoryMappedFileOpen(...)`.

Therefore `ELQBinGetSize(bin,1)` = byte length of the whole file (29144430 for the Jorge DB, confirmed by
`ls -l` `[file]`), and the header probe uses it to bound `header_size`
(`if ((undefined1 *)(int)sVar4 <= local_8)`). The second argument is a plain divisor: the function is
`sub[0] / div` (integer), so `ELQBinGetSize(bin,110)` = 29144430/110 = **264949** — deliberately *not* the
frame count (264948), because the divisor applies to the file size including the 150-byte
header+sub-header prefix. After an `ELQBinSeek` the returned value is the *remaining* size (`sub[0]` was
decremented) `[INFERENCE]`.

---

## 6. `ELQBin` handle layout

`ELQBinOpen` / `ELQBinOpenNoCache` are thin thunks that call the internal open with a cache flag
`[asm 0x10003960: push 0x1 / call 0x10003510]`, `[asm 0x10003990: push 0x0 / call 0x10003510]`.
The internal open allocates and zeroes **`0x214`** bytes in the Jorge build
`[asm 0x10003596: push 0x214 / push 0x0 / push ebx / call 0x1004b1b0]` (= `memset(handle,0,0x214)`), and
`ELQBinShell` (`0x10003190`) and `ELQBinVirtualOpen` (`0x10003450`) allocate the same `0x214`
`[decomp ELQBinShell @ 0x10003190] _Dst = _malloc(0x214); _memset(_Dst,0,0x214);`.

> The ticket's "0x218 bytes" is the **older** build (`engine_re/LTTS7Util.dll`): there the handle is `0x218`
> and a log-handle dword sits at `+0x10` (`[old build decomp FUN_10003ca0 @ 0x10003ca0] _Dst[4] = param_3;`),
> pushing the filename to `+0x14` and the extra dword to `+0x214`. In the Jorge build the log handle is
> **not** stored in the handle (every `ELQLogWrite` in the open path passes `0x0` or the caller's handle),
> so the fields shift down by 4 → `0x214`. Both layouts are listed below.

### Jorge build — `ELQBin` handle, `0x214` bytes

| off | type | content | evidence |
|---|---|---|---|
| `+0x00` | `void*` | type tag = address of `ELQBinOpen` (`0x10003960`), `0` = unusable | `[asm 0x10003118 cmp DWORD PTR [eax],0x10003960]`; `[asm 0x100035b6 mov DWORD PTR [ebx],0x0]` then `*_Dst = ELQBinOpen` |
| `+0x04` | `void*` | whole-file data pointer: MMF base (`'m'`), RAM image (`'r'`), `0` for `'d'` | `[decomp ELQBinGetRawData] return param_1[1];`; `[asm 0x10003126 mov eax,DWORD PTR [eax+0x4]]`; `[decomp FUN_10003510] _Dst[1] = pvVar4;` / `_Dst[1] = uVar6;` / `_Dst[1] = 0;` |
| `+0x08` | `u8` | "data is borrowed" flag (`1` for shell/clone, `0` for a real open); gates freeing/closing the backing store in `ELQBinClose` (`'r'`: `handle+4`; `'m'`: the MMF) | `[asm 0x100035b2 mov BYTE PTR [ebx+0x8],0x0]`; `[decomp ELQBinShell] *(undefined1 *)(_Dst + 2) = 1;` (`_Dst+2` = byte `+0x08`); `[decomp ELQBinCloneEx] *(undefined1 *)(param_1 + 2) = 1;` |
| `+0x09` | `char` | access type: `'d'`, `'m'`, `'r'`, (`'s'` shell) | `[asm 0x100035a6 mov BYTE PTR [ebx+0x9],al]`; `[asm 0x10003b19 mov cl,BYTE PTR [eax+0x9]]` |
| `+0x0C` | `void*` | access substruct (see §7), `NULL` if none | `[asm 0x10003b2b mov eax,DWORD PTR [eax+0xc]]`; `[asm 0x10003e0c mov ecx,DWORD PTR [ecx+0xc]]` |
| `+0x10` | `char[0x200]` | NUL-terminated full file name | `[asm 0x100035f4 lea edx,[ebx+0x10]` … copy loop `]; `[decomp ELQBinGetFilename] return param_1 + 4;` |
| `+0x210` | `u32` | 5th open argument, kept verbatim | `[asm 0x1000360d mov DWORD PTR [ebx+0x210],eax]` from `[ebp+0x18]` |
| `+0x214` | — | end of allocation (`0x10 + 0x200 + 4 = 0x214`) | `[asm 0x10003596 push 0x214]` |

Open sequence (`[asm 0x10003596..0x10003616]`): `memset(handle,0,0x214)` →
`handle[9] = access char` → `handle[8] = 0` → `handle[0] = 0` → `fopen`+size (`FUN_10002dd0`) →
`handle[0x10..] = filename` → `handle[0x210] = arg5` → per-type substruct setup → `handle[0] = ELQBinOpen`.
On any failure the handle is freed, `*out = 0` and an error code is returned (`3` NULL bin pointer,
`8` NULL filename / unknown access type, `5` out of memory / read error, `2` file open error, `0` OK).

### Compatibility — older build `0x218`

Same fields shifted by `+4` from `+0x10`: `+0x04` data, `+0x08` flag, `+0x09` type, `+0x0C` substruct,
`+0x10` log handle, `+0x14` `char[0x200]` filename, `+0x214` 5th arg. `[old build decomp FUN_10003ca0]`
`_Dst[4] = param_3;` / filename copy at `+0x14` / `_Dst[0x85] = param_5;` (`0x85*4 = 0x214`, +4 = `0x218`).
A reimplementation must therefore not assume either size; it should only rely on the field meanings.

---

## 7. Access substructs

All are allocated per handle and reachable at `handle+0x0C`.

### `'d'` — DiskCache, `0x24` bytes

```
+0x00 u32  total size in bytes                     (ELQBinGetSize / ELQBinSeek)
+0x04 u32  capacity of the destination buffer, always >= max(requested, 0x2800)
+0x08 u32  base file offset (advanced by ELQBinSeek)
+0x0C void* destination cache buffer (the pointer returned by ELQBinGetBuffer without a smart buffer)
+0x10 FILE* file handle
+0x14 void* staging buffer (malloc 0x5000, or a caller-supplied buffer)
+0x18 u32  cached file offset (last ftell), 0 at open
+0x1C u8   "staging buffer is external" flag
+0x20 u32  staging block size = 0x5000
```
Evidence: `[asm 0x10003e24 lea eax,[ecx+4] / 0x10003e2b lea eax,[ecx+0xc]]` (cap = `sub[1]`,
dst = `sub[3]`), `[asm 0x1000401f..0x10004028]` (size/base), `[decomp FUN_10003020]` (`+0x8` base,
`+0xc` dst, `+0x10` FILE\*, `+0x14` staging, `+0x18` cached offset, `+0x20` block size),
`[decomp FUN_10002e20]` (called with `ESI = sub+0x10`: `ESI[0]=FILE`, `ESI[1]=staging`,
`*(u8*)(ESI+0xc)=own-flag`, `ESI[2]=0`, `ESI[4]=0x5000`), `[decomp ELQBinClose case 0x64]` (frees
`sub[3]`, then `FUN_10002f00` which frees `ESI[1]` and `fclose(ESI[0])`).

### `'m'` — MMF, `0x14` bytes

```
+0x00 u32  total size in bytes
+0x04 u32  capacity of the destination buffer
+0x08 void* mapped base pointer        (== handle+0x04, ELQBinGetRawData)
+0x0C void* MMF handle                 (out-param of ELQMemoryMappedFileOpen, ELQMemoryMappedFileClose'd)
+0x10 void* destination buffer         (realloc'd on demand, freed with ELQfree)
```
Evidence: `[decomp FUN_10003510 'm'] *psVar3 = local_10; psVar3[4] = 0; psVar3[2] = uVar6 & (cVar1 == 'd') - 1;`
plus `uVar6 = ELQMemoryMappedFileOpen(param_4,'\0',1,psVar3 + 3,param_3); _Dst[1] = uVar6;`,
`[decomp FUN_10003ba0 'm'] puVar5 = puVar6 + 4;` (destination = `sub[4]`),
`[decomp ELQBinClose case 0x6d]` (frees `sub[4]`, `ELQMemoryMappedFileClose(sub[3])`).

### `'r'` — whole file in RAM, `0x10` bytes

```
+0x00 u32  total size in bytes
+0x04 u32  capacity of the destination buffer
+0x08 void* base pointer, == handle+0x04 (malloc'd file image)
+0x0C void* destination buffer
```
Evidence: `[decomp FUN_10003510 'r'] pvVar4 = _malloc(local_10); _Dst[1] = pvVar4; ... *psVar3 = local_10;
psVar3[2] = _Dst[1];`, `[decomp FUN_10003ba0 'r'] puVar5 = puVar6 + 3;`,
`[decomp ELQBinClose case 0x72]` (frees `handle+4` when the borrowed-flag is clear, then `sub[3]`).

`ELQBinCloneEx` copies filename/type/5th-arg and, per type, all fields except the buffers
(`[decomp ELQBinCloneEx @ 0x10003220]` `param_1[1] = param_2[1]; uVar4 = *puVar2; puVar7[3] = 0; *puVar7 = uVar4;
uVar4 = puVar2[2]; puVar7[1] = 0; puVar7[2] = uVar4;`) — a clone shares the `handle+0x04` data pointer but
must have the borrowed flag set (`*(undefined1 *)(param_1 + 2) = 1;`) so neither copy frees it twice.

---

## 8. Reader/consumer chain (context)

```
ELQBinOpen(&h, 'd'|'m'|'r', log, "voice.bin", 0)
  └─ FUN_10003510 (0x10003510)  ▸ malloc(0x214), fopen+size, substruct, handle[0]=ELQBinOpen
ELQBinaryHeaderIsPresent(bin, &hdr)      → FUN_10002160 (0x10002160)   [0x12 read, key, "LOQUENDOTTS7"]
FUN_10005100 / ELQBinaryHeaderLoadInfo   → FUN_10002550 / 0x100026d0  [version==1, then ReadHeader]
FUN_100022c0 (0x100022c0)                ▸ XOR whole header, parse TLVs into an ELQDataDescriptor
ELQBinGetBuffer/GetSmartBuffer           ▸ raw payload bytes (frames for codec210)
```

Known constants: signature `"LOQUENDOTTS7"` (`0x10058674`), tag names `"Label"…"Version"`
(`0x10058634`/`0x1005864c`/`0x10058664` are the `Name`/`Freq`/`Rank` strings), error strings
`"ELQBinOpen: NULL bin pointer error.\n"`, `"ELQBinOpen: Filename NULL.\n"`, `"ELQBinOpen: bin access type
<%c> unknown.\n"`, `"ELQBinOpen: Init DiskCache error.\n"`, `"ELQBinOpen: Error opening in MMF %s.\n"`,
`"ELQBinGetBuffer: cast value error.\n"`, `"ELQBinGetBuffer: Out of boundaries.\n"`,
`"ELQBinGetBuffer: Read error.\n"`, `"ELQBinGetBuffer: Out of memory.\n"`,
`"ReadHeader: Error creating HID."`,
`"ReadHeader: Warning. Header format not supported."`, `"ELQBinSeek: cast value error.\n"`,
`"ELQBinSeek: bin access type <%c> unknown.\n"`.

## 9. Reimplementation checklist

1. Read `b0 = f[0]`, `b1 = f[1]`; `k = b0 ^ b1`; decode `f[2:header_size]` with `k`.
2. Require `f[2:14] == b"LOQUENDOTTS7"`, `u16le(f,14) == 1`, `u16le(f,16) == header_size`,
   `0x12 <= header_size <= len(f)`.
3. Parse TLVs from `0x12` to `header_size`; unknown tag ⇒ reject the file.
4. Data region starts at `header_size`; **no** de-obfuscation. For `LTTS7Codec210` voices read the 7 BE
   `u32`s and then `nframes` × `bpf` frames (verify `header_size+28+nframes*bpf == len(f)`).
5. Never assume the handle size; the Jorge build uses `0x214`, the older one `0x218`.

Reference implementation of the read side: `tools/bin_dump.py` (standalone, stdlib only) —
`python3 tools/bin_dump.py` dumps the Jorge database by default, `--offset N --length M` dumps an
arbitrary file range, `--key N` overrides the derived key.


---

# APPENDIX: specs/SDE.md

# `.sde` — Loquendo TTS 7 unit inventory ("speech atom" table)

Scope: the unit-inventory files shipped with the Jorge voice package
(`jorge/pf/Loquendo/LTTS7/data/voices/Jorge/`):

| file | bytes | header | records |
|---|---|---|---|
| `Jorge.sde` | 1 511 129 | `10,4` / `LTTSComponentVersion=7.0.0` / `N=3647,82007` | 3647 `U=`, 149 426 `L`/`R`, 146 `S=` |
| `JorgeGildedPhrases.sde` | 53 534 | `10,4` / `LTTSComponentVersion=7.0.0` / `N=261,2960` | 261 `U=`, 4 876 `L`/`R`, 260 `S=` |
| `JorgeGildedParalinguistics.sde` | 3 809 | **none** | 147 `P=` only |
| `payload/Ludoviko.sde13` (legacy gen., §12) | 186 290 | `14,1` / `VERSION=7` / `N=3482,6953,6578` | 3482 `U=`, 6577 `D=` |

Everything below is derived from the decompiled readers (addresses in §9). Two builds were
used: the older `engine_re/LoqTTS7.dll` dumps (`decomp_loqtts.txt`,
`decomp_util.txt`) and the newer jorge build `jorge/pf/…/bin/LoqTTS7.dll`
(`jorge_re/decomp_loqtts_jorge.txt`), plus `jorge_re/decomp_util_jorge.txt` for
`LTTS7Util.dll`. Both builds contain the same parser; address pairs are tabulated in §9.

---

## 1. Layer 0 — bit-7 obfuscation (auto-detected per file)

`Jorge.sde` and `JorgeGildedPhrases.sde` are stored with **bit 7 set on every single byte
except the line feed**. Byte histogram of `Jorge.sde`:

```
bit7 set : 1 357 907 bytes        bit7 clear: 153 222 bytes
number of 0x0A (LF) bytes: 153 222     →  the two sets are disjoint
```

so `b & 0x7F` = the real character and the only unmasked byte is `0x0A`.
`JorgeGildedParalinguistics.sde` is stored **plain** (bit 7 clear everywhere).

The reader auto-detects the masked form from the *first character of the first line*
(jorge `FUN_10049f10`, `0x10049f10`; old `FUN_1002a890`, `0x1002a890`):

```c
/* first line is read with fgets(buffer+1, 0x32, fp) -- so the line starts at index 1 */
(*DAT_100b73f0)(acStack_d11 + 1, 0x32, iStack_1d68);
uStack_1d48 = CONCAT31(uStack_1d48._1_3_, 0x7f < (byte)acStack_d11[1]);
...
if ((char)uStack_1d48 == '\0') {          /* unmasked  -> plain, set built-in defaults */
    (*DAT_100b7418)(iStack_1d68);         /* ELQrewind */
    ...
} else {                                  /* masked    -> copy with -0x80 */
    do {
      cVar6 = acStack_d11[uVar14 + 1];
      if (cVar6 == '\0' || cVar6 == '\r' || cVar6 == '\n') break;
      *(char *)((int)puVar7 + uVar14 + 0x30) = cVar6 + -0x80;   /* clear bit 7 */
      uVar14++;
    } while (uVar14 < 0x4f);              /* first line, max 79 chars */
}
```

Who applies it: the **generator** writes the whole file masked; the **reader** detects it
once (from line 0, char 0) and clears bit 7 while copying. The same convention is used by the `LTTSComponentVersion=` reader in
`LTTS7Util.dll` (`FUN_1000d030` `0x1000d030` in the jorge build, `FUN_1000a390`
`0x1000a390` in the old one; public wrapper `ELQGetComponentVersion` `0x1000d180` jorge /
`0x1000a4f0` old), which
builds the key with `cVar1 + -0x80` and accepts *either* `"LTTSComponentVersion="` or its
bit-7-set copy, normalising the copied value with `cVar1 + -0x80`.

Uniform over the file: **yes** — every byte except LF. It does **not** cover "binary
fields" because the format has none: after unmasking the payload is pure printable
ASCII (bytes `0x20`–`0x7E`); even the numeric fields are digits of a printable numeral
system (§4). `JorgeGildedParalinguistics.sde` proves the detection is a real branch: it
starts with `P` (0x50), is stored plain, and is parsed unharmed.

Line 0 is additionally *opaque*: it is read once with `fgets(…,0x32,…)` and stored
verbatim at reader-state `+0x30` (max 79 chars). For the unmasked branch the engine
substitutes a compiled-in default string — in `engine_re/LoqTTS7.dll` at `0x10088858`
the bytes are `"332198,21119"`, i.e. the engine writes a `<int>,<int>` pair there and
the shipped files write `10,4`. **The two numbers of line 0 are not interpreted by any
code path we found** (not used as a count, version or offset); treat as opaque.

---

## 2. Line / record grammar

All lines are LF-terminated; the first character of a line is the record tag.
The reader dispatches on it (jorge `FUN_10049f10`, switch on `acStack_d11[1]`,
which is the file's first character because the buffer starts at +1):

```
<file>  := <line0> LF [ "LTTSComponentVersion=" <ver> LF ] [ "N=" <a> "," <b> LF ]
           { record LF }*
record  := 'U' '=' <atom-tokens>          -- speech atom: phoneme sequence
         | 'L' <n> ["!"<start>] " " <dur> " " <val>     -- left  ('S', Sinistra) half
         | 'R' <n> ["!"<start>] " " <dur> " " <val>     -- right ('D', Destra)   half
         | 'S' '=' <flag-char>             -- per-atom boundary-class flag
         | 'P' '=' <name> "|" <begin> "|" <end> [ "|" ... ]   -- numeric range record
         | 'A' '=' <name>                  -- extra name for the current atom  (unused here)
         | 'F' '=' <name>                  -- extra name (2nd array)           (unused here)
         | 'D' <n> "," <S|D> "," <start> "," <end> "," <pitch>  -- explicit part (unused here)
```

* `U=`, `A=`, `F=` all delimit atoms: the atom index is bumped by the *next* such record
  (jorge `FUN_10049f10`, `case 'A'/'U'`: `if (local_1d71) { uStack_1d58++; local_1d71 = 0; }`).
* An atom's `L`/`R`/`S` records follow its `U=` record. In all shipped files every atom
  has exactly one `U=`, one `S=` (except in `Jorge.sde`, where only 146 do), and
  `L1 R1 L2 R2 … LK RK` for the atom's K phonemes.
* `JorgeGildedParalinguistics.sde` has no header lines at all and only `P=` records; the
  reader tolerates this (the `N=`/`U=`/`P=` branch is inside the record loop).

`N=<a>,<b>` (jorge `FUN_100493b0` @ `0x100493b0`, old `FUN_10028b80` @ `0x10028b80`;
`_atol` before and after the comma, stored at state `+0x10` and `+0x18` = `puVar5[4]`
and `puVar5[6]`):

* **`a` = number of `U=` atoms** → 3647 (verified: exactly 3647 `U=` lines).
* **`b` = total number of atom tokens** (= size of the engine's 2-byte-per-token frame
  code array, `puVar5[5]`) → 82007 (verified by re-implementing the tokenizer: the token
  count equals 82007 exactly). 82007 − 69339 space-separated fields = 12668 diphone
  joins written with `-`.

`N2` is *not* the codec frame count: the `.bin` has 264 948 frames while `N2` is 82 007.

---

## 3. `U=` records — speech-atom phoneme sequence

Parser: jorge `FUN_10049c10` @ `0x10049c10`, old `FUN_10029230` @ `0x10029230`.
(Logging in the jorge build calls these "speech atoms": *"Too many speech atoms in file
\"%s\" at line %d"*.)

```c
    bVar2 = unaff_EDI[iVar5];
    do {
        if (((bVar2 == 0x2d) || (bVar2 == 0)) || (4 < iVar4)) break;   /* stop at '-', NUL, 5 chars */
        iVar5 = iVar5 + 1;
        local_c[iVar4] = bVar2;      /* token, max 5 chars */
        bVar2 = unaff_EDI[iVar5];
        iVar4 = iVar4 + 1;
    } while (bVar2 != 0x20);
    if (local_10 != 0)
      *param_2 = ((unaff_EDI[iVar5] != '-') - 1U & 0xf7) + 0xf;   /* 0x06 after '-', else 0x0f */
    uVar3 = FUN_100190c0(table, local_c);      /* phoneme symbol -> id (old FUN_100190c0) */
    *param_4 = (char)uVar3;
```

* Fields are separated by **space**; `-` is a second separator that joins two phonemes
  of one slot (a diphone): the first token gets flag `0x06` ("joined to next"), the
  second `0x0f`. Tokens are at most 5 characters.
* Each token is a **phoneme/allophone symbol** looked up by exact string match in the
  voice's phonetic table (`*(int**)(state+0xc)`, the "TabelleFonetiche" shared resource
  registered by old `FUN_10024470`); the lookup returns the phoneme id (byte). `Jorge.sde`
  uses **44 distinct phoneme symbols**:
  ``# $ @ BH DH GH GL GN Gl Gn J M N T$ Th Ts Y Zg `a `e `i `o `u a b dd e f g hr i j k
  l m n o p r: s tt u w x``
  (the single-character tokens `#`, `@`, `$` are special/non-phonemic symbols); the 832 distinct
  space-separated fields come from ~788 diphone spellings such as `s-DH`, `o-DH`, `e-l`, `a-k`.
* **Arity: `U=<left-context> <p1> … <pK> <right-context>`.** The atom holds `K = tokens−2`
  phonemes; token 0 and the last token are the left/right **context** phonemes. The atom
  occupies K+2 frame slots `[S, S+K+2)` of the global token/frame-code array, where `S`
  is the running token counter (`puVar5[3][atom].start = local_1d2c`). *Proof:* for
  all 3647 + 261 atoms in both files, `#L == #R == #(tokens) − 2` (0 mismatches), and the
  `n` of the `L`/`R` records runs exactly `1,1,2,2,…,K,K`.
* The context pairs in `Jorge.sde` are `('#','@')` ×1891 and `('#','#')` ×1756; in
  `JorgeGildedPhrases.sde` `('#','@')` ×261 (all of them) — `#`/`@` are the
  silence/pause-type context symbols.

Frame codes: the token ids are written into the 2-byte-per-slot array as
`[phoneme-id, flag]` (flag `0x0f` normal, `0x06` diphone-join). Then
old `FUN_10029930` / jorge twin rewrites the *edge* slots of each atom with boundary
codes (`0x02,0x04,0x05,0x08…0x0d`) while preserving the `0x06` join flags; the `S=` flag
is the second argument of that call (`if (param_1 == 'I')` chooses the alternative code).

---

## 4. Layer 1 — printable base-93 numerals (`L`/`R` fields)

Decoder: jorge `FUN_100436f0` @ `0x100436f0`, old `FUN_10024440` @ `0x10024440`:

```c
int FUN_10024440(int len, byte *p) {
  i = 0; b = *p;
  while (0x21 < b) { p++; i = i * 0x5d + (uint)(byte)(b - 0x22); b = *p; }
  return i;
}
```

* Big-endian, **base 0x5D = 93**, digit = `byte − 0x22` ⇒ alphabet `"`(0) `#`(1) `$`(2)
  … `~`(92). Field ends at space (`0x20`), `!` (`0x21`) or NUL.
* `-` (0x2D) is **a digit (11)** here (only `U=`'s tokenizer treats it as a separator).
* So e.g. `#`=1, `$`=2, `0`=14, `a`=63, `'E`=5·93+35=500, `#-%`=(1·93+11)·93+3=9675.

This is why the file "looks like base-94ish digits": all `.sde` numerals are such
byte strings; there is no bit-packing inside a field.

---

## 5. `L<n>` / `R<n>` records — atom timeline

Parser: jorge `FUN_10048e30` @ `0x10048e30`, old `FUN_100285b0` @ `0x100285b0`.
Grammar (all four fields are base-93 numerals, §4):

```
L<n> [ "!"<start> ] SP <dur> SP <val>
R<n> [ "!"<start> ] SP <dur> SP <val>
```

Decompiled control flow (old build, `unaff_EDI` = the line content, i.e. from the `n` char):

```c
  /* field 1 -> param_1  ("phoneme order") */
  iVar3 = FUN_10024440(uVar5, unaff_EDI);  *param_1 = (short)iVar3;
  /* optional '!' introduces an explicit start value */
  if (unaff_EDI[uVar8] == 0x21) { uVar7 = FUN_10024440(len2, unaff_EDI+uVar5); }
  else                          { uVar7 = *in_EAX; }        /* else: previous end */
  *param_2 = uVar7;                                          /* start */
  /* duration field */
  iVar3 = FUN_10024440(param_1, pbVar4);  uVar5 = iVar3 + *param_2;
  *in_EAX = uVar5;                          /* running end -> next line's start */
  if (*param_2 <= uVar5) {                                  /* "Negative duration" otherwise */
     uVar8 = FUN_10024440(len4, ...);                       /* low 10-bit value */
     param_2[1] = uVar8 & 0xffff | (uVar5 - uVar7) * 0x400; /* packed (dur<<10)|val */
  }
```

Field meaning (verified numerically on the shipped files):

| field | meaning |
|---|---|
| `n` | 1-based index of the phoneme inside the atom; `1..K`, `K = tokens−2`. |
| `!<start>` | explicit absolute start of this half-segment. It is written **only on the first `L` record of each atom** (verified: exactly one `!` per atom in both files). |
| `<dur>` | duration of the half-segment. |
| `<val>` | 10-bit acoustic parameter of the half-segment (values 0…284 in `Jorge.sde`, 0…250 in `Phrases`); 0 = unvoiced/first sample. `[INFERENCE]` it fits a pitch-period/voicing code in samples, but the exact acoustic meaning is not proven by the code (the reader stores `(dur<<10)|val` and later recomputes `end = start + (packed>>10)`). |

* Position unit: `start`/`dur` are in **10 µs ticks**. *Proof (consistency, not fitting):*
  the last end position of `Jorge.sde` is **529 894 060** while the DB has 264 948 frames
  of 20 ms ⇒ `264948 × 2000 = 529 896 000` (Δ 0.0019 s). Independently
  `JorgeGildedPhrases.sde`: max end 17 776 419 vs `8889 × 2000 = 17 778 000`, and
  `JorgeGildedParalinguistics.sde`: 19 915 859 vs `9958 × 2000 = 19 916 000`. The sum of
  all durations (526 255 963) is within 0.7 % of the whole timeline ⇒ the records tile
  the acoustic database in time order.
* Side: `L` is stored as part `'S'` (Sinistra/left) and `R` as `'D'` (Destra/right)
  (`local_1d59 = ((local_1d69 != 0x52) - 1U & 0xf1) + 0x53;`); the engine writes the
  left half into frame slot `2·(atom.start + n)` and the right half into `2·(atom.start+n)+1`
  (`iVar10 = (((n) - unit.field4) + runningTokenCount) * 2; if (part=='D') iVar10++;`).
* The `R` records never carry `!`; they inherit the accumulator from the preceding `L`.
* Timeline continuity is checked by the engine (`local_1d1c = start + (packed>>10)`) —
  mismatches produce an `ELQLogWrite` warning but do not reject the file.

---

## 6. `S=` records — per-atom flag

`case 'S': *(char *)(puVar7[3] + 6 + uStack_1d58*8) = acStack_d11[3];`

Sets one character of the atom (state `+6`); the `U=` record pre-sets it to `'D'`.
Observed values: `Jorge.sde` only `I` (146 atoms, atoms #3307…#3646 — the tail of the
file); `JorgeGildedPhrases.sde` `e`×180, `i`×67, `f`×7, `x`×6. The character is later
passed as `param_1` into the frame-code builder (`FUN_10029930`, old build), which takes
a different branch when `param_1 == 'I'`; it is therefore a **boundary-class selector**
for the atom's edge frames (exact enumeration of the classes not needed for parsing).

---

## 7. `P=` records — numeric range records

Parser: old `FUN_10029300` @ `0x10029300` (`'|'`-separated, `_atol`), jorge
`FUN_10049de0`. Format `P=<name>|<begin>|<end>[|...]`, plain **decimal**, no base-93:

```
P=Aa|0|61846
P=Aa_01|61846|150218
...
```

Only `JorgeGildedParalinguistics.sde` uses them (147 records, names = the
paralinguistic extras of `JorgeGilded.gde`: `Aa, Aa_01, Ah, Breath, …`); the reader
requires `end > begin` (`"Negative duration"` otherwise) and stores
`{name, begin, end}` (16-byte entries, `state[10]`), count in `state[0xb]`.
`begin`/`end` are again **10 µs ticks** (max end 19 915 859 ≈ 9958 frames × 2000).

---

## 8. Summary of every field

| position | who | value |
|---|---|---|
| line 0 | — | opaque `<int>,<int>` string, e.g. `10,4` |
| `LTTSComponentVersion=` | — | component version string `7.0.0` (also present masked in `.bin` headers) |
| `N=a,b` | `FUN_100493b0` | `a` = #atoms, `b` = #atom tokens (frame-code slots) |
| `U=` field i | `FUN_10049c10` + phonetic table | phoneme/allophone **symbol** (i=0 left context, i=last right context, middle = atom phonemes) |
| `U=` `-` | same | joins two phonemes into one diphone token (flag 0x06) |
| `L<n>`/`R<n>` field 1 | `FUN_10048e30`/`FUN_100436f0` | `n` = phoneme index 1..K |
| `!<start>` | idem | absolute start, 10 µs ticks, first L of atom only |
| `<dur>` | idem | duration, 10 µs ticks |
| `<val>` | idem | 10-bit parameter (0..~284) |
| `S=` | reader `case 'S'` | 1-char boundary-class flag (default `D`) |
| `P=` | `FUN_10049de0` | name, begin, end (decimal, 10 µs ticks) |

---

## 9. Functions (address table)

| role | old `engine_re/LoqTTS7.dll` | jorge `bin/LoqTTS7.dll` |
|---|---|---|
| `.sde` reader (mask detect, dispatch, atom table) | `FUN_1002a890` `0x1002a890` | `FUN_10049f10` `0x10049f10` |
| `N=` parser (`_atol`,`_atol`) | `FUN_10028b80` `0x10028b80` | `FUN_100493b0` `0x100493b0` |
| `U=` tokenizer | `FUN_10029230` `0x10029230` | `FUN_10049c10` `0x10049c10` |
| base-93 ≤5-char numeral decoder | `FUN_10024440` `0x10024440` | `FUN_100436f0` `0x100436f0` |
| `L`/`R` field parser | `FUN_100285b0` `0x100285b0` | `FUN_10048e30` `0x10048e30` |
| `D` record parser (`_atol`) | `FUN_10028700` `0x10028700` | `FUN_10048f90` `0x10048f90` |
| `P` record parser (`\|`,`_atol`) | `FUN_10029300` `0x10029300` | `FUN_10049de0` `0x10049de0` |
| phonetic symbol table lookup | `FUN_100190c0` `0x100190c0` | (same design; table ptr at state `+0xc`) |
| atom edge frame-code builder | `FUN_10029930` `0x10029930` | vtable slot `state+0x10` |
| phonetic-table shared-resource loader | `FUN_10024470` `0x10024470` | — |

---

## 10. The descriptor / tags layer (`LTTS7Util.dll`) and its relation to `.sde`

`.sde` is **not** parsed by `ELQTagsDescriptor*`: the engine opens the file itself
(`ELQfopen`/`ELQFileValidfgets` in `FUN_10049f10`) and parses the tags in §2. The
`ELQTagsDescriptor*` API is the generic tag-file layer that reads the voice's **descriptor**
files `Jorge.vde` and `JorgeGilded.gde` (`"key" = "value"` lines, `~`-separated lists,
`;` comments), and `ELQDataDescriptor*` is the generic key/value descriptor used for
`.bin` header fields and voice attributes.

`LTTS7Util.dll` jorge build (`jorge_re/decomp_util_jorge.txt`):

| export | addr | behaviour |
|---|---|---|
| `ELQTagsDescriptorIni` | `0x100293b0` | `malloc(0x58)`; installs default delimiter set (from `.rdata` `0x10064378…`), magic = `ELQTagsDescriptorDelete`, `[0x15]` = predefined-tag table, state `[0x14]=0` |
| `ELQTagsDescriptorDelete` | `0x10029450` | frees name buffer `[0x11]` |
| `ELQTagsDescriptorSetTagDelim` | `0x10029490` | sets `[1]`/`[3]`; defaults `'\' (0x5c)` / `'(' (0x28)`; guarded by `[0x14]<2` |
| `ELQTagsDescriptorSetQuoteDelim` | `0x10029640` | sets `[6]`/`[7]`; default `'"'` both |
| `ELQTagsDescriptorMalformedTags` | `0x100297f0` | stores a **bool at `+0x40`** = "accept malformed tags" (API-sequence guarded) |
| `ELQTagsDescriptorSetListOfPreDefinedUserTags` | `0x10029990` | user-tag name list |
| `ELQTagsDescriptorSetIsUserTagNameFunction(s)` | `0x10029ba0` / `0x10029d30` | user-tag predicate callbacks |
| `ELQTagsDescriptorCheck` | `0x10029ec0` | locks the configuration (`[0x14]=1`) |
| `ELQTagsDescriptorGetTagEffect` | `0x1002a040` | linear search (stride `0x44`) in the tag table, returns effect `1`/`2` or `0` |

Default delimiters seen in `.rdata` (code points): escape `'\'`, pair `'('`,`')'`,
`'"'`,`'"'`, `';'`,`';'`, `','`, `'='`,`'='`, `'+'`,`'-'`.

`ELQDataDescriptor*` (`0x10004d60` Ini, `0x10005070` LoadFile, `0x10005200` GetNext,
`0x100052a0` GetCount, `0x10004ec0` GetAttribute, `0x10004f40` SetAttribute,
`0x10004e20`/`0x10004e90` Set/GetName, `0x10004d90` Delete) is an ordered
`name=value` attribute list (used by `ELQBinaryHeaderGetValue`/`LoadInfo` for the
`.bin` TLV header and by the engine to fetch voice paths).

Note the `MalformedTags` flag is about tag *syntax*, not about the bit-7 masking of
`.sde`; the bit-7 handling is exclusively the first-character test in §1 (and the
equivalent `-0x80` normalisation inside `ELQGetComponentVersion`).

---

## 11. Consistency checks that back this spec

1. `#U=` = 3647 = `N`[0]; token count = 82007 = `N`[1] (tokenizer re-implemented exactly).
2. For all 3647 (Jorge) and 261 (Phrases) atoms: `#L = #R = #tokens − 2`; the `n`
   sequence is `1,1,2,2,…,K,K`.
3. `#L` index characters are exactly `'#'…'a'` = base-93 values `1…63` (max 63 phonemes/atom).
4. Exactly one `!`-prefixed (explicit start) `L` record per atom; every `L`/`R` line has
   3 fields (`n dur val`) except those 3647/261 first-`L` lines which have 4 (`n !start dur val`).
5. `max(end)` = 529 894 060 ≈ `264948×2000`; Phrases 17 776 419 ≈ `8889×2000`;
   Paralinguistics 19 915 859 ≈ `9958×2000` ⇒ 10 µs ticks.
6. Byte histogram: every non-LF byte of a masked file has bit 7 set.
7. `JorgeGildedParalinguistics.sde` (plain, `P=`-only, no header) parses with the same
   reader, proving the auto-detection and the optional header.
8. Legacy generation (`payload/Ludoviko.sde13`): `#U=` = 3482 = `N`[0]; `#D=` = 6577 and
   `N`[2] = 6578 = `#D + 1`; every `D` record has a valid `part ∈ {S,D}`, `end ≥ start`,
   `pitch ≥ 0` (the three conditions `FUN_10028700` enforces) — 0 violations.
9. `N`[1] of the legacy file (6953) = raw token count (6962) minus the 9 tokens that
   follow the first occurrence of the one token whose phonetic-table index is 0
   (`` Oe ``/`` `Oe ``; both candidate tokens reproduce exactly 9).
10. Shared time base: Jorge max end 529 894 060 ≈ 264 948 × 2000; legacy max end
    15 829 000 ≈ 158.29 s ≈ the companion PCM's 2 534 653 samples @16 kHz (158.42 s).

## 12. Legacy generation (`VERSION=7`) — e.g. `payload/Ludoviko.sde13`

The SDK voice ships an **older `.sde` generation** whose grammar is distinct but which
is consumed by the *same* engine reader. Example: `payload/Ludoviko.sde13`
(186 290 B, 10 063 lines, bit-7 masked like the Jorge files; decoded copy kept at
`engine_re/Ludoviko.sde.txt`).

```
14,1                        <- line 0, same opaque <int>,<int> convention as Jorge's "10,4"
VERSION=7                   <- generation marker (instead of LTTSComponentVersion=)
N=3482,6953,6578            <- THREE numbers
U=#                         <- atom, no context tokens
D=0,S,15769400,15779075,0   <- part record, PLAIN DECIMAL, comma separated
D=0,D,15779075,15794394,0
U=@
...
```

Record inventory of the file: 3482 `U=`, 6577 `D=`, no `L`/`R`/`S`/`P`.

### 12.1 `D=` records

Parsed by the *old-build* `D` case of the reader (`FUN_10028700` `0x10028700`, jorge
`FUN_10048f90` `0x10048f90`), which I verified line by line:

```c
  uVar3 = _atol(unaff_EDI);                     /* field 1: "phoneme order" */
  if ((int)uVar3 < 0) -> "Error in phoneme order";
  *param_1 = (short)uVar3;
  cVar1 = unaff_EDI[uVar6 + 1];  *param_2 = cVar1;      /* field 2: part letter */
  if (cVar1 != 'S' && cVar1 != 'D') -> "Unknown phoneme part";
  ... field 3 "start" (empty field => *in_EAX accumulator) -> *param_3
  ... field 4 "end"  -> *in_EAX ;  if (end < start) -> "Negative duration"
  ... field 5 "pitch";  if (pitch < 0) -> "Pitch negative"
  param_3[1] = (end - start) * 0x400 | pitch & 0xffff;
```

Grammar: **`D=<order>,<S|D>,<start>,<end>,<pitch>`**, all fields plain `_atol` decimal
(contrast with the base-93 numerals of the Jorge generation). The engine stores
`(start, ((end-start)<<10) | pitch&0xffff)` — i.e. the *same 8-byte per half-slot pair*
as an `L<n>`/`R<n>` record, with `dur = end − start`.

* `order` is a **0-based token index** into the atom's `U=` list (the same quantity the
  Jorge `n` carries, but 0-based because the legacy `U=` line has no context tokens):
  the reader computes `slot = ((order - atomSlotCount) + runningSlotCount) * 2`
  (`+1` when `part == 'D'`), which equals `(atomStart + order) * 2 (+1)`.
* `part` = `'S'` (left half, `Sinistra`) or `'D'` (right half, `Destra`) — the value the
  Jorge generation expresses implicitly by choosing an `L` or `R` line.
* `start`/`end` are the explicit bounds (the Jorge generation writes `start` only on the
  first line and a `dur` afterwards).
* Observed fields: `order ∈ {0,1}`; `(order 0, part D)` ×3300, `(order 1, part S)` ×3275,
  `(order 0, part S)` ×2; `pitch` is 0 in every one of the 6577 records.

### 12.2 `N=` with three numbers

`N=3482,6953,6578`:

| # | value | meaning | evidence |
|---|---|---|---|
| 1 | 3482 | #atoms | = exact `U=` count |
| 2 | 6953 | slot/frame count as computed by the reader | see below |
| 3 | 6578 | #`D` records + 1 | 6577 records present |

The reader (`FUN_100493b0`/`FUN_10028b80`) parses only the **first two** numbers (two
`_atol` calls, stored at state `+0x10`/`+0x18`); the third is never read — it is a
generator-side note. Number 3 being exactly `#D + 1` (one more than the records present)
is consistent with a counted terminating boundary.

Number 2: the raw grammatical token count of the `U=` lines is **6962** (3480 atoms with
2 tokens + 2 atoms with 1 token), but the reader's counter is
`strlen()` of the per-token id-byte buffer (`local_1d30 = strlen(local_a04)` in the first
pass; the consume loop in the second pass also stops at a 0 byte). `FUN_100190c0` returns
the phonetic-table *index*, and **index 0 is written as a 0 byte**, truncating the rest of
that line's count. Brute-forcing every token of the file: exactly two tokens —
`` Oe `` and `` `Oe `` (which never co-occur in a line and appear in identical position
patterns, 6 lines each) — reproduce a loss of exactly 9 tokens (6962 − 9 = 6953). So
exactly one of them is phonetic-table entry 0 in the Ludoviko table. (This is the same
mechanism that makes `N`[1] exact for Jorge, where no token decodes to index 0.)

### 12.3 Time base — shared with the Jorge generation

Positions are in the same **10 µs** unit:
max `end` in the file = 15 829 000 → **158.29 s**, and the companion PCM container
`payload/Ludoviko.16000.linear.256000.10.bin12` (5 069 459 B, header 125+28 = 153 B,
16-bit mono) holds `(5069459−153)/2 = 2 534 653` samples @16 kHz = **158.42 s**
= 15 841 581 ten-µs units (independently reported as 2 534 667 samples = 158.417 s).
The two agree to 0.08 %, so the 10 µs position unit is **shared by both `.sde`
generations**.

### 12.4 Generation routing

* The two generations are distinguishable by the header line:
  `LTTSComponentVersion=<ver>` (Jorge, `7.0.0`) vs **`VERSION=<n>`** (legacy, `7`).
  Both files also carry the same opaque `<int>,<int>` line 0 (`10,4` / `14,1`).
* **`jorge LoqTTS7.dll` handles both, and there is no version branch.** The literal
  `"VERSION="` does not occur anywhere in `LoqTTS7.dll`, `LTTS7Util.dll` or `LTTS7DB.dll`
  (byte search of all three jorge **and** old binaries: 0 hits), so the line is an
  *unknown tag* that the reader skips. Concretely, in the reader
  (`FUN_10049f10` jorge / `FUN_1002a890` old):
  * pass 1 reacts only to `'N'` (`FUN_100493b0`), `'U'` and `'P'` — `VERSION=7` and `D=`
    lines are ignored;
  * pass 2 dispatches on the tag character with cases
    `'A' 'D' 'L' 'R' 'F' 'S' 'U' 'P'` — `'D'` is the case that parses the legacy part
    records, and `'V'` has no case and is dropped.
  * The only tag with an explicit version branch is `LTTSComponentVersion=`, and even
    that is just "skip one extra header line" (`local_1d45 = 1`); it is *not* required for
    the file to load.

  So the same reader loads both the Jorge `U/L/R/S` files and the legacy `U/D` file;
  route by the header *for our own parsing*, not because the engine does.

---

## 13. Tool

`tools/sde_parse.py` implements §1–§7 and §12 and prints header fields, the first N atoms
with their decoded `L`/`R` (or `D`) records, record counts vs `N=`, the `U=` field
distribution, and the max timeline position. It auto-detects the generation from the
`VERSION=` / `LTTSComponentVersion=` header marker and the mask from byte 0.

Verified counts:

| file | `U=` | `L`/`R` | `D=` | `S=` | `P=` | `N=` | max end |
|---|---|---|---|---|---|---|---|
| `Jorge.sde` | 3647 | 149 426 | 0 | 146 | 0 | 3647, 82007 | 529 894 060 |
| `JorgeGildedPhrases.sde` | 261 | 4 876 | 0 | 260 | 0 | 261, 2960 | 17 776 419 |
| `JorgeGildedParalinguistics.sde` | 0 | 0 | 0 | 0 | 147 | (absent) | 19 915 859 |
| `payload/Ludoviko.sde13` | 3482 | 0 | 6577 | 0 | 0 | 3482, 6953, 6578 | 15 829 000 |




---

# APPENDIX: specs/EngineBinding.md

# Engine ↔ voice binding in Loquendo TTS 7 (voice "Jorge")

Scope: how the engine `LoqTTS7.dll` (jorge build) registers/loads the voice databases, how the
`.vde/.vcf/.gde/.ycf/.lcf` descriptors drive that registration, what the voice module
`LTTS7Jorge.dll` exposes, and the exact code path from a selected unit to a decoder request.

All addresses below are **VA (image base 0x10000000)**. Unless stated otherwise they are from the
**jorge** build, decompiled with Ghidra 12.1.2 into
`jorge_re/decomp_loqtts_jorge.txt` (engine), `jorge_re/decomp_jorge_voice.txt` +
`jorge_re/decomp_jorge_funcs.txt` (voice module) and `jorge_re/decomp_util_jorge.txt` (Util).
The older `engine_re/` build is quoted only where it is clearer/verified; old addresses are given as
`FUN_10024ff0 (old)`.

## 0. Build map (old `engine_re` → jorge)

| role | old build | jorge build |
|---|---|---|
| register DB list (`VocalDBName[i]` loop, 16 slots) | `FUN_10024ff0` | `FUN_100444d0` |
| register one DB via `ELQSharedResourceAdd` (".sde") | `FUN_10024ad0` | `FUN_10043f50` |
| register one DB via `LinkedSde[...]` plugin (`SdeDllMain`) | `FUN_10024ba0` | `FUN_10044040` |
| accessor: is there a `VocalDBName[0]`? | `FUN_10024f70` | `FUN_10044450` |
| `ELQLoadFileData` (loads .vcf/.vde/.lcf/.lde, gdeInclude, `__BinInfo__[i]`) | `FUN_1001b140` | `FUN_10052380` |

The engine never calls the `LTTS7Util.dll` API directly; it resolves every symbol through a
name→pointer table and calls `(*DAT_…)(…)`. The table was recovered from the DLL image (base
`0x100b2460`, 441 × `{char *name; void *slot}` pairs); the full dump is in
`tools/enginebind_symtab.txt`. Examples used below:

```
DAT_100b7054 = ELQBinClose        DAT_100b7058 = ELQBinGetBuffer     DAT_100b7064 = ELQBinGetSize
DAT_100b706c = ELQBinOpen         DAT_100b7070 = ELQBinSeek          DAT_100b73d0 = ELQDataDescriptorGetAttribute
DAT_100b73e0 = ELQDataDescriptorLoadFile                             DAT_100b73e4 = ELQDataDescriptorSetAttribute
DAT_100b70c4 = ELQFileFullName    DAT_100b70c8 = ELQFileResolveSymbolicName
DAT_100b7324 = ELQSharedResourceAdd                                  DAT_100b7148 = ELQLogWrite
DAT_100b72d8 = ELQPluginGetProc   DAT_100b72e0 = ELQPluginIni        DAT_100b72c4 = ELQPluginGetVersion
DAT_100b74fc = ELQBinaryHeaderLoadInfo                               DAT_100b7504 = ELQBinaryHeaderGetValue
DAT_100b750c = ELQBinaryHeaderIsPresent                              DAT_100b7410 = ELQmalloc
DAT_100b747c = ELQBufferAlloc     DAT_100b74b0 = ELQBufferFill       DAT_100b74c0 = ELQBufferInfoSetData
DAT_100b7090 = ELQConfigurationSetValue                              DAT_100b7080 = ELQConfigurationGetValue
```

## 1. Voice / language / database registration

### 1.1 The shipped descriptors (verbatim)

`jorge/pf/Loquendo/LTTS7/data/Jorge.vcf` (voice *configurator* — selects the DBs):

```
"Description"       = "Castilian Spanish male voice"
"BaseVoice"         = "Jorge"
"VoicePath"        = "voices/Jorge"
"VocalDBName[0]"    = "Jorge"
"VocalDBName[1]"    = "JorgeGildedPhrases"
"VocalDBName[2]"    = "JorgeGildedParalinguistics"
"Built-in"          = "Yes"
```

`jorge/pf/Loquendo/LTTS7/data/voices/Jorge/Jorge.vde` (voice *descriptor* — carries `Library`,
prosody defaults and the gilded include):

```
"BaseDescription"   = "Castilian Spanish male voice"
"Library"           = "LTTS7Jorge, Jorge"
"BaseSpeed"         = "128"
"BasePitch"         = "85"
"Gender"            = "Male"
"Age"               = "40"
"GildedTTS"         = "yes"
"gdeInclude"        = "JorgeGilded.gde"
"MotherTongue"      = "SpanishEs"
"MotherTongueAliases" = "SpanishEs,es-ES,ES,Castilian,es,Spanish"
```

`JorgeGilded.gde` defines the speech-act / paralinguistic phrase inventories
(`"Gilded[0]"="SpeechActs>~Extras>"`, `"SpeechActs[0]"="Apologies>~Approval>~…"`,
`"Extras[0]"="Aa>~Ah>~Aha>~…"`, and per-phrase text lists `"Apologies[0]"="Perdona!~…"`).

`Jorge.32000.LTTS7Codec210.44000.10.bin` is the acoustic DB of DB 0, and
`JorgeGildedPhrases.*` / `JorgeGildedParalinguistics.*` are the DBs of slots 1 / 2.

### 1.2 Constants resolved from the jorge DLL image

Resolved by mapping the VA through the PE section table and reading the bytes (script used:
eval cell "Read constant strings"; reproducible with `read` docs / the section table
`(.text 0x1000/0x400, .rdata 0x6E000/0x6C800, .data 0xB1000/0xAF200, imagebase 0x10000000)`):

| VA (jorge) | bytes | string | used as |
|---|---|---|---|
| `0x10097388` | `49 64 00` | `"Id"` | attribute name passed to `ELQDataDescriptorGetAttribute` in `FUN_10043f50` — **the DB name key** |
| `0x1009f3c4` | `2e 73 64 65 00` | `".sde"` | suffix appended to `VocalDBName[i]` in `FUN_100444d0` |
| `0x1009f3c8` | `00` | NUL | terminator written after `".sde"` |
| `0x1009f3c0` | `2f 00` | `"/"` (u16) | path separator appended before `VocalDBName[i]` |
| `0x1009f1e8` | `4c 54 54 53 37 00` | `"LTTS7"` | default LinkedSde plugin label |
| `0x1009f1f0` | `53 64 65 00` | `"Sde"` | suffix appended to `VocalDBName` → plugin/export name `<name>Sde` |
| `0x1009f234` | `37 2e 30 2e 31 00` | `"7.0.1"` | **engine SDE API version** compared with the SDE plugin version |
| `0x1009b248` | `62 75 69 6c 74 5f 69 6e 00` | `"built_in"` | forced coding name when no DB matches |
| `0x1009b1e8` / `0x1009b508` | `"Freq"` / `"Rank"` | | `ELQBinaryHeaderGetValue` tag names (with literal `"Coding"`,`"BitRate"`) |
| `0x100a1f6c` | `2e 64 6c 6c 00` | `".dll"` | appended to the `Library` DLL name |
| `0x100a1f74` / `0x100a1f88` | | `"FullLibraryName"` / `"LibraryVersion"` | attributes set from `Library` |
| `0x100a1f34` / `0x100a1f3c` | `".vde"` / `".lde"` | | voice / language descriptor suffixes |
| `0x9dbc4`→VA `0x1009f3c4` | `".sde"` | | (file-offset cross-check) |

Other extension literals in the engine `.rdata`: `.epd`, `.vad`, `.rcf` (`0x9…`), `.vcf` (RVA
`0x…`, file off 0xa06b0), `.lcf` (0xa06b8), `.ycf` (0xa06c0), `.vde` (0xa0734), `.lde` (0xa073c),
`.dll` (0xa076c).

**Correction to `specs/CONTEXT.md` §D:** the suffix constant is **`".sde"`, not `".bin"`**, and the
attribute name is **`"Id"`**, not an opaque tag. In the *old* build these live at
`DAT_1008eec0 = ".sde"` / `DAT_1008eec4 = 00` / `DAT_1008eec8 = "/"` and `DAT_10088a0c = "Id"`
(verified by reading `engine_re/LoqTTS7.dll` at RVA 0x8eec0 / 0x88a0c: bytes
`2e 73 64 65 00 00 00 00 2f 00 00 00 4c 69 6e 6b…` = `".sde\0\0\0\0/\0\0\0LinkedSde[%d]"` and
`49 64 00 00 4c 61 6e 67…` = `"Id\0\0Language=%s,…"`). Mapping those RVAs into the *jorge* DLL
yields unrelated data (the jorge `.rdata` layout differs), so the jorge values above were resolved
by content, not by RVA.

### 1.3 `FUN_10044450` — does DB 0 exist? (old `FUN_10024f70`)

```c
void FUN_10044450(void)
{
  int *unaff_ESI;
  char *local_28;
  char local_24 [32];
  …
  if (((unaff_ESI != (int *)0x0) && ((code *)*unaff_ESI == FUN_10043980)) && (unaff_ESI[1] != 0)) {
    _sprintf(local_24,"VocalDBName[%d]",0);
    (*DAT_100b73d0)(unaff_ESI[1],local_24,&local_28,0);   /* ELQDataDescriptorGetAttribute */
    if ((local_28 != (char *)0x0) && (*local_28 != '\0')) {
      …return;
    }
  }
  …
}
```

Binds DB index 0 in the *voice object* (`unaff_ESI[1]` = the descriptor), i.e. it is the predicate
"this voice has a speech-unit DB".

### 1.4 `FUN_10043f50` — fallback registration of one DB (old `FUN_10024ad0`)

```c
void __cdecl FUN_10043f50(undefined4 param_1)         /* param_1 = the .vcf/.vde descriptor   */
{
  char cVar1; int iVar2; int unaff_ESI;               /* unaff_ESI = session object           */
  undefined1 *local_410; undefined4 uStack_40c;
  undefined1 auStack_408 [4]; undefined1 auStack_404 [512]; undefined1 auStack_204 [512];
  …
  iVar2 = *(int *)(unaff_ESI + 8);
  (*DAT_100b73d0)(param_1,&DAT_10097388,&local_410,0);            /* GetAttribute(desc,"Id")    */
  (*DAT_100b70c4)(auStack_404);                                   /* ELQFileFullName(dir)       */
  if (local_410 == (undefined1 *)0x0) {
    local_410 = &DAT_100967df;                                    /* "" */
  }
  (*DAT_100b70c8)(auStack_204,0x200,auStack_404,local_410,0,0);   /* ELQFileResolveSymbolicName */
  cVar1 = (*DAT_100b73d0)(*(undefined4 *)(unaff_ESI + 4),"debug",auStack_408,0);
  iVar2 = (*DAT_100b7324)(*(undefined4 *)(iVar2 + 8),&uStack_40c,auStack_204,0,0,0); /* ELQSharedResourceAdd */
  if (iVar2 != 0) {
    if (cVar1 == '\0') goto LAB_10044024;
    uStack_40c = 0;
  }
  *(undefined4 *)(unaff_ESI + 0x18 + (uint)*(byte *)(unaff_ESI + 0x5b8) * 4) = uStack_40c;
  *(undefined1 *)(*(byte *)(unaff_ESI + 0x5b8) + 0x98 + unaff_ESI) = 1;
LAB_10044024:
  …
}
```

Semantics: `ELQLoadFileData`/`FUN_100444d0` first built the file name and stored it in the "Id"
attribute of the descriptor being loaded; here the engine takes that `Id`, resolves it against the
directory of the current descriptor, and registers the file as a **shared resource**; the returned
handle goes into the session's DB-handle array at `session+0x18+i*4` and the flag byte
`session[0x98+i] = 1` marks *this* DB slot as "loaded from a file" (as opposed to "from a plugin",
which `FUN_10044040` clears to 0). `"debug"` allows a failed Add to be tolerated.

### 1.5 `FUN_10044040` — LinkedSde plugin registration (old `FUN_10024ba0`)

```c
void __cdecl FUN_10044040(int param_1,char *param_2)     /* param_2 = VocalDBName[i] */
{
  …
  piVar2 = *(int **)(param_1 + 8);
  uVar7 = *(undefined4 *)(*piVar2 + 0xc00);               /* log handle */
  local_604 = DAT_1009f1e8;                               /* "LTTS"  */
  local_600 = DAT_1009f1ec;                               /* "7\0"   → local_604 = "LTTS7" */
  … copy param_2 (the DB name) to the end of the label buffer …
  *puVar12 = DAT_1009f1f0;                                /* append "Sde" → "<name>Sde"    */
  iVar5 = (*DAT_100b72e0)(param_1 + 0x58 + (uint)*(byte *)(param_1 + 0x5b8) * 4,uVar7,&local_604,
                          *piVar2 + 0x400,"SdeDllMain",0,0);          /* ELQPluginIni */
  if (iVar5 == 0) {
    (*DAT_100b72c8)(…, *(undefined4 *)(*(int *)(param_1 + 8) + 0x10)); /* ELQPluginLoadUtilSymbols */
    cVar3 = (*DAT_100b72c4)(…,uVar7,abStack_404);                      /* ELQPluginGetVersion */
    if (cVar3 == '\0') { … "Missing version information in sde dynamic library\n" … }
    … strcmp(abStack_404, &DAT_1009f234 /* "7.0.1" */) …
    if (iVar5 == 0) {
      … ELQPluginGetProc(…,"GetVersion",…); (*(code*)…)(abStack_404) …
      … ELQPluginGetProc(…,"CatVoiceVersion",&pcStack_60c); (*pcStack_60c)(abStack_204) …
      … ELQPluginGetProc(…,"CatSdeData",&pcStack_610);
      uVar7 = (*DAT_100b72d0)(…);                       /* ELQPluginGetFileName */
      iVar5 = (*pcStack_610)(param_1 + 0x18 + (uint)*(byte *)(param_1 + 0x5b8) * 4);
      if (iVar5 != 0) (*DAT_100b7148)(1,local_614,"Error loading dbunita from %s\n",uVar7);
      …
```

`LinkedSde[ALL]` (or `LinkedSde[i]`) = `y`/`Y` selects this path: the module
`<prefix><VocalDBName>+"Sde"` is loaded as an ELQ plugin whose entry point must be the export
`SdeDllMain`, and which must export `GetVersion`, `CatVoiceVersion` (voice version must compare
equal), `CatSdeData` (returns the dbunita handle written to `session+0x18+i*4`) — the log string is
`"Error loading dbunita from %s"` and the version mismatch message is
`"%s voice version (%s) is not compatible with voice version (%s)"`; the engine's own SDE API
version is `"7.0.1"`. **No shipped module exports `SdeDllMain` and the Jorge descriptors contain no
`LinkedSde` tag, so Jorge always uses the fallback path (1.6).**

### 1.6 `FUN_100444d0` — the 16-slot DB registration loop (old `FUN_10024ff0`)

```c
void __thiscall FUN_100444d0(void *this,int param_1)      /* this = descriptor, param_1 = session */
{
  …
  bVar1 = *(byte *)(param_1 + 0x5b8);                     /* DB slot counter, starts at 0 */
  while (bVar1 < 0x10) {
    bVar3 = false;
    (*DAT_100b73d0)(this,"LinkedSde[ALL]",&local_634,0);
    if ((local_634 == (char *)0x0) || ((*local_634 != 'y' && (*local_634 != 'Y')))) {
      _sprintf(acStack_624,"LinkedSde[%d]",(uint)*(byte *)(param_1 + 0x5b8));
      (*DAT_100b73d0)(this,acStack_624,&local_634,0);
      if ((local_634 != (char *)0x0) && ((*local_634 == 'y' || (*local_634 == 'Y')))) goto LAB_1004457b;
    } else {
LAB_1004457b: bVar3 = true;
    }
    _sprintf(acStack_624,"VocalDBName[%d]",(uint)*(byte *)(param_1 + 0x5b8));
    (*DAT_100b73d0)(this,acStack_624,&local_634,0);
    if ((local_634 == (char *)0x0) || (*local_634 == '\0')) {
      if (*(char *)(param_1 + 0x5b8) == '\0') {
        (*DAT_100b7148)(2,…,"* SYSTEM: No speech unit database has been defined for this voice\n");
      }
      goto LAB_10044819;
    }
    if (bVar3) { iVar5 = FUN_10044040(param_1,local_634); }        /* plugin path (§1.5) */
    else {
      _sprintf(acStack_624,"VocalDBPath[%d]",(uint)*(byte *)(param_1 + 0x5b8));
      (*DAT_100b73d0)(this,acStack_624,&pcStack_630,0);
      if ((pcStack_630 == (char *)0x0) || (*pcStack_630 == '\0')) {
        (*DAT_100b73d0)(this,"VoicePath",&pcStack_630,0);          /* fall back to VoicePath */
        …build "dir/" + VocalDBName…   *(undefined2 *)pcVar10 = DAT_1009f3c0;  /* "/" */
      } else { …same, base = VocalDBPath[i]… }
      (*DAT_100b73d0)(this,"DataPath",&pcStack_628,0);             /* fetched into acStack_204 */
      …
      *(undefined4 *)((int)puVar7 + 1) = DAT_1009f3c4;             /* append ".sde"  */
      *(undefined1 *)((int)puVar7 + 5) = DAT_1009f3c8;             /* NUL            */
      iVar5 = FUN_10043f50(this);                                 /* §1.4: register the file */
    }
    if (iVar5 != 0) goto LAB_10044819;
    pcVar10 = (char *)((uint)*(byte *)(param_1 + 0x5b8) * 0x51 + 0xa8 + param_1);
    pcVar9 = local_634;
    do { cVar2 = *pcVar9; *pcVar10 = cVar2; pcVar9++; pcVar10++; } while (cVar2 != '\0');
    *(char *)(param_1 + 0x5b8) = *(char *)(param_1 + 0x5b8) + '\x01';   /* next slot */
    bVar1 = *(byte *)(param_1 + 0x5b8);
  }
  (*DAT_100b7148)(1,…,"Too many speech unit databases (max %d)\n",0x10);
LAB_10044819: …
}
```

Facts:
* loop over `i = 0…15`, reading `LinkedSde[ALL]`, `LinkedSde[i]`, `VocalDBName[i]`,
  `VocalDBPath[i]`, `VoicePath`, `DataPath` from the **descriptor**;
* per slot it builds the path `VocalDBPath[i] | VoicePath` + `"/"` + `VocalDBName[i]` and appends
  **`".sde"`** → for `Jorge.vcf` that is `voices/Jorge/Jorge.sde`,
  `voices/Jorge/JorgeGildedPhrases.sde`, `voices/Jorge/JorgeGildedParalinguistics.sde` — exactly the
  three shipped inventories;
* the DB **name** (`VocalDBName[i]`) is stored per slot in the session at `session + 0xa8 + i*0x51`
  (0x51 = 81-byte name field) and the resource handle at `session + 0x18 + i*4`;
* `0xa8` (jorge) vs `0xa4` (old) and `0x18/0x98` vs `0x14/0x94` are the only struct shifts between
  builds.
* The path derivation copies `VoicePath`/`VocalDBPath[i]` into +0x604-relative buffer and the final
  `".sde"` string into an overlapping 512-byte buffer at `ebp-0x404`; Ghidra renders these two
  buffers with overlapping names (`acStack_604`, `uStack_405/auStack_400`, `acStack_204`), so the
  *exact* destination of the last copy is ambiguous in the decompilation. `DataPath` is read from
  the descriptor and copied into a local in every branch but is never referenced afterwards in the
  decompiled body — **[INFERENCE]** it is the fallback directory when the descriptor has neither
  `VocalDBPath[i]` nor `VoicePath` (the engine also logs `"DataPath not found in voice descriptor\n"`
  from another function), but the code as decompiled does not show that use.

### 1.6b `FUN_10043cb0` — release of all registered DBs

```c
/* decomp_loqtts_jorge.txt */
void FUN_10043cb0(void)
{
  byte bVar1; uint uVar2; int unaff_ESI;
  if (unaff_ESI != 0) {
    while (*(char *)(unaff_ESI + 0x5b8) != '\0') {
      bVar1 = *(char *)(unaff_ESI + 0x5b8) - 1;
      *(byte *)(unaff_ESI + 0x5b8) = bVar1;
      uVar2 = (uint)bVar1;
      if (*(int *)(unaff_ESI + 0x18 + uVar2 * 4) != 0) {
        if (*(char *)(uVar2 + 0x98 + unaff_ESI) == '\0') {
          (*DAT_100b72cc)(*(undefined4 *)(unaff_ESI + 0x58 + uVar2 * 4));      /* ELQPluginDelete */
          *(undefined4 *)(unaff_ESI + 0x58 + (uint)*(byte *)(unaff_ESI + 0x5b8) * 4) = 0;
        }
        else {
          (*DAT_100b7334)(*(undefined4 *)(*(int *)(unaff_ESI + 8) + 8),
                          **(undefined4 **)(unaff_ESI + 0x18 + uVar2 * 4),0);  /* ELQSharedResourceRemove */
          *(undefined4 *)(unaff_ESI + 0x58 + (uint)*(byte *)(unaff_ESI + 0x5b8) * 4) = 0;
        }
      }
    }
  }
}
```
This confirms the two handle kinds and the flag's polarity: `session[0x98+i] == 0` → the slot is a
*plugin* handle (`session+0x58+i*4`, freed with `ELQPluginDelete`); `== 1` → the slot is an
*ELQ shared-resource* handle whose first dword (`**handle`) is passed to `ELQSharedResourceRemove`
(together with the session's resource set at `*(session+8)+8`). So the `.sde` registered in §1.4 is
a shared resource, not a plugin.

### 1.7 What actually opens the `.bin`: `FUN_10052380` (`ELQLoadFileData`)

`FUN_10052380(param_1, param_2, param_3, param_4, param_5)` is the generic descriptor loader used
for voices and languages (`param_5` picks the extension pair: voice → `.vcf` + `.vde`,
language → `.lcf` + `.lde`; the constants `".vde"`=`0x100a1f34`, `".lde"`=`0x100a1f3c`,
`".dll"`=`0x100a1f6c`). Core of it:

```c
  puVar5 = FUN_10052340();                                     /* returns the configurator suffix */
  _sprintf(acStack_804,"%s%s",param_2,puVar5);
  (*DAT_100b70c4)(acStack_604,param_4,acStack_804);            /* resolve <base><.vcf> */
  cVar2 = (*DAT_100b73e0)();                                   /* ELQDataDescriptorLoadFile */
  if (cVar2 == '\0') { …"Unable to open %s configurator file \"%s\"\n"… }
  if ((param_5 != 1) && (param_5 != 2)) { … }
  …
  (*DAT_100b70c4)(acStack_604,acStack_404,pcStack_86c);        /* the "gdeInclude" value, if any */
  cVar2 = (*DAT_100b73d0)();                                   /* GetAttribute(…,"gdeInclude"…) */
  if ((cVar2 != '\0') && (iStack_864 != 0)) {
      (*DAT_100b70c4)(acStack_604,acStack_404,iStack_864);
      cVar2 = (*DAT_100b73e0)();                               /* ELQDataDescriptorLoadFile */
      if (cVar2 == '\0') { pcVar3 = "Unable to open gilded descriptor file \"%s\"\n"; … }
  }
  iVar4 = 0;
  _sprintf(acStack_804,"VocalDBName[%d]",0);
  cVar2 = (*DAT_100b73d0)();
  while ((cVar2 != '\0' && (iStack_870 != 0))) {
    _sprintf(acStack_804,"VocalDBPath[%d]",iVar4);
    cVar2 = (*DAT_100b73d0)();
    if ((cVar2 == '\0') || (iStack_858 == 0)) { …acStack_604 = acStack_404 (the .vcf's dir)… }
    else { (*DAT_100b70c4)(acStack_604,local_860,iStack_858); }
    iVar7 = (*DAT_100b74fc)(iStack_870,acStack_604,uVar1);     /* ELQBinaryHeaderLoadInfo(name,dir,log) */
    if (iVar7 == 0) {
      _sprintf(acStack_804,"BINLoad[%d]",iVar4);
      cVar2 = (*DAT_100b73d0)();
      if (((cVar2 == '\0') || (iStack_85c == 0)) ||
         (iVar7 = (*DAT_100b7428)(iStack_85c,&DAT_100976e4 /* "no" */), iVar7 != 0)) {
        (*DAT_100b7148)(1,uVar1,"ELQLoadFileData: no binary data for %s in %s\n",iStack_870,acStack_604);
        goto LAB_10052b50;
      }
    }
    _sprintf(acStack_804,"__BinInfo__[%d]",iVar4);
    (*DAT_100b73e4)();                                         /* SetAttribute("__BinInfo__[i]",hdr) */
    iVar4 = iVar4 + 1;
    _sprintf(acStack_804,"VocalDBName[%d]",iVar4);
    cVar2 = (*DAT_100b73d0)();
  }
  … same loop again for "VocalAddOn[%d]" (continuing the __BinInfo__ indices) …
  … and, when the descriptor has "Library", get the DLL name + "FullLibraryName" + "LibraryVersion" …
```

So per `VocalDBName[i]`:
1. the directory is `VocalDBPath[i]` (resolved with `ELQFileResolveSymbolicName` against the
   descriptor's own directory) or, absent that, the directory of the `.vcf`;
2. `ELQBinaryHeaderLoadInfo(name, dir, log)` **globs `<dir>/*.bin`** and keeps every file whose
   header tag `Label` equals `name` **case-insensitively** (see §1.8). It is *not* a file-name
   lookup: `VocalDBName[i]` is the **`Label` TLV of the `.bin`**, and all matching variants
   (different `Freq`/`Coding`/`BitRate`/`Rank`) are collected;
3. the resulting object is stored in the descriptor as `__BinInfo__[i]`;
4. `BINLoad[i]` (`no`/`false`/`ignore` disables) is a switch that suppresses the hard error.

`FUN_10022a50` (the "signal processor" voice loader, `FUN_100225e0` calls it) then *chooses* one of
the collected headers: it reads `SetSampleRate`/`SetCoding`/`SetBitRate` (or
`ForcedSampleRate`/`ForcedCoding`/`ForcedBitRate`) from the descriptor, defaults
`0xac44` = 44100 when the `debug`/`freq` keys are present, and for every `__BinInfo__[i]` calls

```c
  cVar3 = (*DAT_100b7504)(iStack_a6c,&DAT_1009b1e8 /*"Freq"*/,&local_a78,&DAT_10096814,1);  /* ELQBinaryHeaderGetValue */
  cVar3 = (*DAT_100b7504)(iStack_a6c,"Coding",&local_a70,&DAT_10096814,1);
  cVar3 = (*DAT_100b7504)(iStack_a6c,"BitRate",&local_a60,&DAT_10096814,1);
  cVar3 = (*DAT_100b7504)(iStack_a6c,&DAT_1009b508 /*"Rank"*/,&local_a58,&DAT_10096814,1);
  …
  uVar5 = iVar8 * (iVar7 / 100) * (iVar6 / 100);   /* score: freq × coding% × bitrate% ; keep max */
```

and stores the winner's `Freq` in `session+…` (`param_1+0xc`) and `BitRate` in `param_1+0xd`
(see `FUN_100225e0`: `FUN_10022a50(local_404,param_1,local_204,(uint *)(param_1 + 0xc),param_1 + 0xd)`).
Failure logs `"* SIGNAL PROCESSOR: Unable to find a vocal db for this voice. Check %s.vcf file's
content"` — i.e. selection is driven by the **`.vcf` keys vs the `.bin` header tags**.

### 1.8 `ELQBinaryHeaderLoadInfo` — the `*.bin` matcher (Util, jorge VA 0x100026d0)

```c
undefined4 * __cdecl ELQBinaryHeaderLoadInfo(byte *param_1,void *param_2,int *param_3)
                                              /* param_1 = wanted Label, param_2 = directory */
{
  …
  puVar5 = _malloc(8);                       /* {ELQBuffer *list; int count} */
  *puVar5 = 0; puVar5[1] = 0;
  iVar6 = ELQBufferInit(puVar5);
  …
  local_c = FUN_10001fd0(param_2,&local_18);          /* glob, pattern "*.bin" */
  while (local_14 < local_c) {
      pcVar7 = (char *)ELQBufferGetString(puVar4);
      iVar6 = FUN_10003510(&local_18,'d',param_3,pcVar7,0,'\0');   /* ELQBinOpenNoCache */
      if (iVar6 == 0) {
        uVar8 = FUN_10002550(pcVar7,param_3);                      /* ReadHeader + TLV parse */
        if ((char)uVar8 != '\0' && local_1c != 0 && (code *)*local_1c == ELQDataDescriptorIni) {
          for (puVar5 = local_1c[2]; puVar5 != 0; puVar5 = puVar5[4]) {
            iVar6 = ELQstricmp((byte *)*puVar5,(byte *)"Label");
            if (iVar6 == 0) {
              if ((byte *)puVar5[1] != 0 &&
                  (iVar6 = ELQstricmp((byte *)puVar5[1],param_1), puVar5 = local_10, iVar6 == 0)) {
                iVar6 = ELQBufferCatRaw((int *)*local_10,&local_1c,4,0);   /* collect the descriptor */
                …
                puVar5[1] = puVar5[1] + 1;
                goto LAB_10002804;
              }
              break;
            }
          }
        }
        ELQDataDescriptorDelete(piVar3);
LAB_10002804:
        ELQBinClose(local_18);
        …advance the name buffer…
      } else {
        ELQLogWrite(8,param_3,"ELQBinaryHeaderLoadInfo: error opening %s file.");
      }
      local_14 = local_14 + 1;
  }
  ELQBufferFree(puVar4);
  return puVar5;
}
```

(The older build shows the glob pattern literally: `uVar3 = FUN_10004cf0(&local_14,"*.bin",param_3);`
then `pcVar4 = (char *)ELQBufferGetString(local_14); ELQBinOpenNoCache(&local_10,'d',param_3,pcVar4,0);`
… `ELQDataDescriptorGetAttribute(local_18,(byte *)"Label",&local_8,0); … ELQstricmp(local_8,param_1)` —
quoted verbatim in §"old utility" below.)

```c
/* decomp_util.txt, ELQBinaryHeaderLoadInfo @ 100051f0 (older Util) */
        uVar3 = FUN_10004cf0(&local_14,"*.bin",param_3);
        local_c = 0; local_4 = uVar3;
        if (uVar3 != 0) {
          do {
            pcVar4 = (char *)ELQBufferGetString(local_14);
            iVar2 = ELQBinOpenNoCache(&local_10,'d',param_3,pcVar4,0);
            if (iVar2 == 0) {
              uVar3 = FUN_10005100(pcVar4,param_3);        /* ReadHeader */
              if (((((char)uVar3 == '\0') ||
                   (uVar5 = ELQDataDescriptorGetAttribute(local_18,(byte *)"Label",&local_8,0), …
                     iVar2 = ELQstricmp(local_8,param_1), iVar2 != 0)) {
                ELQDataDescriptorDelete(local_18);
              } else {
                iVar2 = ELQBufferCatRaw((int *)*puVar1,&local_18,4,0);
                … puVar1[1] = puVar1[1] + 1; …
              }
              ELQBinClose(local_10);
              ELQBufferDeleteString(local_14);
```

## 2. Descriptor semantics relevant to the DB

The configurator extension is chosen by a descriptor *type* through `FUN_10052340`:

```c
undefined1 * FUN_10052340(void)          /* in_EAX = type */
{
  undefined4 in_EAX;
  switch(in_EAX) {
  case 0: return &DAT_100a1ea8;          /* ".rcf" */
  case 1: return &DAT_100a1eb0;          /* ".vcf" */
  case 2: return &DAT_100a1eb8;          /* ".lcf" */
  case 3: return &DAT_100a1ec0;          /* ".ycf" */
  default: return &DAT_100967df;         /* ""     */
  }
}
```
and `FUN_10052380(...,param_5)` is called with `param_5 = 1` (voice), `2` (language) or `3`
(other/"general"; see the callers at dump lines 9181 / 9495 / 10187). Only `param_5 == 1` reaches the
`gdeInclude` + `VocalDBName[i]`/`VocalAddOn[i]` registration block (`LAB_10052808`), and both 1 and 2
load their descriptor via `".vde"`/`".lde"` plus the `Library` keys. `"BaseVoice"` (VA `0x100a1f18`)
and `"BaseLanguage"` (`0x100a1f28`) name the *base* configurator the current file inherits from.

| extension | role (evidence) | keys that matter for the DB |
|---|---|---|
| `.vcf` (type 1) | voice *configurator* | `BaseVoice`, `VoicePath`, `VocalDBName[i]`, `VocalDBPath[i]`, `Built-in`, `SetSampleRate`/`SetCoding`/`SetBitRate` (+`Forced*`), `BINLoad[i]` |
| `.vde` | voice *descriptor*, appended via `&DAT_100a1f34` (`.vde`, `"voice"`/`"language"` log wording), guarded by the `Library` key (`"Unable to find \"library\" key in descriptor file \"%s\""`) | `Library` (=`<dll>,<name>`), `FullLibraryName`, `LibraryVersion`, `gdeInclude`, `GildedTTS`, `BaseSpeed`, `BasePitch`, `MotherTongue*` |
| `.lcf` (type 2) | language configurator | language `DataPath`, `BaseLanguage` |
| `.lde` | language *descriptor* (`&DAT_100a1f3c`) | `Library` |
| `.rcf` (type 0), `.ycf` (type 3) | other configurators (same loader, no VDB registration) | — |
| `.gde` | *gilded* descriptor, pulled in by `gdeInclude` from the `.vde` (`"Unable to open gilded descriptor file \"%s\"\n"`, old dump `FUN_1001b140` lines 22505+) | `Gilded[0]="SpeechActs>~Extras>"`, `SpeechActs[i]`, `Extras[i]`, and the phrase lists (`Apologies[0]`, `Greetings[0]`, … `_\<Name\>` entries for the paralinguistics) |
| `.sde` | unit inventory; the suffix appended in §1.6, registered as an ELQ shared resource named by the descriptor's `Id` | opened via `ELQSharedResourceAdd`, handle in `session+0x18+i*4` |
| `.bin` | acoustic DB; found by `ELQBinaryHeaderLoadInfo` (§1.8) via `*.bin` glob + header `Label` == `VocalDBName[i]`; selected by `Freq`/`Coding`/`BitRate`/`Rank` (§1.7) | TLV tags `Name/Label/Comment/Freq/Coding/BitRate/Rank/Version` |

* **Which keys select a DB**: `VocalDBName[i]` (+ optional `VocalDBPath[i]`) selects the *label*;
  `SetSampleRate`/`SetCoding`/`SetBitRate` (or the `Forced*` variants) select the *variant* of that
  label; `BINLoad[i]="no"` skips it. Rank is read and folded into the score.
* **Gilded mechanism**: `GildedTTS="yes"` + `gdeInclude="JorgeGilded.gde"` in the `.vde` make the
  engine load the `.gde` into the same descriptor (`ELQDataDescriptorLoadFile`), which then carries
  the speech-act/paralinguistic phrase inventories. Those phrases are *separate text units*, and
  their audio comes from additional `VocalDBName[1..2]` entries (`JorgeGildedPhrases`,
  `JorgeGildedParalinguistics`) — the `.gde` names are exactly the `P=<name>|…` names in
  `JorgeGildedParalinguistics.sde` (`Aa`, `Aa_01`, … `Yawn_04`) and the `\_<Name>` entries of
  `JorgeGildedPhrases.sde`. So a gilded/speech-act unit enters selection by (a) the `.gde` mapping
  text→phrase name and (b) that name selecting DB slot 1/2 through the same
  `VocalDBName[i]`/`__BinInfo__[i]` machinery; `FonVidAllofonoVoce` (§3) is only consulted for
  normal (non-gilded) phone→voice mapping.
* `Library` is parsed by taking the first token up to `' '`, `','` or `';'` (`LTTS7Jorge`), appending
  `".dll"`, recording it as `FullLibraryName` and its version (`ELQGetComponentVersion`) as
  `LibraryVersion` (old dump `FUN_1001b140`):

```c
    /* decomp_loqtts.txt, FUN_1001b140 (jorge: FUN_10052380, same logic) */
    cVar2 = ELQDataDescriptorGetAttribute(param_1,"Library",&local_6bc,0);
    if ((cVar2 != '\0') && (local_6bc != (char *)0x0)) {
      …copy up to ' ' / ',' / ';' into local_6a4…
      ELQFileFullName(local_204,local_6b8,local_6a4);
      _sprintf(local_6a4,"%s%s",local_204,&DAT_1008b9c0);        /* ".dll" */
      … ELQDataDescriptorSetAttribute(param_1,"FullLibraryName",iVar4,1,ELQfree);
      cVar2 = ELQGetComponentVersion(local_6a4,local_654,0x50);
      … ELQDataDescriptorSetAttribute(param_1,"LibraryVersion",iVar4,1,ELQfree);
    }
    …
    cVar2 = ELQDataDescriptorGetAttribute(param_1,"gdeInclude",&local_6b4,0);
    if ((cVar2 != '\0') && (local_6b4 != 0)) {
      ELQFileFullName(local_604,local_404,local_6b4);
      cVar2 = ELQDataDescriptorLoadFile(param_1,local_604,1);
      if (cVar2 == '\0') { pcVar3 = "Unable to open gilded descriptor file \"%s\"\n"; goto LAB_1001b8aa; }
    }
```

`Library = "LTTS7Jorge, Jorge"` therefore means: DLL `<voices/Jorge>/LTTS7Jorge.dll`, and the second
token `Jorge` is the module's **export name** used with `ELQPluginIni(...,"Jorge",...)` (§3).

## 3. The voice module interface (`LTTS7Jorge.dll`)

The DLL has exactly **one export**, named **`Jorge`**, at **RVA 0x1170** (VA `0x10001170`) —
verified from the PE export directory (`nfunc=1, nname=1, dllname=LTTS7Jorge.dll`). It is a
name-dispatch entry point:

```c
/* jorge_re/decomp_jorge_voice.txt, function "Jorge" @ 10001170 */
undefined * __cdecl Jorge(byte *param_1)                  /* param_1 = requested procedure name */
{
  byte bVar1; byte *pbVar2; int iVar3; byte *pbVar4; int iVar5; bool bVar6;
                    /* 0x1170  1  Jorge */
  if ((param_1 == (byte *)0x0) || (DAT_10008868 != -0x55)) {   /* must equal 0xFFFFFFAB at run time */
    return (undefined *)0x0;
  }
  iVar5 = 0;
  do {
    pbVar4 = (&PTR_s_GetVersion_10008878)[iVar5 * 2];        /* name string */
    pbVar2 = param_1;
    do {
      bVar1 = *pbVar2;
      bVar6 = bVar1 < *pbVar4;
      if (bVar1 != *pbVar4) {
LAB_100011b0:
        iVar3 = (1 - (uint)bVar6) - (uint)(bVar6 != 0);
        goto LAB_100011b5;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar2[1];
      bVar6 = bVar1 < pbVar4[1];
      if (bVar1 != pbVar4[1]) goto LAB_100011b0;
      pbVar2 = pbVar2 + 2;
      pbVar4 = pbVar4 + 2;
    } while (bVar1 != 0);
    iVar3 = 0;
LAB_100011b5:
    if (iVar3 == 0) {
      return (&PTR_LAB_1000887c)[iVar5 * 2];                 /* target procedure */
    }
    iVar5 = iVar5 + 1;
    if (7 < iVar5) {
      return (undefined *)0x0;
    }
  } while( true );
}
```

`DAT_10008868` is an initialisation magic: its bytes in the file are `ab b1 fe de …`, but the check
compares the dword with `0xFFFFFFAB`, so the value is patched during load before any
`ELQPluginGetProc` call can succeed; every other function in the module is therefore unreachable
until the DLL has been initialised.

### 3.1 The complete name table

Read from the DLL image at VA `0x10008878` (16 dwords = 8 × `{char *name; void *proc}`,
terminated by `iVar5 > 7` in the dispatcher):

| # | name (VA of string) | proc VA | jorge body |
|---|---|---|---|
| 0 | `GetVersion` (`0x100081f4`) | `0x10001150` | copies `"7.1.0"` into the caller buffer |
| 1 | `ELQGetPhonemes` (`0x100081e4`) | `0x10001060` | `*out = 0x100087a0` (phoneme inventory) |
| 2 | `FonVidAllofonoVoce` (`0x100081d0`) | `0x100011e0` | stub: `xor eax,eax; ret` (= `return 0`) |
| 3 | `FonVidAllofonoAnalisi` (`0x100081b8`) | `0x10001260` | allophone→unit-code analysis |
| 4 | `FonVidMetaFonema` (`0x100081a4`) | `0x100013b0` | archiphoneme substitution (delegates to `FUN_100011f0`) |
| 5 | `FonVidAnalisi2Sintesi` (`0x1000818c`) | `0x100013d0` | unit-code remap table |
| 6 | `ELQVoiceChannelOpen` (`0x10008178`) | `0x10001070` | allocate channel (0x18) + resource |
| 7 | `ELQVoiceChannelClose` (`0x10008160`) | `0x10001100` | free channel + resource |

Additional strings in the module: `LTTSComponentVersion=7.1.0` (file off 0x88b8),
`Out of memory for ELQJorgeChannelType` (0x88d4), `Out of memory for FonJorgeChannelType`
(0x8138). Imports: `ELQLogWrite`, `ELQmalloc`, `ELQfree`, `ELQSharedResourceIni`,
`ELQSharedResourceDelete` from `LTTS7Util.dll`.

### 3.2 Recovered bodies and signatures

`GetVersion` — `int GetVersion(char *buf)` (dest = `param_1`; the referenced literal is VA
`0x100088CD`, the `"7.1.0"` tail of the `LTTSComponentVersion=7.1.0` string at `0x100088B8`, while
the sibling Ludoviko module's identical function copies the whole `LTTSComponentVersion=7.4.0`):
```c
undefined4 FUN_10001150(int param_1)          /* param_1 = destination buffer */
{
  char cVar1; char *pcVar2;
  pcVar2 = "7.1.0";
  do {
    cVar1 = *pcVar2;
    pcVar2[param_1 + -0x100088cd] = cVar1;   /* dest = param_1 (Ghidra's base arithmetic) */
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return 0;
}
```
The engine only tests the return value (`iVar5 = (*(code *)auStack_608)(abStack_404); … iVar5 == 0`)
and compares the produced string with the SDE plugin's `CatVoiceVersion` output in the `LinkedSde`
path.

`ELQGetPhonemes` — `int ELQGetPhonemes(void **outTable)`; returns the module's static phoneme
inventory structure (VA `0x100087A0`, an array of `{char *allophone; …}` entries; the example-word
strings `cuatro, rabia, colcha, calle, cola, pido, coro, cinco, infierno, mancha, noche, kama,
pizza, cocido, Genova, chocolate, show, desde, consejo, juzgar, facil, conyuge, ayuda, llegada,
guerra, escudo, toldo, amaba, bueno, caja, loco, tarde, capa, causa, rey, capitulo, cura, soldado,
coche, retorica, silla, pidenos, pesca, llamo, caro` live at VA `0x10008200…0x10008380` and are the
per-phoneme example words of that table):
```c
undefined4 FUN_10001060(undefined4 *param_1)   /* *param_1 = out table */
{
  *param_1 = &PTR_PTR_100087a0;
  return 0;
}
```

`ELQVoiceChannelOpen` — `int ELQVoiceChannelOpen(void *voiceCtx)`, `voiceCtx+0x4` = out channel,
`voiceCtx+0x10` = engine, `voiceCtx+0x14` = log handle; returns 0 or 5 (`Out of memory`):
```c
int FUN_10001070(int param_1)
{
  undefined4 *puVar1; int iVar2;
  puVar1 = (undefined4 *)ELQmalloc(0x18);                  /* ELQJorgeChannelType, 24 bytes */
  if (puVar1 == (undefined4 *)0x0) {
    ELQLogWrite(1,*(undefined4 *)(param_1 + 0x14),"Out of memory for ELQJorgeChannelType\n");
    return 5;
  }
  puVar1[2] = 0; puVar1[1] = 0; *puVar1 = 0; puVar1[4] = 0; puVar1[5] = 0;
  ELQSharedResourceIni(puVar1 + 5,0,0);                    /* channel+0x14 = shared-resource object */
  iVar2 = FUN_10001000(*(int *)(param_1 + 0x10),puVar1 + 2);  /* allocate FonJorgeChannelType (4B) */
  if (iVar2 == 0) {
    *(undefined4 **)(param_1 + 4) = puVar1;
  }
  return iVar2;
}
```
```c
undefined4 __cdecl FUN_10001000(int param_1,int *param_2)   /* param_2 = &channel[2] */
{
  int iVar1;
  iVar1 = ELQmalloc(4);                     /* FonJorgeChannelType */
  *param_2 = iVar1;
  if (iVar1 == 0) {
    ELQLogWrite(1,*(undefined4 *)(param_1 + 0x14),"Out of memory for FonJorgeChannelType\n");
    return 5;
  }
  *(int *)(param_1 + 0x48) = iVar1;         /* engine-side back pointer */
  return 0;
}
```
Channel layout (**FonJorgeChannelType**) is the `0x18` window anchored at `channel+0xc`, stride
`0x18` per output unit (`*(byte *)(channel + 0xc + i*0x18)`), i.e. 24 bytes per unit, first byte at
`+0xc` = unit/variant code, the remaining 23 bytes are set by the engine.

`ELQVoiceChannelClose` — `int ELQVoiceChannelClose(void *voiceCtx)`:
```c
undefined4 __cdecl FUN_10001100(int param_1)
{
  int iVar1,iVar2,iVar3,iVar4; undefined4 *puVar5;
  if ((param_1 != 0) && (iVar1 = *(int *)(param_1 + 4), iVar1 != 0)) {
    iVar3 = *(int *)(iVar1 + 8);            /* FonJorgeChannelType */
    iVar2 = *(int *)(param_1 + 0x10);       /* engine */
    iVar4 = iVar1 + 0x10;
    puVar5 = (undefined4 *)(iVar1 + 0x14);
    FUN_10001040(iVar2,iVar3);              /* ELQfree(FonJorgeChannelType); engine[0x48]=0 */
    ELQSharedResourceDelete(*(undefined4 *)(iVar1 + 0x14),iVar2,iVar3,iVar4,puVar5);
    ELQfree(iVar1);
    *(undefined4 *)(param_1 + 4) = 0;
  }
  return 0;
}
```

`FonVidAllofonoVoce` — **a no-op in this voice**:
```c
undefined4 FUN_100011e0(void) { return 0; }        /* bytes at 0x100011e0: 33 c0 c3 (xor eax,eax; ret) */
```
The engine still binds it (see 3.3) but for Jorge the allophone→voice-unit decision is entirely
driven by `FonVidAllofonoAnalisi` + the SDE.

`FonVidAllofonoAnalisi(channel, inUnits, inIndex*, table*)` — maps the incoming allophone stream to
**unit variant codes** written into the channel's 24-byte-per-unit array:
```c
undefined4 FUN_10001260(int param_1,int *param_2,int *param_3,int *param_4)
{
  int iVar1,iVar2,iVar3,iVar4; uint uVar5;
  iVar1 = *(int *)(param_1 + 4);            /* channel */
  iVar2 = *param_3;                         /* out index */
  iVar3 = *param_2;                         /* in index  */
  iVar4 = *(int *)(param_1 + 0x10);         /* in array  */
  uVar5 = *(uint *)(*(int *)(iVar4 + iVar3 * 4) + 4);   /* inUnit->tag */
  if (uVar5 < 0x1100405) {
    if (uVar5 == 0x1100404) {
      if ((iVar3 != 0) && (*(int *)(*(int *)(iVar4 + -4 + iVar3 * 4) + 4) == 0x10104)) {
        *(undefined1 *)(iVar1 + 0xc + iVar2 * 0x18) = 0x15;
        *param_3 = iVar2 + 1; *param_2 = *param_2 + 1; return 0;
      }
    }
    else if (uVar5 == 0x1002404) { … *(…)= 0x14; … }
    else if ((uVar5 == 0x1008404) && iVar3 != 0 && (…prev/next tags 0x10104/0x28/0x18…)) { …= 0x13; … }
  } else if ((uVar5 == 0x3008014) && (iVar3 == 0)) { …= 0x1c; … }
  FUN_100011f0(param_3,param_4);            /* default: look up in the caller's table */
  return 0;
}
```
Default lookup (`FUN_100011f0`) walks a caller-supplied table of 16-byte entries
`{…, +4:byte unitCode, +8:int allophoneTag, …}` and writes the matching entry's `+4` byte into the
unit slot, else writes `1`:
```c
undefined4 __fastcall FUN_100011f0(int *param_1,int *param_2)   /* param_1=index, param_2=table */
{
  int in_EAX; uint uVar1; int *unaff_ESI; int *piVar2;
  uVar1 = 0;
  if (param_2[1] != 0) {
    piVar2 = (int *)(*param_2 + 8);
    do {
      if (*piVar2 == *(int *)(*(int *)(*(int *)(in_EAX + 0x10) + *unaff_ESI * 4) + 4)) {
        *(undefined1 *)(*(int *)(in_EAX + 4) + 0xc + *param_1 * 0x18) =
             *(undefined1 *)(uVar1 * 0x10 + 4 + *param_2);
        *param_1 = *param_1 + 1; *unaff_ESI = *unaff_ESI + 1; return 0;
      }
      uVar1 = uVar1 + 1;
      piVar2 = piVar2 + 4;
    } while (uVar1 < (uint)param_2[1]);
  }
  *(undefined1 *)(*(int *)(in_EAX + 4) + 0xc + *param_1 * 0x18) = 1;   /* fallback code 1 */
  *param_1 = *param_1 + 1; *unaff_ESI = *unaff_ESI + 1; return 0;
}
```

`FonVidMetaFonema(a,b,index*,table*)` — archiphoneme/metaphoneme resolution, same default lookup:
```c
undefined4 FUN_100013b0(undefined4 param_1,undefined4 param_2,int *param_3,int *param_4)
{ FUN_100011f0(param_3,param_4); return 0; }
```

`FonVidAnalisi2Sintesi(uchar code) -> uchar` — pure remap of analysis codes to synthesis codes:
```c
undefined1 FUN_100013d0(undefined1 param_1)
{
  switch(param_1) {
  case 0x13: return 0x12;
  case 0x14: return 0x10;
  case 0x15: return 0x11;
  case 0x1a: return 0x19;
  case 0x1c: return 0x1b;
  case 0x1e: return 0x1d;
  case 0x24: param_1 = 0x23;
  }
  return param_1;
}
```

### 3.3 Engine-side call sites

The engine binds the module with `ELQPluginIni(...,"Jorge",...)` and stores each resolved procedure
into a fixed slot of the **voice object**:

```c
/* decomp_loqtts_jorge.txt, FUN_1002d730 (voice channel init), 32346-32390 */
  iVar4 = (*DAT_100b72d0)(*(undefined4 *)(in_EAX + 0x14));      /* ELQPluginGetFileName */
  if (iVar4 != 0) {
    uVar3 = *(undefined4 *)(*(int *)(*(int *)(in_EAX + 4) + 4) + 0xc00);
    iVar5 = FUN_1002cf20(uVar3);                               /* validate VoicePhonemeTable */
    if (iVar5 == 0) {
      piVar1 = (int *)(in_EAX + 0x1c);
      piVar2 = (int *)(in_EAX + 0x20);
      *(undefined4 *)(in_EAX + 0x18) = 0;   *piVar1 = 0;   *piVar2 = 0;
      *(undefined4 *)(in_EAX + 0x24) = 0;   *(undefined4 *)(in_EAX + 0x28) = 0;
      if (*(int *)(in_EAX + 0x14) == 0) {
        *piVar1 = (int)&LAB_1002d100;  *piVar2 = (int)&LAB_1002d100;  return 0;
      }
      iVar5 = (*DAT_100b72d8)(*(int *)(in_EAX + 0x14),"FonVidAllofonoVoce",
                              (undefined4 *)(in_EAX + 0x18));
      if (iVar5 != 0) {
        (*DAT_100b7148)(1,uVar3,"Error loading FonAllofonoVoce procedure from %s\n",iVar4);
        return iVar5;
      }
      iVar5 = (*DAT_100b72d8)(*(undefined4 *)(in_EAX + 0x14),"FonVidIngloba",
                              (undefined4 *)(in_EAX + 0x28));
      if (iVar5 == 0) {
        iVar5 = (*DAT_100b72d8)(*(undefined4 *)(in_EAX + 0x14),"FonVidAllofonoAnalisi",piVar1);
        if (iVar5 == 0) {
          if (*piVar1 == 0) { *piVar1 = (int)&LAB_1002d100; }
          iVar5 = (*DAT_100b72d8)(*(undefined4 *)(in_EAX + 0x14),"FonVidMetaFonema",piVar2);
          if (iVar5 != 0) { (*DAT_100b7148)(1,uVar3,"Error loading FonMetafonema procedure from %s\n",iVar4); return iVar5; }
          if (*piVar2 == 0) { *piVar2 = (int)&LAB_1002d100; }
          iVar5 = (*DAT_100b72d8)(*(undefined4 *)(in_EAX + 0x14),"FonVidAnalisi2Sintesi",
                                  in_EAX + 0x24);
          if (iVar5 == 0) { return 0; }
          (*DAT_100b7148)(1,uVar3,"Error loading FonAnalisi2Sintesi procedure from %s\n",iVar4);
          return iVar5;
        }
        pcVar6 = "Error loading FonAllofonoAnalisi procedure from %s\n";
      }
      else { pcVar6 = "Error loading FonIngloba procedure from %s\n"; }
```

| voice-object slot | procedure | jorge target | default if absent |
|---|---|---|---|
| `+0x14` | plugin instance (HINSTANCE) | — | — |
| `+0x18` | `FonVidAllofonoVoce` | `0x100011e0` (stub) | required (error logged) |
| `+0x1c` | `FonVidAllofonoAnalisi` | `0x10001260` | `&LAB_1002d100` |
| `+0x20` | `FonVidMetaFonema` | `0x100013b0` | `&LAB_1002d100` |
| `+0x24` | `FonVidAnalisi2Sintesi` | `0x100013d0` | required (error logged) |
| `+0x28` | `FonVidIngloba` | **absent in Jorge** | lookup tolerated |
| `+0x248` | plugin HINSTANCE used for `ELQPluginGetProc` | — | — |
| `+0x24c` / `+0x250` | `ELQVoiceChannelOpen` / `ELQVoiceChannelClose` | `0x10001070` / `0x10001100` | — |

The other call sites (verbatim):

```c
/* decomp_loqtts_jorge.txt, voice channel set-up */
8663:  iVar4 = (*DAT_100b72d8)(*(int *)(unaff_EDI + 0x248),"ELQVoiceChannelOpen",unaff_EDI + 0x24c);
8670:  iVar4 = (*DAT_100b72d8)(*(undefined4 *)(unaff_EDI + 0x248),"ELQVoiceChannelClose", …);
8679:  iVar4 = (*DAT_100b72d8)(*(undefined4 *)(unaff_EDI + 0x248),"ELQGetPhonemes",&pcStack_208);
8367:  iVar4 = (*DAT_100b72d8)(*(undefined4 *)(param_1 + 0x230),"ELQGetPhonemes",&pcStack_60c);   /* language module */
32302:  iVar4 = (*DAT_100b72d8)(*(undefined4 *)(in_EAX + 0x10),"FonAllofonoLingua", …);           /* language module */
```
```c
/* ELQGetPhonemes usage: the returned handle is stored in the phonetic modules */
  iVar4 = (*DAT_100b72d8)(*(undefined4 *)(unaff_EDI + 0x248),"ELQGetPhonemes",&pcStack_208);
  if ((iVar4 != 0) || (pcStack_208 == (code *)0x0)) {
    pcVar8 = "Unable to find phoneme table in dynamic voice library\n"; … }
  iVar4 = (*pcStack_208)(&iStack_20c);
  …
  piVar2 = *(int **)(unaff_EDI + 0x218);
  if ((piVar2 != (int *)0x0) && ((code *)*piVar2 == FUN_1002b0f0)) { piVar2[3] = iStack_20c; }
  piVar2 = *(int **)(unaff_EDI + 0x21c);
  if ((piVar2 != (int *)0x0) && ((code *)*piVar2 == FUN_10043980)) { piVar2[3] = iStack_20c; }
  piVar2 = *(int **)(unaff_EDI + 0x220);
  if ((piVar2 != (int *)0x0) && ((code *)*piVar2 == FUN_10021230)) { piVar2[5] = iStack_20c; }
```

The phoneme table returned by `ELQGetPhonemes` is validated by the engine before use — records of
16 (`0x10`) bytes with the code byte at `+4` equal to the record index:

```c
/* decomp_loqtts_jorge.txt, FUN_1002cf20 */
undefined4 __cdecl FUN_1002cf20(undefined4 param_1)
{
  uint uVar1; int *in_EAX; uint uVar2; ushort uVar3;
  if (in_EAX == (int *)0x0) return 4;
  uVar1 = in_EAX[1]; uVar3 = 0;
  if (uVar1 != 0) { uVar2 = 0;
    do {
      if (uVar3 != *(byte *)(uVar2 * 0x10 + 4 + *in_EAX)) {
        (*DAT_100b7148)(1,param_1,"Corrupted index in VoicePhonemeTable: i=%d cod=%d len=%d\n",
                        (uint)uVar3,*(undefined1 *)((uint)uVar3 * 0x10 + 4 + *in_EAX),uVar1);
        return 4; }
      uVar3 = uVar3 + 1; uVar2 = (uint)uVar3;
    } while (uVar2 < uVar1); }
  return 0;
}
```

The error strings `"Error loading FonAllofonoVoce procedure from %s"`,
`"Error loading FonAllofonoAnalisi procedure from %s"`,
`"Error loading FonAnalisi2Sintesi procedure from %s"`, `"Error loading FonIngloba procedure from %s"`
and `"Unable to find phoneme table in dynamic voice library"` show which procedures the engine
requires. The engine also probes `FonAllofonoLingua` on the *language* module
(`in_EAX+0x10`), which the Jorge voice module does not export.

## 4. Unit → frame mapping (what reaches the codec)

### 4.1 The codec plugin ABI

`LTTS7Codec210.dll` (jorge) has one export `LTTS7Codec210` at RVA 0x4760 (old build 0x4760 too,
see `decomp_codec210.txt`). Its name table is at file offset 0x22090 (VA `0x10022C90`) and contains
`ELQDecode`, `DecoderFileChanged`, `GetDecodedFileSize`, `ELQCloseDecoder`, `ELQOpenDecoder`,
`GetVersion`, plus `LoadUtilSymbols`. The engine binds it with

```c
/* decomp_loqtts_jorge.txt, FUN_10022890 */
int __cdecl FUN_10022890(undefined4 param_1)     /* param_1 = log handle; in_EAX = decoder struct */
{
  int *in_EAX; int iVar1;
  if (*in_EAX == 0) { (*DAT_100b7148)(1,param_1,"Error in accessing decoder functions\n"); return 0; }
  iVar1 = (*DAT_100b72d8)(*in_EAX,"ELQOpenDecoder",in_EAX + 3);      /* slot [3] */
  if (iVar1 != 0) { …"Error in detecting \"OpenDecoder\" function\n"… }
  iVar1 = (*DAT_100b72d8)(*in_EAX,"ELQDecode",in_EAX + 1);           /* slot [1] */
  …
  iVar1 = (*DAT_100b72d8)(*in_EAX,"ELQGetDecodedFileSize",in_EAX + 2);/* slot [2] */
    iVar1 = (*DAT_100b72d8)(*in_EAX,"ELQCloseDecoder",in_EAX + 4);    /* slot [4] */
      iVar1 = (*DAT_100b72d8)(*in_EAX,"ELQDecoderFileChanged",in_EAX + 5); /* slot [5] */
```
So the decoder object is `{ [0]=plugin handle, [1]=ELQDecode, [2]=ELQGetDecodedFileSize,
[3]=ELQOpenDecoder, [4]=ELQCloseDecoder, [5]=ELQDecoderFileChanged }` (the 7-entry ABI of CONTEXT §C,
slot 6 being the plugin's own state) and, e.g.,

```c
/* FUN_10022560 (open) and FUN_100225e0 (close) */
      iVar2 = (*(code *)piVar1[9])(&local_4,(short)unaff_ESI[0x8d], *(undefined4 *)(*(int *)unaff_ESI[6] + 0xc00));
      if (iVar2 != 0) { (*DAT_100b7148)(1,…,"Error opening decoder\n"); return iVar2; }
      unaff_ESI[0x91] = local_4;                      /* decoder handle kept in the Sig object */
      …
    if ((unaff_EDI[0x91] != 0) && ((code *)piVar1[10] != (code *)0x0)) {
      (*(code *)piVar1[10])(unaff_EDI[0x91]);         /* CloseDecoder(handle) */
    }
```

### 4.2 One voice unit → one decoder request

`FUN_1001faa0` is the per-unit synthesis driver:

```c
/* decomp_loqtts_jorge.txt, FUN_1001faa0 (param_1 = Sig/sequencer, param_2 = state, param_3 = unit) */
int __cdecl FUN_1001faa0(int *param_1,int param_2,int *param_3)
{
  …
  iVar3 = *param_1;
  if (*(int *)(iVar3 + 0x20) == 0) {
    uVar2 = (*DAT_100b7064)(param_1[0xb],2);            /* ELQBinGetSize(bin,2) */
    *(undefined4 *)(param_2 + 0x130c) = uVar2;
  }
  else {
    uVar2 = (*DAT_100b7064)(param_1[0xb],1,param_2 + 0x130c);   /* ELQBinGetSize(bin,1,out) */
    (**(code **)(iVar3 + 0x20))(uVar2);
  }
  FUN_1001f790(param_3[0x52],(char *)param_3[1]);
  FUN_1001ddd0((int)auStack_28,(int)param_3,*(uint *)(param_2 + 0x130c));   /* read unit's .bin sub-header */
  iVar3 = FUN_1001f580(param_1,(int)param_3);           /* ★ the decoder request ★ */
  if (iVar3 == 0) {
    if (((char)param_3[4] != '\x02') && ((char)param_3[4] != '\x03')) {
      FUN_1001e3a0((int)param_1,(int)param_3);          /* pitch-mark placement / PSOLA stretch */
      …
    }
    FUN_1001deb0(param_2);
    FUN_1001ea60(…, (short)param_3[0x51]);
    …
    iVar3 = FUN_1001f8e0((int)param_1);
```

and the request itself:

```c
/* decomp_loqtts_jorge.txt, FUN_1001f580 (param_1 = Sig, param_2 = unit descriptor) */
int __cdecl FUN_1001f580(int *param_1,int param_2)
{
  …
  uVar5 = ((*(ushort *)(unaff_ESI + 0x4c1) / 10) * 400) / 20000;      /* = Fs/500 samples margin */
  if ((*(int *)(param_2 + 0xc) == 2) || (*(int *)(param_2 + 0xc) == 4)) {
    uVar5 = uVar5 * 4;
  }
  unaff_ESI[0x4b8] = 0;
  local_4 = uVar5;
  if (unaff_ESI[0x4b9] == 0) { local_4 = 0; }
  if ((*(char *)(param_2 + 0x10) == '\x02') || (*(char *)(param_2 + 0x10) == '\x03')) {
    iVar6 = param_1[0x54c] - param_1[0x54b];
    iVar4 = (iVar6 + local_4 + uVar5) * 2;
    …
    iVar2 = (*DAT_100b747c)(unaff_ESI[2],iVar4);            /* ELQBufferAlloc(outBuf,n) */
    if (iVar2 == 0) {
      iVar2 = (*DAT_100b74b0)(unaff_ESI[2],0,iVar4);        /* ELQBufferFill */
      …
      goto LAB_1001f731;
    }
  }
  else {
    iVar6 = unaff_ESI[0x4ba] - unaff_ESI[0x4b9];            /* ★ unit length in samples */
    iVar4 = iVar6 + local_4 + uVar5;                        /* + pre-roll + post-roll  */
    iVar2 = (*DAT_100b747c)(unaff_ESI[2],iVar4 * 2 + 400);
    if (iVar2 == 0) {
      if (*(code **)(*param_1 + 0x1c) == (code *)0x0) {
        pcVar3 = "Error. Decoder function is missing.\n";
      }
      else {
        iVar2 = (**(code **)(*param_1 + 0x1c))              /* ★★ the decoder call ★★ */
                          (param_1[0x91],                    /* 1: ELQOpenDecoder handle      */
                           unaff_ESI[0x4b9] - local_4,       /* 2: start position (samples-pre)*/
                           iVar4,                            /* 3: sample count (incl. margins)*/
                           *(undefined4 *)unaff_ESI[2],      /* 4: out buffer (short[])        */
                           param_1[0xb]);                    /* 5: ELQBin handle of the DB     */
        if (iVar2 == 0) {
          (*DAT_100b74c0)((undefined4 *)unaff_ESI[2],*(undefined4 *)unaff_ESI[2],iVar4 * 2, iVar4 * 2);
          *(bool *)(unaff_ESI + 400) = *(char *)(param_2 + 0x150) == '0';
          goto LAB_1001f731;
        }
        param_1[0x91] = 0;
        pcVar3 = "Error decoding signal.\n";
      }
      (*DAT_100b7148)(1,*(undefined4 *)(*(int *)param_1[6] + 0xc00),pcVar3);
      iVar2 = 4;
    }
  }
  return iVar2;
}
```

**Conclusion:** the decoder receives **(handle, start-in-samples, count-in-samples, short* out,
ELQBin handle of the .bin)**. Neither a frame index nor a byte offset crosses this boundary. The
samples→frame→byte conversion happens **inside the codec**, quoted in §4.5 below; also:
`ELQGetDecodedFileSize` always returns `-1` ("unknown"), and `ELQBinGetSize(bin,which)` is a
**divisor** (`which=1` → byte size, `which=2` → size/2 = 16-bit sample count) — which is why
`FUN_1001faa0` calls `ELQBinGetSize(param_1[0xb],2)` when it wants a sample count for the output
buffer. Engine-side `ELQBin*` access exists only for non-codec containers (e.g. WAV:
`FUN_10018150` does `ELQBinGetSize(url,1)` + `ELQBinGetBuffer(url,0,min(size,0x400),1,0,&out)` and
parses `RIFF/WAVE`).

### 4.3 Position scaling — SDE positions are 10 µs units

`FUN_1001e3a0` converts the unit's start/end (fields at `param_1+0x155c` / `param_1+0x1564`) into
samples, and places the pitch marks:

```c
/* decomp_loqtts_jorge.txt, FUN_1001e3a0 (head) */
  uVar14 = *(uint *)(param_1 + 0x155c);              /* unit start */
  uVar16 = *(uint *)(param_1 + 0x1564);              /* unit end   */
  if (uVar16 == uVar14) { return; }
  uVar1 = *(ushort *)(param_1 + 0x234);              /* sample rate, e.g. 32000 */
  uVar13 = (uint)uVar1;
  uVar18 = ((uVar14 % 100000) * (uVar13 / 10)) / 10000;
  iVar4 = (uVar14 / 100000) * uVar13 + uVar18;       /* start sample = pos * Fs / 100000 */
  uVar18 = ((uVar16 / 100000 - uVar14 / 100000) * uVar13 +
           ((uVar16 % 100000) * (uVar13 / 10)) / 10000) - uVar18;   /* length in samples */
  iVar11 = **(int **)(param_1 + 0x250) + *(int *)(param_1 + 0x25c) * 2;   /* pitch-mark source (short*) */
  if (*(char *)(param_2 + 0x150) != '0') {
    if (*(char *)(param_2 + 0x150) == 'u') {
      uVar14 = uVar1 / 0x7d;                          /* Fs/125 → target pitch period */
      uVar16 = uVar18 / uVar14;
      *(int *)(param_1 + 0x1128) = iVar4;
      local_5c = 1;
      … place pitch marks: *(int *)(param_1 + 0x1128 + local_5c*4) = iVar4 …
    }
    goto LAB_1001ea01;
  }
  if (*(uint *)(param_2 + 0x140) == 0) {
     … pitch-mark picker over the waveform (peak search, window 0x32..0xc6 samples …
  } else {
    local_48 = (uint)uVar1 / *(uint *)(param_2 + 0x140);    /* Fs / pitch-ratio */
  }
```

i.e. **`sample = pos × Fs / 100000`**, i.e. **1 position unit = 100000⁻¹ s = 10 µs** (a 20 ms frame
= 2000 units = 640 samples @ 32 kHz). The pitch-mark array (`param_1+0x1128`, one dword per mark,
count `local_5c`) is then filled by TD-PSOLA-style period selection: either from the recorded
pitch-mark waveform (`param_2+0x150 == '0'`, peak search in the window `0x32…0xc6` samples from
`param_2+0x140 == 0`) or at a target period `Fs / (param_2+0x140)` (pitch scaling), and with
`param_2+0x150 == 'u'` (uniform/voiced) at `Fs/125`. This is where **pitch and duration
stretching** happen (the decoded signal is never resampled; marks are re-spaced and the segments
re-overlapped-add); `param_2+0x150/'u'`, `param_2+0x140` and `param_2+0x10c` (coding) are the prosody
inputs.

### 4.4 Worked example (real unit: `Aa` of the paralinguistics DB)

`.sde` → descriptor. `JorgeGildedParalinguistics.sde` (bit-7-cleared) begins:

```
P=Aa|0|61846
P=Aa_01|61846|150218
P=Aa_02|150218|258078
…
P=Yawn_04|19325121|19915859
```

For `P=Aa|0|61846` the engine holds start = `0`, end = `61846` (10 µs units) in
`param_1+0x155c` / `param_1+0x1564` and the unit's name `Aa` (the `param_2+0x118` string copied in
`FUN_1001f580`/`FUN_1001f8e0`). The paralinguistics DB
`JorgeGildedParalinguistics.32000.LTTS7Codec210.44000.10.bin` is 1095572 B = header 164 + 28 +
9958 × 110 B, i.e. 640 samples/frame @ 32000 Hz, 110 B/frame.

`FUN_1001e3a0` computes (Fs = 32000):

* start sample = `0 / 100000 * 32000 + (0 % 100000) * 3200 / 10000` = **0**
* length      = `(61846/100000)*32000 + (61846 % 100000)*(3200)/10000` − 0 = `197907200/10000` = **19790 samples**
  (= 0.6183 s ✓ vs 61846 × 10 µs)

`FUN_1001f580` then calls the decoder with (margin `local_4`; `unaff_ESI[0x4b9] == 0` ⇒ margin 0,
post-roll `uVar5 = Fs/500 = 64`):

| argument | value | unit |
|---|---|---|
| 1 decoder handle | from `ELQOpenDecoder` | — |
| 2 offset | `0 − 0` = **0** | samples (into the decoded stream of the DB) |
| 3 count | `19790 + 0 + 64` = **19854** | samples |
| 4 out buffer | `ELQBufferAlloc(out, 19854*2 + 400)` = 40108 B | int16 PCM |
| 5 DB handle | `param_1[0xb]` = ELQBin handle registered by `ELQBinaryHeaderLoadInfo` (header `Label` = `JorgeGildedParalinguistics`, `Freq`=32000, `Coding`=LTTS7Codec210, `BitRate`=44000, `Rank`=10) | — |

**Which SDE fields are read for this unit:** the record is the `P=` line, whose three fields are
`name | start | end`; the *positions* are the only numeric fields, they are 10 µs units, and they are
consumed as `param_1+0x155c` (start) / `param_1+0x1564` (end) by `FUN_1001e3a0` and as the sample
cursor `unaff_ESI[0x4b9]`/`[0x4ba]` by `FUN_1001f580`. The `name` (`Aa`) is the phrase key that the
`.gde` maps from the speech-act/paralinguistic text and it is carried in the unit descriptor as the
string at `param_2+0x118` (`FUN_1001f8e0`: `pcVar3 = (char *)(in_EAX + 0x118); … copy into
unaff_ESI+0x628-relative buffer`).
*[INFERENCE]*: the `.sde` **record parser itself** (which reads the bit-7-set text and fills
`+0x155c`/`+0x1564`) is not present in the engine dump under any of the names used here; the
identification of the `P=name|start|end` fields with those two slots rests on (a) the field set being
the only numeric content of the record, (b) the range check `max(end) = 19915859 ≤ 9958 × 2000 =
19916000 = frames × 2 ms`, and (c) the exact `pos × Fs / 100000` conversion in `FUN_1001e3a0`. The
byte-level `.sde` encoding is `SdeFormat`'s remit.

The codec converts `sample 0 → frame 0` and `19854 samples → 19854/640 = 31.02 → 32 frames` using
the 28-byte BE sub-header of the `.bin` (`[BitRate=44000, Rank=10, samples_per_frame=640,
Freq=32000, bytes_per_frame=110, frame_count=9958, cookie]`) and fetches the compressed bytes itself
with `ELQBinGetBuffer(bin, 110·i + 28 + 122, 110, 1, 0, &eof)` = file offset `164 + 110·i`
(§4.5), un-XORing each frame with the cookie LSB `0x91` before bit-unpacking. If instead the unit
were taken from the main DB (`Jorge.sde`, Fs = 32000, 264948 frames, 110 B/frame, frame *i* at
150 + i·110, frame XOR key `d[27] = 0x6D`), a start of e.g. 2000 units would give offset
`2000*32000/100000 = 640` samples = frame 1, and a length of 2000 units → 704 samples incl. the
64-sample post-roll.

### 4.5 Inside the codec: the exact byte request, and per-frame obfuscation

`LTTS7Codec210.dll` (jorge) exports one symbol `LTTS7Codec210` @ RVA **0x4760** (VA `0x10004760`),
an 8-entry dispatcher over `{name; handler}` pairs at VA `0x1002e028`:

| # | name | handler VA | role |
|---|---|---|---|
| 0 | `LoadUtilSymbols` | `0x10004130` | `GetProcAddress(utilLib,…)` for 5 names into slots at `0x1002f624…` |
| 1 | `GetVersion` | `0x100041f0` | writes `"7.14.0"` (6 bytes) — verified constant `0x372e31342e30` at `0x10022db8` |
| 2 | `ELQOpenDecoder` | `0x100045e0` | allocate + sample-rate tables |
| 3 | `ELQCloseDecoder` | `0x10004730` | free |
| 4 | `ELQGetDecodedFileSize` | `0x10004220` | `*out = 0xffffffff` (−1 "unknown") |
| 5 | `ELQGetDecoderDescription` | `0x100041c0` | returns `"Loq210"` |
| 6 | `ELQDecoderFileChanged` | `0x100041d0` | `*(u8*)(dec+0x11e5)=0; *(u32*)(dec+0x4c)=arg` → resets the header state and sets the payload offset |
| 7 | `ELQDecode` | `0x10004530` | decode N samples |

The five Util names the codec itself resolves (`LoadUtilSymbols`) are
`ELQBinGetBuffer → DAT_1002f624`, `ELQLogWrite → DAT_1002f628`, `ELQfree → DAT_1002f62c`,
`ELQmalloc → DAT_1002f630`, `ELQstricmp → DAT_1002f634` — i.e. **the codec's only file access is
`ELQBinGetBuffer`**.

`ELQOpenDecoder(out, sampleRate, log)` (`codec_handlers.txt`, verbatim):

```c
undefined4 FUN_100045e0(undefined4 *param_1,int param_2,int param_3)
{
  int *_Dst; …
  _Dst = (int *)(*DAT_1002f630)(0x11e8);                 /* ELQmalloc(0x11e8) */
  *param_1 = _Dst;
  if (_Dst == (int *)0x0) { return 5; }
  _memset(_Dst,0,0x11e8);
  … param_2 == 8000:  *(u16*)((int)_Dst+0x11d2) = 0xa0;  _Dst[0xd] = 0x6e;  _Dst[0xe] = 3;  …
  … param_2 == 16000: *(u16*)((int)_Dst+0x11d2) = 0x140; _Dst[0xd] = 0xe0;  _Dst[0xe] = 3;  …
  … param_2 != 32000: (*DAT_1002f628)(1,param_3,"Unable to create LoqCodec210 decoder (SampleRate not supported)\n");
                      (*DAT_1002f62c)(_Dst); return 4;
  *(undefined2 *)((int)_Dst + 0x11d2) = 0x280;           /* 640 samples/frame @32 kHz */
  _Dst[0xd] = 0x1fd;                                     /* 509 = lead-in samples (+0x34) */
  _Dst[0xe] = 6;                                         /* +0x38 = re-prime depth          */
  _Dst[9] = (int)&PTR_PTR_10023b2c;                      /* model table                     */
  …
  _Dst[0xc] = param_2;                                   /* +0x30 sample rate  */
  _Dst[0xb] = param_3;                                   /* +0x2c log handle   */
  _Dst[0x477] = -2; _Dst[0x478] = -2;                    /* +0x11dc/+0x11e0 cursors */
  FUN_100012e0(_Dst);                                    /* bit-reader buffer */
  return 0;
}
```

`ELQDecode(decoder, samplePos, nSamples, dstInt16, bin)` (`codec_handlers.txt`, verbatim):

```c
undefined4 __thiscall
FUN_10004530(uint3 param_1,int param_2,uint param_3,uint param_4,int param_5,int param_6)
{                                       /* param_2=decoder, param_3=samplePos, param_4=nSamples,
                                           param_5=dst buffer, param_6=bin handle */
  …
  if (param_2 == 0) return 4;
  if (param_4 == 0) return 0;
  if (param_5 == 0) return 4;
  if (param_6 == 0) return 4;
  if (*(char *)(param_2 + 0x11e5) == '\0') {            /* first call: parse sub-header */
    iVar2 = (*DAT_1002f624)(param_6,*(undefined4 *)(param_2 + 0x4c),0x1c,1,0,(int)&uStack_4 + 3);
    *(short *)(param_2 + 0x11d0) = (short)*(char *)(iVar2 + 0x13);   /* sub-header byte 19 → 110 B/frame */
    *(undefined1 *)(param_2 + 0x11e4) = *(undefined1 *)(iVar2 + 0x1b);/* sub-header byte 27 → frame XOR key */
    *(undefined1 *)(param_2 + 0x11e5) = 1;
  }
  iVar2 = *(int *)(param_2 + 0x34);                     /* lead-in: 509 @32 kHz */
  param_3 = param_3 + iVar2;                            /* samplePos += lead-in */
  do {
    uVar3 = FUN_10004340((uint3)iVar2,&param_5,&param_3,uVar3,iVar1);
    iVar2 = extraout_ECX;
  } while (uVar3 != 0);
  return 0;
}
```

i.e. `ELQBinGetBuffer(bin, 0x4c-field, 0x1c, 1, 0, &subHeader)` fetches the 28-byte BE sub-header,
whose **byte 19** gives `bytes_per_frame` (110) and **byte 27** the per-frame XOR key. Then the
per-frame reader (`codec210_new.txt`, jorge VA `0x10004340`, verbatim):

```c
uint __thiscall FUN_10004340(uint3 param_1,int *param_2,uint *param_3,uint param_4,undefined4 param_5)
{
  int in_EAX; uint uVar1,uVar2,uVar3; int iVar4; void *_Dst,*_Src; undefined4 uStack_4;
  uVar2 = (uint)*(short *)(in_EAX + 0x11d2);            /* samples/frame = 640 */
  uVar3 = *param_3;                                     /* samplePos */
  uVar1 = uVar3 / uVar2;                                /* ★ frameIndex = samplePos / 640 */
  …
      iVar4 = (*DAT_1002f624)(param_5,(int)*(short *)(in_EAX + 0x11d0) * uVar1 + 0x1c +
                                      *(int *)(in_EAX + 0x4c),(int)*(short *)(in_EAX + 0x11d0),1,0,
                              (int)&uStack_4 + 3);      /* ★ ELQBinGetBuffer(bin, off, 110, 1, 0, &eof) */
      if (uStack_4._3_1_ == '\x01') {                   /* eof flag → silence */
        _memset(*(void **)(in_EAX + 0x11d4),0,*(short *)(in_EAX + 0x11d2) * 2);
        *(uint *)(in_EAX + 0x11dc) = uVar1; return param_4; }
      if (iVar4 != 0) { FUN_10004290(); }               /* ★ un-XOR + bit-unpack + model decode */
      *(uint *)(in_EAX + 0x11dc) = uVar1;
      return param_4;
```
so the exact request is

```
byteOffset = bytes_per_frame(110) * frameIndex + 28 + *(u32*)(decoder+0x4c)
byteLength = bytes_per_frame(110), elemSize = 1
```
with `frameIndex = samplePos / 640` and `*(decoder+0x4c) = 122` (payload offset, set by
`ELQDecoderFileChanged`) ⇒ `byteOffset = 150 + 110·frameIndex`, matching the container layout
(`110·264948 + 28 + 122 = 29144430` = file size). Cache: the decoder keeps the current frame and the
previous one (`+0x11d4` / `+0x11d8`, 640 int16 each) and only re-reads when `frameIndex` changes;
a random seek re-primes from `frameIndex - 6` (`*(decoder+0x38) = 6`, the `_Dst[0xe]` above).

**Per-frame obfuscation (verified, contradicts the "data region is not obfuscated" premise).**
`FUN_10004290` XORs every byte of the fetched frame with the key read from sub-header byte 27 before
the bit-unpacker/model run; for the three shipped Jorge DBs the keys are 0x6d / 0x15 / 0x91 and

| file | header key `d[0]^d[1]` | header size | frame byte-0 raw set | after `^key` |
|---|---|---|---|---|
| `Jorge.32000.LTTS7Codec210.44000.10.bin` | 0x02 | 122 | `{0x50…0x57}` | `{0x38…0x3F}` |
| `JorgeGildedPhrases.…bin` | 0x7c | 148 | `{0x28…0x2F}` | `{0x38…0x3F}` |
| `JorgeGildedParalinguistics.…bin` | 0xe2 | 164 | `{0xA8…0xAF}` | `{0x38…0x3F}` |

All three normalise to the *same* tag set `0x38…0x3F` only after XOR with their own cookie LSB, so
the payload is byte-XORed per frame with that key; treating the payload as plaintext yields noise.

### 4.6 `ELQBin*` semantics (Util, jorge)

```c
/* ELQBinGetSize @ 0x10003b00 — 2nd arg is a DIVISOR */
uint ELQBinGetSize(int *bin, uint which) {
  if (bin == 0 || (code *)bin[0] != ELQBinOpen) return 0;
  if (which != 0 && (t=BYTE(bin+9), t=='d'||t=='m'||t=='r') && bin[3] != 0)
      return *(uint *)bin[3] / which;          /* which=1 → bytes, which=2 → 16-bit samples */
  return 0; }
/* ELQBinGetRawData @ 0x10003110 — zero-copy base pointer; 0 for access type 'd' */
int ELQBinGetRawData(int *bin) {
  if (bin && (code*)bin[0]==ELQBinOpen && *(char*)((int)bin+9) != 'd') return bin[1];
  return 0; }
/* ELQBinSeek @ 0x10003fc0 — shifts the window by delta*elemSize */
/* ELQBinGetBuffer @ 0x10003f90 → FUN_10003ba0: byteOffset = offset*elemSize, byteLen = count*elemSize;
   every path memcpy()s/fread()s into a heap buffer and returns that pointer (never a pointer into the
   mapping); minimum internal capacity 0x2800 bytes. */
```
Access types: `'d'` = lazy disk cache (`FILE*` + `fseek/fread`), `'m'` = memory-mapped file,
`'r'` = whole file read into RAM, `'s'` = shell. `ELQBinInitSmartBuffer` = `malloc(8)` giving
`{void *data; uint capacity;}`; `ELQBinGetSmartBufferCore` returns `*data`; `ELQBinResizeSmartBuffer`
grows it; the "smart buffer" is **not** offset-keyed — it is just the caller-owned destination
buffer, so the caller (the codec) does the frame caching itself. The engine opens the voice DB with
`ELQBinOpen(&bin, 'd'=100, log, filename)` (`FUN_1001e0e0`) and only ever calls `ELQBinSeek` once,
with `delta = 0`.

## 5. Verification status / open points

* Verified against the jorge DLLs: the dispatch table and all eight procedure bodies (§3,
  `jorge_re/decomp_jorge_funcs.txt` was produced by `tools/EngineBindDumpFuncs.java`, which creates
  the functions Ghidra had missed; the dispatcher/`FUN_10001000/40/1100/11f0` bodies are also in
  `jorge_re/decomp_jorge_voice.txt`), `FUN_10044450`/`FUN_10043f50`/`FUN_10044040`/`FUN_100444d0`/
  `FUN_10043cb0`, `FUN_10052380`, `FUN_10052340`, `ELQBinaryHeaderLoadInfo`, the constants of §1.2,
  and the whole §4.1–4.6 code (the codec handler bodies are quoted from
  `codec_handlers.txt`/`codec210_new.txt`, produced by the codec-side disassembly).
* Cross-check: the older sibling module `LTTS7Ludoviko.dll` (`decomp_ludoviko.txt`) exports a 4-entry
  dispatcher and its `FUN_10001150` copies `"LTTSComponentVersion=7.4.0"` — the same
  `LTTSComponentVersion=` scheme, at a different version, confirming the chain.
* `DataPath`'s exact use in `FUN_100444d0` is not visible in the decompilation (see §1.6 note).
* `FUN_1001e0e0` (Sig "set database") resolves and `ELQBinOpen`s the chosen `.bin` per type 1/2/3
  (`ELQBinOpen(&handle,100,log,path)` then a virtual call `(**(code**)(*self+0x2c))(decoder,0,path)`)
  and `FUN_1001e3a0`/`FUN_1001f580` write/fill the arrays consumed above; the Sig object layout
  beyond the offsets named here (0x91 decoder handle, 0xb bin handle, 0x2c/0x1c vtable slots,
  0x4b9/0x4ba sample cursors, 0x1128 pitch marks, 0x155c/0x1564 SDE positions, 0x234 sample rate,
  0x4c1 sample rate copy) is not fully reconstructed.
* The `.sde` byte-level record parser is not identifiable in the engine dump by name (see §4.4);
  the `.bin` TLV→`ELQDataDescriptor` mapping inside `FUN_10002550`/`FUN_10005100` (ReadHeader) is in
  `ELQBinContainer`'s remit.
* Who sets `*(decoder+0x4c)` (the `.bin` payload offset = 122) is not proven: it is set only by
  `ELQDecoderFileChanged` (codec handler #6), whose engine-side call site is not visible in the
  dump; the resulting reads nevertheless match the container (`150 + 110·i`) exactly, and
  `FUN_1001e0e0` hands the just-opened bin's `ELQBinaryHeaderIsPresent` value to the decoder drive
  slot `+0x2c`, which is the most likely source.


---

# APPENDIX: specs/SpanishLanguage.md

# Spanish language data layer (Loquendo TTS 7, voice "Jorge")

Source tree: `jorge/pf/Loquendo/LTTS7/data/` (`Jorge.vcf`, `SpanishEs.lcf`, `languages/Spanish/*`)
plus `jorge/pf/Loquendo/LTTS7/bin/LTTS7Spanish.dll`. Language module descriptor
`languages/Spanish/SpanishEs.lde`:

```
; LTTSComponentVersion=7.3.0
"BaseDescription" = "Castilian Spanish generic descriptor file"
"Library"         = "LTTS7Spanish, Spanish"
"Language"        = "SpanishEs,es-ES,ES,Castilian,es,Spanish"
"WinLangid"       = "1034"
"LexicalDB"       = "SpanishEs.dbl"
"DefaultVariant"  = "yes"
;"RegExp"         = "Spanish.rex"          <- commented out: no regex rules shipped for es
"Lexicon"         = "Spanish.lex"
"sayas[address]"  = "AddressSpanishEs"
```
`SpanishEs.lcf` (language configurator): `BaseLanguage=SpanishEs`, `LanguagePath=languages/Spanish`,
`Built-in=Yes`. The `.lde` `Library` value is exactly how the engine builds the plugin name:
`ELQPluginIni(..., "LTTS7Spanish", ...)` then resolves `Les*`/`Fon*`/`ELQ*` procedures by name.

## Files and roles (observed in the Jorge package)

| file | size | role |
|---|---|---|
| `SpanishEs.lde` | 395 B | language descriptor (plain text, keys above) |
| `SpanishEs.dbl` | 261 120 B | **lexicon database: SQLite**, table `lessico` |
| `Spanish.lex` | 4 361 B | compiled binary lexicon (see below) |
| `Spanish Automotive.lex`, `American Spanish Automotive*.lex`, `SISpanish.lex` | 2–17 KB | style/domain lexicons referenced as `"lexicon[i]"` by `.ycf` style files |
| `SpanishEs.lcf` | – | language configurator (plain text) |
| `AddressSpanishEs.ycf` etc. | – | **say-as/style configurator (plain text)**, e.g. `"lexicon[0]" = "languages/Spanish/Spanish Automotive.lex"` |
| `SpanishAm/Ar/Cl/Mx.dbl` + `.lde` | 261 120 B each | the 5 Spanish variants (Am/Ar/Cl/Mx/Es) |
| `languages/*/…gpr`, `*.rex` | – | rule/regex data for other languages (Spanish ships none; G2P is lexicon+compiled rules) |

## Lexicon database (`SpanishEs.dbl`)

SQLite, one table (Italian column names, latin-1 text):
`lessico(grafemica, fonetica, grammaticale, specgramm, gennum, tempomodo, abbreviazione, gradoaccentuale)`

* 5 381 rows; 1 690 with a non-NULL `fonetica` (the DB holds irregular/foreign/number forms;
  regular words are produced by the compiled rules in `Spanish.lex`).
* `grammaticale` values with counts: `SOST` 1372, `VERBO` 1323, `AGG` 429, `AVV` 174, `PRON` 62,
  `VERBOE` 52, `VERBOA` 50, `PREPS` 26, `CONG` 22, `OMOGRAFO` 8, `PRONR` 8, `PRONPC` 7,
  `ARTPRON` 4, `ARTIC` 4, `PREPA` 2, `NONVERBO` 1, `PRONCLI` 1 (empty 1836).
* sample rows (`grafemica` -> `fonetica`):
  `abiogenesia -> a BH i o x e n `e s j a`, `adagio -> a DH `a Y j o`,
  `advanced -> a DH BH `a n s e DH`, `aeromexico -> a e hr o m `e x i k o`,
  `interregional -> i N tt e hr r: e x j o n `a l`, `telefonicaonline -> tt e l e f `o n i k a o n l `a i n`

### Phoneme inventory actually used (35 symbols; from `fonetica`)

Most frequent tokens: `s` 830, `i` 784, `e` 693, `hr` 659, `a` 555, `` `e `` 549, `tt` 545,
`n` 538, `l` 509, `k` 502, `` `a `` 430, `m` 403, `o` 359, `` `i `` 295, `` `o `` 281, `p` 275,
`b` 244, `u` 221, `f` 189, `` `u `` 169, `x` 157, `BH` 147, `DH` 144, `w` 132, `dd` 116.

Symbol list (as printed by `LTTS7Spanish.dll` at file offset 0x26918, preceded by example words
`mancha, noche, kama, pizza, Genova, chocolate, show, desde, consejo, yemas, caballo, llegada,
guerra, escudo, toldo, amaba, bueno, isla, hasta, giro, caja, loco, tarde, capa, cuatro, rabia,
comprar, retorica, denos, Educador`):

```
HRB Dg uw r: hr GL Gl GN Gn N M Y Hh Th Zg T$ Ts J dd tt DH GH Hr BH `u `o `i `e `a @ # ^
```
Interpretation (SAMPA-like, Loquendo dialect): `a e i o u` vowels; `` `x `` = stressed vowel;
`$` secondary stress; `:` lengthening (`r:`); `hr` trill, `r` tap; `tt`/`dd` = voiceless/voiced
alveolar stops (Spanish /t/, /d/); `BH`/`DH`/`GH` = spirantised allophones of b/d/g;
`Hh`/`Th`/`Ts`/`Zg`/`Dg`/`HRB`/`GL`/`Gl`/`GN`/`Gn` = context variants; `N` = [ŋ], `J` = [ɲ],
`L` = [ʎ], `Y` = [ʝ], `x` = [x], `M`, `T$`, `w`, `j` glides; `@ # ^` = internal markers.

## Compiled lexicon `.lex` (open item)

All `.lex` files share the header
`ca fe db 60 df e3 dc a4 c9 a5 85 f3 96 e4 97 fe` and are **not** text under bit-7 clearing nor
under XOR with `d[0]^d[1]` (= 0x34). They are therefore a compiled rule/lexicon program
(consistent with `Lessico`/rule-based G2P); reversing them is a separate pass. `AddressSpanishEs.ycf`
shows how styles select them (`lexicon[0]`, `lexicon[1]`, …).

## The voice's phonetic table (`LTTS7Jorge.dll`)

The voice module embeds its own phoneme table (the one the engine asks for as resource
`TabelleFonetiche`). In `jorge/…/bin/LTTS7Jorge.dll` at file offset ~0x82c0..0x8450 it appears as a list
of **example words** followed by **symbols**, in the voice's own order:

```
examples: ayuda llegada guerra escudo toldo amaba bueno caja loco tarde capa causa rey capitulo cura
          soldado coche retorica silla denos pesca llamar caro
symbols : r:  hr  GL Gl l GN Gn N M n m Y Th x Zg $ vs s f T$ Ts J HG g Hdd dd HB b k tt p
          HGH HBH HDH DH GH BH j w u `u o `o i `i e `e a `a @ # ^
```

* This is exactly the symbol set seen in the lexicon's `fonetica` column (base vowels/consonants,
  `hr`/`r:`/`r` rhotics, `BH`/`DH`/`GH` spirantised allophones, `Hdd`/`dd`/`tt` stops, `GL/Gl GN/Gn`
  palatals, `N`, `J`, `L`, `Y`, `x`, `Th`, `Zg`, `T$`, `Ts`, `$`, `vs`), so the `.sde` `U=` tokens and
  the lexicon transcriptions share one alphabet.
* `#`, `@`, `^` are internal markers (silence / boundary) - the first atoms of `Jorge.sde` are
  `U=# # @ @`, i.e. marker context + markers.
* Example words give the pronunciation intent of each symbol (e.g. `LL`-like `Gl`/`GL` from *llegada/
  llamar*, `J` from *caja*?, `Y` from *rey/ayuda*), which is enough to map the alphabet onto IPA for a
  reimplementation (mapping still `[INFERENCE]` where ambiguous).
* `LTTS7Spanish.dll` carries a *similar* table (examples + symbols) for the language layer; the engine's
  reader converts `U=` tokens through the voice table by exact string match (see `specs/SDE.md` S3).

## Say-as / style layer

The `.ycf` files are tiny plain-text *Style Configurator Files* that only name the compiled lexicons used
by a style, e.g. `AddressSpanishEs.ycf`:

```
; Style Configurator File for Loquendo TTS
"lexicon[0]" = "languages/Spanish/Spanish Automotive.lex"
```
(`SMSItalian.ycf` -> `languages/Italian/SMSItalian.lex`, etc.). So the say-as behaviours of the
Director's *Say As* menu (address, SMS, currency, ...) are implemented by **compiled `.lex` binaries**,
not by readable rules: `AddressSpanishEs` uses `Spanish Automotive.lex`; the language default uses
`Spanish.lex` (`.lde` key `Lexicon`). A binary-free reimplementation must re-create these say-as
grammars itself (a generic implementation is a valid substitute, as the interface is
`ttsReadString` with a `sayas`/style parameter).

## Reimplementation notes

* A binary-free Spanish front end needs: the `.dbl` lexicon (drop-in: SQLite, latin-1), a rule G2P
  for regular words equivalent to `Spanish.lex`, and this phoneme alphabet as its output symbols.
* The engine resolves the language procedures through the module dispatcher
  (`ELQPluginGetProc("LesGetSymbolName"|"ELQGetGraphemes"|"ELQGetPhonemes"|"FonTrasParola"|…, …)`);
  `LesGetSymbolName` is the symbol-id -> name map for exactly the alphabet above.


---

# APPENDIX: specs/CONTEXT.md

# Shared context: Loquendo TTS 7 voice "Jorge" — DB/inventory formats

Working dir: `/home/user/Downloads/ltts_re` (use it as cwd; all relative paths below).

## Deliverable goal
Reverse-engineer the **vocal database (.bin)** and **unit inventory (.sde)** formats of Loquendo TTS 7
so another agent can reimplement the synthesizer binary-free and reproduce the *same voice* from the
shipped data files. Each sub-task writes its own spec under `specs/` and its own tools under `tools/`.
**Never edit `REPORT.md`** (the parent owns it). Do not run builds/lint/tests mid-flight.

## Authoritative inputs (the voice package, extracted with innoextract)
`jorge/pf/Loquendo/LTTS7/`
- `bin/LoqTTS7.dll` (746 KiB engine) — NEWER build than `engine_re/LoqTTS7.dll`.
- `bin/LTTS7Util.dll` (551 KiB) — NEWER than `engine_re/LTTS7Util.dll` (266 KiB).
- `bin/LTTS7Codec210.dll`, `bin/LTTS7CodecMsx.dll`, `bin/LTTS7Jorge.dll` (voice module), `bin/LTTS7DB.dll`,
  `bin/LTTS7GPR.dll`, `bin/LTTS7SAPI5.dll`, `bin/TTSDiag.exe`
- `data/Jorge.vcf`, `data/voices/Jorge/Jorge.vde`, `JorgeGilded.gde`,
  `Jorge.sde` (1 511 129 B), `Jorge.32000.LTTS7Codec210.44000.10.bin` (29 144 430 B),
  `JorgeGildedPhrases.sde/.bin`, `JorgeGildedParalinguistics.sde/.bin`

Existing Ghidra dumps (from the OLDER `engine_re/` build — good as a fast index, but **verify against the
jorge DLLs**): `decomp_util.txt`, `decomp_loqtts.txt`, `decomp_codec210.txt`, `decomp_codecmsx.txt`,
`decomp_db.txt`, `decomp_ludoviko.txt`, `decomp_director.txt`.

Ghidra headless (test it first; ~minutes per DLL):
```
/opt/ghidra/support/analyzeHeadless /tmp/ghproj_<tag> proj -import jorge/pf/Loquendo/LTTS7/bin/LTTS7Util.dll \
  -postScript DumpAll.java /home/user/Downloads/ltts_re/jorge_re/decomp_util_jorge.txt \
  -scriptPath /home/user/Downloads/ltts_re/ghidra_scripts
```
(`ghidra_scripts/DumpAll.java` decompiles all functions; pass the output path as script arg.)

## Already-established facts (do NOT re-derive; build on them)

### A. `.bin` container = `LOQUENDOTTS7` binary header (from `LTTS7Util.dll`, `decomp_util.txt`)
- `ELQBin*` API in Util: `ELQBinOpen`, `ELQBinOpenNoCache`, `ELQBinClose`, `ELQBinGetSize`, `ELQBinSeek`,
  `ELQBinGetBuffer`, `ELQBinGetRawData`, `ELQBinInitSmartBuffer`, `ELQBinGetSmartBuffer(Core)`,
  `ELQBinResizeSmartBuffer`, `ELQBinClone(Ex)`, `ELQBinVirtualOpen`, `ELQBinGetFilename/Type/Exclusive/LogHandle`,
  plus `ELQBinaryHeaderIsPresent/LoadInfo/UnLoadInfo/CheckCondition/CheckMultipleConditions/GetValue/CopyInMemory`.
- Access types: memory-mapped file ("MMF") and DiskCache (`ELQBinClone: bin access type <%c> unknown`).
- Recovered `ReadHeader` logic (`FUN_10004de0` + `FUN_10004ec0` in `decomp_util.txt`):
  * 18-byte fixed prefix read at offset 0 (`ELQBinGetBuffer(bin,0,0x12,1,…)`):
    `u8 [0]`, `u8 keyish [1]`, then 12 bytes = signature XORed → `"LOQUENDOTTS7"` (strncmp 12), then
    `u16 format_version` (== 1), `u16 header_size`.
  * De-obfuscation: `FUN_10004ca0(len, byteKey, ptr)` = `for i<len: ptr[i] ^= unaff_BL ^ byteKey` —
    i.e. effective key = (BL register at entry, a global/constant the caller loads) XOR byteKey.
    Empirically, on the real file, XOR **0x02** turns the header text/values into coherent form:
    offline decode of `Jorge.…bin` with `b ^ 0x02` yields
    `29 2b 4c 4f 51 55 45 4e 44 4f 54 54 53 37 01 00 7a 00 02 00 06 00 "Jorge\0" …`
    i.e. `format_version=1`, `header_size=0x7A=122`.
  * After the 18-byte prefix (from offset 0x12) comes a **TLV list until header_size**:
    `u16 tag, u16 size, u8 data[size]` (little-endian u16s), tags (verified against the contiguous .rdata
    string table `Name/Label/Comment/Freq/Coding/BitRate/Rank/Version`):
    `1=Name, 2=Label, 3=Comment, 4=Freq, 5=Coding, 6=BitRate, 7=Rank, 8=Version`.
    Observed on the real file: `2=Label:"Jorge"`, `3=Comment:"Acoustic file Jorge of voice Jorge"`,
    `4=Freq:"32000"`, `5=Coding:"LTTS7Codec210"`, `6=BitRate:"44000"`, `7=Rank:"10"`, `8=Version:"7.1.0"`.
    The DB filename mirrors these: `<Label>.<Freq>.<Coding>.<BitRate>.<Rank>.bin`.
  * Data region begins at `header_size` (122). Its first bytes (raw) are
    `00 00 ab e0 00 00 00 0a 00 00 02 80 00 00 7d 00 00 00 00 6e 00 04 0a f4 …` = 7 big-endian u32
    [BitRate, Rank, samples_per_frame(640), Freq, bytes_per_frame(110), nframes, cookie]; the
    sub-header is stored plain (not obfuscated) and `header_size + 28 + nframes*bpf == filesize`.
    RESOLVED: the FRAMES that follow ARE obfuscated - each 110-byte frame is byte-XORed with the
    single key = sub-header byte 27 (last byte of the cookie); verified by EngineBind and re-verified
    independently: three files with keys 0x6D/0x15/0x91 all normalise frame[0] to {0x38..0x3F}.
- `ELQBinaryHeaderGetValue` / `LoadInfo` read these fields into an `ELQDataDescriptor` (Util).

### B. `.sde` = unit inventory (descriptor with bit-7-set ASCII)
Offline transform: clear bit 7 (`b & 0x7f`) turns `Jorge.sde` into printable text, 153 223 lines, e.g.:
```
10,4
LTTSComponentVersion=7.0.0
N=3647,82007
U=# # @ @
L# !'E #-% "
R# #>E "
U=# `a #
L# !*Jz #:< x
R# #T) #G
…
  R3 =t q
  L4 YR q
```
(the fields after `U=`/`L<n>`/`R<n>` are space-separated printable bytes; the numeric encoding of those
fields is still unknown — find it in the reader code.)

### C. Codec 210 (from `decomp_codec210.txt`)
- 7-entry ABI plugin (`LTTS7Codec210.dll` export = single dispatcher at RVA 0x4760).
- `FUN_100010c0(esi, edi)`: `len = *(u16*)(esi+0x474); key = *(u8*)(esi+0x479); for i<len: buf[i] ^= key;`
  then `FUN_10001810(esi,buf,len)`, `FUN_10001720(esi[10], esi, esi[0x475])`.
- 32000 Hz-specific init: `FUN_10001b00(32000)`.

### D. Engine ↔ plugin binding (from `decomp_loqtts.txt`)
- `FUN_10024ff0(voiceDescriptor, session)`: loops i=0..15 over `VocalDBName[i]` / `VocalDBPath[i]`;
  tag `LinkedSde[ALL]`/`LinkedSde[i]` = 'y' selects the **linked SDE plugin** path → `FUN_10024ba0`,
  which does `ELQPluginIni(slot, engine, desc, *piVar3+0x400, "SdeDllMain", 0)` then looks up
  `GetVersion`, `CatVoiceVersion`, `CatSdeData`, `GetSdeData` (log: `"Error loading dbunita from %s"`).
  No shipped module exports `SdeDllMain`; the Jorge descriptors have **no** `LinkedSde` tag → Jorge uses
  the fallback path.
- Fallback path: builds a path from `VocalDBPath[i]`/`VoicePath` + `DataPath`, appends the suffix built
  from `DAT_1008eec0/1008eec4` (likely `".bin"`), then `FUN_10024ad0(desc)` →
  `ELQDataDescriptorGetAttribute(desc,<tag at DAT_10088a0c>,&name,0)`, `ELQFileFullName`,
  `ELQFileResolveSymbolicName(buf,0x200,full, name,0,0)`, `ELQSharedResourceAdd(engine, &h, path, 0,0,0)`
  → handle stored at `session+0x14+i*4`, `session[i+0x94]=1`.
- `.bin` files are registered as a shared-resource type via pattern `*.bin` in `LTTS7Util.dll`.
- `ELQTagsDescriptor*` (Util) = the tags-descriptor parser; Util also has `ELQDataDescriptor*`,
  `ELQFileSearch*`, `ELQBuffer*`, `ELQMA*`.

### E. Voice module `LTTS7Jorge.dll`
Single PE export (dispatcher, RVA 0x1170). Its internal name table (strings) includes
`GetVersion, ELQGetPhonemes, ELQVoiceChannelOpen/Close, FonVidAllofonoAnalisi, FonVidAllofonoVoce,
FonVidAnalisi2Sintesi, FonVidMetaFonema, ELQLogWrite, ELQmalloc, ELQfree, ELQSharedResourceIni/Delete`.
The engine resolves procedures with `ELQPluginGetProc(handle,"<name>",&ptr)`, which goes through the
dispatcher (name string compared in the DLL).
