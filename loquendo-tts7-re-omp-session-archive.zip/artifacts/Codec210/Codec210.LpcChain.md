{
  "title": "Codec210 (Jorge) LPC/LSF spectral chain — reversed",
  "summary": "The 7 'LPC/LSF' math functions are the *analysis* (LPC->LSF) half of the codec, called only by the two vtable-driven analysis objects FUN_1000cc90 (32k/16k) and FUN_10007be0 (8k). The *decode* path (FUN_1000e170 = mode-table slot +0x28, driven by FUN_1000f640) reconstructs LSF from the bitstream, interpolates per subframe, stabilises, converts LSF->LPC (FUN_10005080) and runs the synthesis filter. LPC order = 8 at 32 kHz. All the 0x10022eXX / 0x10021270 constants are IEEE **doubles** (the float labels in the dump are just overlap artefacts); the 0x10023eXX stabilisation margins are floats.",
  "chain_overview": {
    "decode_entry": "ELQDecode(0x10004530) -> FUN_10004290 (XOR deobfusc + bitreader set) -> FUN_1000f640(decObj, ctx, int16_out, ...) -> (*(decObj[0]))[0x28] == FUN_1000e170 (registered at mode-table 0x10023b2c +0x28).",
    "decoder_object": "FUN_1000db20 (mode-table +0x20), size 0x74 bytes, created by ELQOpenDecoder path FUN_10004230 via thunk FUN_1000f4f0(modeTable).",
    "lsf_dequantiser": "In FUN_1000e170 the decoded quantised LSF is produced by modeDesc[0x14] (= FUN_1000c0d0, band descriptor at 0x10023a70) called as (lsf=decObj+0x4c, order, bitreader, ...).",
    "per_band_frame": "Each FUN_1000e170 call decodes decObj[0xc]=320 samples = decObj[0x14]=4 sub-blocks x decObj[0x10]=80 samples; a 640-sample 32 kHz frame = 2 such calls (sub-band codec). See mode struct 0x10023ca8.",
    "spectral_synthesis": "LSF interp (FUN_10005520) -> stabilise (FUN_10005390) -> LSF->LPC (FUN_10005080) -> bandwidth expansion (FUN_10002cc0) -> ARMA/all-pole filtering (FUN_10002f80 / FUN_100030e0)."
  },
  "answers": {
    "1_lpc_order_32k": "LPC order = **8**. Path: ELQOpenDecoder sets ctx[9]=ctx+0x24 = &modeTable(0x10023b2c); FUN_1000db20 does EDI=*modeTable=structA(0x10023ca8); decObj[0x18]=EDI[3]=0x00000008. Independently verified: every LSF/LPC buffer in the decoder object is alloc'd with that field as count (decObj[0x13..0x16] = alloc(order*4)=32 bytes = 8 floats; decObj[0x17]=order*8 bytes = 2 filter states of 8). The Levinson-Durbin loop bound FUN_100047c0(arg3) is that same order when called from the analysis objects (FUN_1000cc90 uses param_1[7], FUN_10007be0 uses param_1[6]). 16 kHz mode struct 0x10023bf8[3] = 8 as well. NOTE: decObj+0x18 is *not* the file-header 'Rank=10'.",
    "2_lsf2lpc_algorithm": "Standard sum/difference (P/Q) method, but the LSF values are **angular frequencies in radians in (0,pi)** — FUN_10004af0(w) is literally cos(w). FUN_10005080: for k=0..p-1 compute c[k]=FUN_10004af0(lsf[k]); then build the two order-(p/2) products by the rolling recurrence f[k] = f[k-1] - 2*c*f[k-2] + f[k-3] (disasm 0x1000515e..: `fVar1 = (P - c*2*hist0) + hist1`, with the 2.0 at 0x10022e58), one chain over the even-index LSFs, one over the odd-index ones (they carry the (1+z^-1)/(1-z^-1) factors), and finally A(z)=(P(z)+Q(z))/2 (the 0.5 at 0x10021270, combine at 0x1000532e..0x1000534c: `out = 0.5*(P + Q - tail2 + tail1)`). Output = p+1-1 = p coefficients a1..ap written to param_2 (a0=1 implicit; the first output slot is skipped). So: cos(2*pi*f) is NOT used — the LSF array already holds radians.",
    "3_constants": {
      "note": "0x10022eXX and 0x10021270/0x10022c88 are 8-byte IEEE doubles; 0x10023eXX below are 4-byte floats (used by callers).",
      "0x10022e08": "double 0.003  (Levinson-Durbin denominator regulariser: k = -acc / (E + 0.003*r0) — FUN_100047c0)",
      "0x10022e10": "double 10.0   (ac[0] += 10.0 white-noise floor — FUN_10004a00 0x10004ade)",
      "0x10022e18": "double 3.141592653589793 (pi) — cos approx else-branch + LSF clamp",
      "0x10022e20": "double 0.9999933242797852",
      "0x10022e28": "double 0.49991244077682495",
      "0x10022e30": "double 0.04148774594068527",
      "0x10022e38": "double 0.0012712094467133284",
      "0x10022e40": "double 1.5707963268 (pi/2, cos branch threshold)",
      "0x10022e48": "double 0.2   (root-search epsilon, FUN_10004cb0)",
      "0x10022e50": "double 0.9   (root-search step factor, FUN_10004cb0)",
      "0x10022e58": "double 2.0   (factor in LSF->LPC recurrence and in FUN_10005080)",
      "0x10021268": "float -1.0   (root-search guard, FUN_10004cb0)",
      "0x10021270": "double 0.5   (final (P+Q)/2 and the 0.5 in FUN_10005390)",
      "0x10022c88": "double 0.0",
      "0x10023ec0": "float 0.002  (LSF stabilisation margin, analysis path)",
      "0x10023ec4": "float 0.05   (LSF stabilisation margin, decode path)",
      "0x10023ed8": "float 0.7    (default gammas when mode entry is 0)",
      "0x10023648": "float 0.2    (root-search step passed by callers)",
      "0x10021278-like float -1.0/0.5 etc": "see above"
    },
    "4_synthesis_filter_form": "Direct-form (state-in-memory) recursion, 1/A(z) with a[1..p] and a[0]=1 implicit, coefficients interpolated *in the LSF domain* per subframe (not in LPC domain): per subframe i of N: FUN_10005520(prev_lsf, cur_lsf, lsf_i, p, i, N) does lsf_i = cur*t + prev*(1-t), t=(i+1)/N; FUN_10005390(lsf_i, p, 0.05) enforces min spacing 0.05 rad and clamps to [0.05, pi-0.05]; FUN_10005080 converts to a1..ap; FUN_10002cc0(gamma, a, a_gamma, p) does a_gamma[k]=gamma^(k+1)*a[k] (bandwidth expansion, 3 sets from mode descriptor 0x10023a70 +0x30/+0x34/+0x38 = 0.75/0.75/0.0; when the entry is null, 0.7/0.7/0.0). The actual filtering is FUN_100030e0 (pure all-pole 1/A(z), state in decObj+0x5c, p floats) or the pair of FUN_10002f80 calls when decObj+0x24!=0 (general ARMA y=(1+A)/(1+B)x; for the 32k descriptors both gammas are equal so the first stage is identity and it degenerates to 1/A(z)). Filter state decObj+0x5c is 2*p floats (two p-float states used by the two cascaded FUN_10002f80 calls)."
  },
  "functions": [
    {
      "addr": "FUN_100047c0",
      "role": "Levinson-Durbin (LPC from autocorrelation) — analysis side only",
      "signature_fixed": "float __cdecl FUN_100047c0(float *lpc_out /*zeroed*/, float *ac_in /*read*/, int order)",
      "arg_evidence": "0x100047c4 EBP=[ESP+0x1c]=arg2 read as *param_2 (initial float compared to 0); 0x100047dc ECX=[ESP+0x24]=arg3 = count; 0x100047e8 EDI=[ESP+0x1c]=arg1 = STOSD destination. Caller FUN_1000cc90 passes (param_1[0x20] out, param_1[0x1f] ac, order).",
      "pseudocode": "if (*ac == 0) { zero lpc[0..order-1]; return 0; }\nE = ac[0]\nfor (i=0; i<order; i++) {\n  acc = -ac[i+1] - sum_{j=0..i-1} lpc[j]*ac[i-j]   // ref: local_10 = -pfVar4[3] ... minus fused MAC chain\n  k = acc / (E + ac[0]*0.003)\n  lpc[i] = k\n  for (j=0;j<i/2;j++) { tmp=lpc[j]; lpc[j]+=k*lpc[i-1-j]; lpc[i-1-j]+=k*tmp; }\n  if (i odd) lpc[i/2] += k*lpc[i/2]\n  E = E - k*E*k\n}\nreturn E",
      "meaning": "Classic Levinson-Durbin producing a[0..order-1]; loop bound = arg3 = order. The 0.003 (0x10022e08, double) is added to the denominator (E + 0.003*r0). Not used in decode.",
      "callers": [
        "FUN_1000cc90 @0x1000cc90 (32k/16k analysis object, order=param_1[7])",
        "FUN_10007be0 @0x10007be0 (8k analysis object, order=param_1[6])"
      ]
    },
    {
      "addr": "FUN_10004a00",
      "role": "Autocorrelation (analysis side)",
      "signature_fixed": "void __cdecl FUN_10004a00(float *sig, float *ac_out, float n_lags, int frame_len)",
      "arg_evidence": "0x10004a04 EDI=[ESP+0x18]=arg3 (used as integer count in the lag loop / (int)param_3); 0x10004a13 EBX=[ESP+0x14]=arg1 (signal base); 0x10004a18 EBP=[ESP+0x24]=arg4 (length). Caller: FUN_10004a00(windowed, param_1[0x1b], order+1, param_1[5]).",
      "pseudocode": "if (n_lags != 0) {\n  for (lag = n_lags; lag >= 1; lag--)\n    ac[lag-1] = sum_{n=lag..frame_len-1} sig[n]*sig[n-lag]\n}\nac[0] += 10.0      // 0x10022e10 (double)",
      "meaning": "Raw autocorrelation of the (lag-windowed) frame, lags 0..n_lags-1 = order+1 values; ac[0] gets a fixed +10.0 floor. Analysis side only."
    },
    {
      "addr": "FUN_10004af0",
      "role": "cos() approximation (double precision)",
      "signature_fixed": "double FUN_10004af0(double x)  /* x in [0,pi] */",
      "pseudocode": "if (x < pi/2)  x2=x*x; return (((0.04148774594068527 - 0.0012712094467133284*x2)*x2 - 0.49991244077682495)*x2 + 0.9999933242797852);\nelse { t = pi - x; t2=t*t; return -(((0.04148774594068527 - 0.0012712094467133284*t2)*t2 - 0.49991244077682495)*t2 + 0.9999933242797852); }",
      "meaning": "Maclaurin polynomial for cos (1 - x^2/2 + x^4/24 - x^6/720, slightly tweaked coefficients), pi/2 symmetry for the upper half. **Input is an angle in radians**, which proves the LSF array holds radian angular frequencies. Constants all double: 0x10022e40(pi/2), 0x10022e18(pi), 0x10022e20/e28/e30/e38."
    },
    {
      "addr": "FUN_10004b80",
      "role": "Chebyshev/Goertzel polynomial evaluation used as LSF root-detection function",
      "signature_fixed": "float __usercall FUN_10004b80(int order /*ECX*/, float *coef /*stack arg1/EBP*/, float c /*stack arg2*/, float *work /*EAX*/)",
      "arg_evidence": "0x10004b84 EBP=[ESP+0xc]=arg1 (coef array), 0x10004b97 FLD [ESP+0x14]=arg2 (float c), ECX=order (>>1), EAX=work (set to 1.0 at align4(EAX)).",
      "pseudocode": "w = align4(work); w[0]=1.0; w[1]=c; g = 2*c;\nfor (k=2; k<=order; k++) { w[k] = g*w[k-1] - w[k-2]; }\nreturn sum_{k=0..order} coef[k]*w[k];",
      "meaning": "Evaluates the LSF frequency polynomial as sum_k coef[k]*U_k(cos w) using the U-recurrence (w[k]=2cos*w[k-1]-w[k-2]); called by FUN_10004cb0 to evaluate the P/Q polynomial at trial frequencies. Return value sign/zero indicates a root."
    },
    {
      "addr": "FUN_10004cb0",
      "role": "LPC -> LSF root search (analysis side)",
      "signature_fixed": "int __cdecl FUN_10004cb0(float *lpc, float order /*as float*/, float *lsf_out, int max_refine, float step, float *work)",
      "arg_evidence": "0x10004cb7 EAX=[ESP+0x38]=arg2 (order, used via /2); 0x10004cc6 EDX=[ESP+0x48]=arg6 (work ptr). Callers pass (lpc, order, lsf_out, 0xf|0xb, _DAT_10023648=0.2|_DAT_10023ec4, scratch).",
      "pseudocode": "half=order/2\n// build sum & difference polynomials (standard LPC->LSF)\nP[0]=Q[0]=1\nfor i<half: P[i+1]=(lpc[i]+lpc[order-1-i]) - P[i];  Q[i+1]=(lpc[i]-lpc[order-1-i]) + Q[i]   // disasm 0x10004dxx: (pfVar9[1]+pfVar5[-2])-local_20 ...\nscale P,Q by 2.0 (0x10022e58)\nfounds=0\nfor k in 0..order-1:\n   pol = (k odd) ? Q : P ; c = 1.0           // first estimate: cos=1 (w=0)\n   loop:  v = FUN_10004b80(order, pol, c)\n          step_i = (1 - 0.9*c*c) * step        // 0x10022e50=0.9\n          if (|v| < 0.2) step_i *= 0.5         // 0x10022e48=0.2, 0x10021270=0.5\n          c_new = c - step_i\n          if (v_new * v <= 0.0 && c_new >= -1.0) continue  // converged sign change\n          c = c_new; v = v_new\n   refine with max_refine bisection-like steps using (c+c_new)*0.5\n   lsf_out[k] = acos(c)      // FUN_10010e10 = acos\n   found++\nreturn found",
      "meaning": "Converts LPC (order coefficients) to order LSFs in radians by locating the roots of P/Q with Newton/secant + bisection. Uses FUN_10004b80 as the evaluation. Analysis side only (not in the 32k decode path)."
    },
    {
      "addr": "FUN_10005080",
      "role": "LSF -> LPC (the core decoder transform)",
      "signature_fixed": "void __cdecl FUN_10005080(float *lsf_in, float *lpc_out, int order, float *work)",
      "arg_evidence": "0x10005085 EBP=[ESP+0x30]=arg3=order; 0x1000508a ESI=[ESP+0x38]=arg4=workspace; 0x100050df ESI=[ESP+0x30]... reads arg1 = LSF array. Caller FUN_1000e170: FUN_10005080(decObj+0x54 /*lsf*/, decObj+0x58 /*lpc*/, order, scratch).",
      "pseudocode": "half = order>>1\nwork = align4(scratch); zero work[0 .. 2*half+1]\ncos_arr = work + half*4 + 2 (aligned)     // p floats\nfor k in 0..order-1: cos_arr[k] = FUN_10004af0(lsf_in[k])   // c[k] = cos(w_k)\nFp = 1.0; Fq = 1.0                          // running P, Q numerators\ndo {\n   for i in 0..half-1:                      // rolling product by (1-2c z^-1+z^-2)\n       Fp = (Fp - 2*c[2i]  *histp0) + histp1\n       Fq = (Fq - 2*c[2i+1]*histq0) + histq1\n       shift hist\n   if (n > 0)   // n = outer counter, first slot skipped (a0 implicit = 1)\n       out[n-1] = 0.5*(Fp + Fq - tail2 + tail1)   // 0x10021270=0.5\n   store Fp,Fq into tails; Fp = Fq = 0.0\n   n++\n} while (n <= order)",
      "meaning": "Produces a1..ap (a0=1 implicit) for A(z)=1+sum a_k z^-k from radian LSFs, via the standard P/Q symmetric/antisymmetric products combined with (P+Q)/2. Exact roll of the P/Q tail combination is INFERRED from 0x1000532e..0x1000534c (the disasm shows `FLD Q; FSUB [EDX+8]; ... FADD ST3(P); FADD [esp+0x3c]; FMUL ST4(0.5); FSTP [ECX]`). The recurrence `new = acc - c*2*hist0 + hist1` is literal from 0x1000515e-0x100051c6 and the constant 0x10022e58 (double 2.0)."
    },
    {
      "addr": "FUN_10005390",
      "role": "LSF stabilisation / minimum spacing (used by both analysis and decode)",
      "signature_fixed": "void __cdecl FUN_10005390(float *lsf, int order, float margin)",
      "pseudocode": "lsf[0] = max(lsf[0], margin)\nlsf[order-1] = min(lsf[order-1], pi - margin)          // 0x10022e18(double)=pi\nfor i in 1..order-2:\n   if (lsf[i]   < lsf[i-1] + margin)           lsf[i] = lsf[i-1] + margin\n   if (lsf[i+1] - margin < lsf[i])             lsf[i] = ((lsf[i] + lsf[i+1]) - margin) * 0.5   // 0x10021270(double)=0.5",
      "meaning": "Forces ascending LSFs with minimum separation `margin` inside (0,pi). Decode path passes margin = 0.05 (float 0x10023ec4); analysis path passes 0.002 (float 0x10023ec0)."
    },
    {
      "addr": "FUN_10005520",
      "role": "Per-subframe LSF interpolation (linear)",
      "signature_fixed": "void __cdecl FUN_10005520(float *lsf_new, float *lsf_prev, float *lsf_out, int order, int subframe_idx, int n_subframes)",
      "arg_evidence": "disasm 0x1000554x..: t = ((float)arg5 + 1.0)/(float)arg6; out[i] = arg2[i]*t + arg1[i]*(1-t). Caller FUN_1000e170: FUN_10005520(decObj+0x50(prev), decObj+0x4c(cur), decObj+0x54(out), order, sub, nsub).",
      "pseudocode": "t = (subframe_idx + 1.0) / n_subframes;\nfor i in 0..order-1: out[i] = lsf_cur[i]*t + lsf_prev[i]*(1.0 - t);",
      "meaning": "Linear interpolation between the previous frame's LSF (weight 1-t) and the current frame's decoded LSF (weight t), t ramping 1/N..1 over the N sub-blocks of the band. This is the only 'interpolation' in the decode spectral path."
    },
    {
      "addr": "FUN_10002cc0",
      "role": "Bandwidth expansion of LPC coefficients (a[k] <- gamma^(k+1) * a[k])",
      "signature_fixed": "void __cdecl FUN_10002cc0(float gamma, float *in, float *out, int n)",
      "pseudocode": "p = gamma; for k in 0..n-1: out[k] = p*in[k]; p *= gamma;",
      "meaning": "out[k]=gamma^(k+1)*in[k]. Called 3x per subframe with gamma = band-descriptor +0x30/+0x34/+0x38 (0.75/0.75/0.0 for 0x10023a70; else 0.7/0.7/0.0)."
    },
    {
      "addr": "FUN_10002da0 / FUN_10002e30",
      "role": "plain scale / divide in place",
      "signature_fixed": "void FUN_10002da0(float *in,float *out,float g,int n)  -> out[k]=in[k]*g;   void FUN_10002e30(float *in,float *out,float g,int n) -> out[k]=in[k]/g"
    },
    {
      "addr": "FUN_10002ec0",
      "role": "vector norm / energy helper (SIMD inner loop in FUN_100105c0)",
      "signature_fixed": "float FUN_10002ec0(float *buf, int n)",
      "meaning": "Loops with empty bodies (Ghidra lost the SIMD op) and calls FUN_100105c0; returns a scalar magnitude/energy of buf[0..n-1]. Used for sub-band gains. INFERENCE: exact reduction (sum of squares vs sum of |x|) not recovered here — FUN_100105c0 is the SSE helper."
    },
    {
      "addr": "FUN_10002f80",
      "role": "General ARMA (pole-zero) filter, direct-form state recursion",
      "signature_fixed": "void __cdecl FUN_10002f80(float *in, float *num, float *den, float *out, int N, int order, float *mem)",
      "pseudocode": "for n in 0..N-1:\n  x = in[n]; y = x + mem[0];\n  for k in 0..order-2: mem[k] = num[k]*x + den[k]*(-y) + mem[k+1];\n  mem[order-1] = num[order-1]*x - den[order-1]*y;\n  out[n] = y;\n// => y = (1 + N(z))/(1 + D(z)) * x",
      "meaning": "Verified symbolically for order 2: y[n] = x[n] + num0 x[n-1] + num1 x[n-2] - den0 y[n-1] - den1 y[n-2]. num=param_2, den=param_3, state mem[0..order-1] carried across N samples (and across subframes if the same state buffer is used). In the decoder it is called (num=A(z/gamma2), den=A(z/gamma1)) then (num=0, den=A(z)) — i.e. the classic CELP weighting-then-synthesis cascade, which degenerates to plain 1/A(z) when gamma1==gamma2."
    },
    {
      "addr": "FUN_100030e0",
      "role": "All-pole (1/A(z)) synthesis filter, direct-form state recursion",
      "signature_fixed": "void __cdecl FUN_100030e0(float *in, float *a, float *out, int N, int order, float *mem)",
      "pseudocode": "for n: x=in[n]; y=x+mem[0]; for k<order-1: mem[k]=a[k]*(-y)+mem[k+1]; mem[order-1]=-a[order-1]*y; out[n]=y;\n// => y = x / A(z),  A(z)=1+a0 z^-1+...+a_{p-1} z^-p",
      "meaning": "The LPC synthesis filter (all-pole). Verified for order 2: y[n]=x[n]-a0 y[n-1]-a1 y[n-2]. a[] = coefficients a1..ap (a0=1 implicit), mem = p-float state. Used when decObj+0x24==0 (no weighting filter) and in analysis."
    },
    {
      "addr": "FUN_100031f0",
      "role": "All-zero / FIR A(z) analysis filter (residual)",
      "signature_fixed": "void __cdecl FUN_100031f0(float *in, float *a, float *out, int N, int order, float *mem)",
      "pseudocode": "for n: x=in[n]; r=mem[0]; for k<order-1: mem[k]=a[k]*x+mem[k+1]; mem[order-1]=a[order-1]*x; out[n]=x+r;\n// => r = A(z) x",
      "meaning": "Image of FUN_100030e0 with the sign flipped: computes the LPC residual (inverse/analysis filter)."
    },
    {
      "addr": "FUN_10003300",
      "role": "cascade FIR-then-IIR (analysis + synthesis)",
      "signature_fixed": "void __cdecl FUN_10003300(float *in, float *a, float *b, int N, float *coefA, float *coefB, int order, int scratch)",
      "pseudocode": "zero state; FUN_100030e0(...); zero state; FUN_10002f80(...);",
      "meaning": "two-stage filter with fresh (zeroed) states."
    },
    {
      "addr": "FUN_100033e0",
      "role": "combine three coefficient sets into a single filter (weighting filter / impulse response build)",
      "signature_fixed": "void __cdecl FUN_100033e0(int a1, int a2, int a3, undefined4 *out, int N, int order, undefined4 *mem)",
      "meaning": "Initialises out[0]=1.0, copies a2[1..order-1] into out, zero-fills the rest with 0x26901d7d (a denormal/epsilon), then runs a two-accumulator recursion using a1 and a3 coefficient arrays. This is the 'build the target/weighted filter from the three gamma-expanded LPC sets' step of the analysis-by-synthesis encoder. Not on the decode path."
    },
    {
      "addr": "FUN_100036b0 / FUN_10003960",
      "role": "symmetric LPC spectral shaping / windowed polyphase filtering helpers",
      "signature_fixed": "void __cdecl FUN_100036b0(int in,int coef,int out,float *x,int N,int order,int y,int scratch); void __cdecl FUN_10003960(int in,int coefTab,int out,float frameLen,int winLen,int state,undefined4 *scratch)",
      "meaning": "Both build a mirrored coefficient array (reverse copy of the coefficients), then convolve with the input. FUN_10003960 is the 64-tap (param_5=0x40) polyphase step invoked in FUN_1000e170 as FUN_10003960(decObj+0x2c, 0x100240a8, decObj+0x38, decObj[2](=640.0), 0x40, decObj+0x40, scratch) and again with 0x100241a8 (+0x100) — two 64-tap kernels, producing frameLen/2 = 320 outputs. INFERENCE: this is the sub-band synthesis/windowing (overlap-add) stage that recombines the 2 half-band signals into the 320-sample band output; the exact kernel tables 0x100240a8/0x100241a8 were not byte-decoded here."
    }
  ],
  "mode_struct_32k": {
    "mode_table": "0x10023b2c (pointed to by ctx+0x24): +00=0x10023ca8 params, +04=0x1000f5d0, +08=0x10023d54 desc strings, +0c=2, +10=4, +14=FUN_1000c310, +18=FUN_1000cb20, +1c=FUN_1000cc90, +20=FUN_1000db20(create decobj), +24=FUN_1000de40(destroy), +28=FUN_1000e170(decode frame), +2c=FUN_1000e8f0(param get/set), +2c=..., +30=FUN_1000f0e0, +44=FUN_1000bdd0, +48=FUN_1000c0d0",
    "params_0x10023ca8": "+00=0x10023ab4 (16k sub-table ptr), +04=0x140 (320 = samples per band-frame), +08=0x50 (80 = sub-block length), +0c=0x8 (LPC ORDER = 8), +10=0x500, +14=0.9, +18=0.6, +1c=0.002, +20=0.0001, +24=0.7",
    "band_descriptor_0x10023a70": "+08=1, +10=FUN_1000bdd0 (excitation decoder), +14=FUN_1000c0d0 (LSF dequantiser), +30=0.75 (gamma1), +34=0.75 (gamma2), +38=0.0 (gamma3), +3c=-1.0, +40=0x24, +44=0x10023bf8, +48=0x1000f5d0",
    "note": "16 kHz params 0x10023bf8: samples/band-frame=0xa0=160, sub-block=0x28=40, nblk=4, order=8."
  },
  "verification_notes": [
    "Signatures fixed against the Jorge disassembly in /tmp/c210/lpc_dis.txt (per-instruction arg reads at function prologues).",
    "Every claim of the form 'x = ...(addr)' is from the decomp dump /tmp/c210/decomp_codec210_jorge.txt at the cited address or from the pefile dump of .rdata.",
    "The exact roll of FUN_10005080's P/Q tail combination and of FUN_10002ec0's reduction are flagged as inference; everything else is literal.",
    "No builds/tests/linters run."
  ]
}