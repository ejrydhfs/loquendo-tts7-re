{
  "title": "Codec210 Jorge: frame parameter unpacking (bitstream -> codec params)",
  "full_report": "/tmp/c210/REPORT_streamparams.md",
  "arch": "Layered sub-band CELP. FUN_1000f640(decObj,ctx,out) -> decObj->vtable[0x28] = FUN_1000e170 (32k obj, built by FUN_1000db20 from descriptor 0x10023b2c). FUN_1000e170 first calls obj[4]->vtable[0x28] = FUN_1000e170(16k obj) which first calls FUN_10009520 (8k core). Bit-consumption order = 8k core, 16k band, 32k band.",
  "modesel_8k": "FUN_10009520: read 1 bit wideband flag (bit7); then read 4 bits MODE (0..8 ok, 0xF=flush, 0xE=aux FUN_1000f6f0(br,obj+0x8c,obj), 0xD=obj[0x1d0]=FUN_1000f7b0). obj[0x80]=mode.",
  "modesel_16k32k": "FUN_1000e170: read 1 flag bit; if 1: skip 1 bit then read 3 bits MODE (mode 0 = concealment, else table[mode]). 16k table 0x10023c20 (idx1..4 valid), 32k table 0x10023cd0 (only idx1). 8k table 0x100239ec (idx1..8).",
  "frame_8k_core": "reads: LSF 6+6+6 bits (modobj[0x14]=FUN_1000bb80), 7 bits if modobj[0]!=-1, 4 bits if modobj[4]!=0, 5 bits, (mode==1: 4 bits); then per subframe x4: pitch codebook (modobj[0x1c]) reads param[2]+param[1] bits, 3 or 1 bits, fixed CB (modobj[0x28]=FUN_100029c0) nVec*(flag?1+bits), second stage if modobj[0xc]!=0.",
  "frame_16k32k": "reads: LSF modobj[0x14]=FUN_1000c0d0 = 6+6 bits; per subframe x4: 5-bit gain if modobj[0x28]==0 else 4-bit gain + fixed CB via FUN_100029c0, plus 2nd stage if modobj[0xc]!=0. No pitch-lag read (band replication via FUN_10002cc0 and modobj[0x30/0x34/0x38]).",
  "empirical": "XOR key 0x6D. Raw byte0 in 0x50..0x57 -> post-XOR 0x38..0x3F = 0b0111_0xxx => wideband flag=0, 8k MODE=7, low 3 bits payload. Mode7 -> 0x100238f8 (LSF 0x1000b510, pitch 0x10006bb0 struct 0x100237e4, fixedCB 0x100029c0 struct 0x10023834 {5,8,0x10021bd8,6,0}, 2nd stage flag=1).",
  "bit_prims": "0x100011d0(br,n) MSB-first read n bits; 0x10001240 1 bit; 0x10001280 skip; 0x100012c0 bits left; 0x100010e0 is the WRITER (encode side).",
  "tables": {
    "descriptors": "0x1002393c 8k, 0x10023ab4 16k, 0x10023b2c 32k; slots +0x20 ctor, +0x28 decode(FUN_1000e170 / FUN_10009520 for 8k)",
    "quant_struct": "+0x00 dim, +0x04 nVec, +0x08 int8* cb, +0x0C bits/index, +0x10 sign-flag",
    "codebooks": [
      "0x10022870 64x8 LSF1(16/32k)",
      "0x10022a70 64x8 LSF2",
      "0x10022e60 64x10 LSF1(8k)",
      "0x100230e0 64x5 LSF2(8k)",
      "0x10023360 64x5 LSF3(8k)",
      "0x100222d0 32x10 pitch",
      "0x10022330 32x10 fixed",
      "0x10021278 16x10 fixed",
      "0x10021458 32x20 fixed",
      "0x10021bd8 64x5 fixed",
      "0x100216d8 256x5 fixed",
      "0x10021d18 ~128x8 fixed",
      "0x10022470 16k-mode fixed(bits7)"
    ],
    "consts": "0x10024088=1/512, 0x10024090=1/256, 0x10024098=.75, 0x100240a0=.3125, 0x10021260=2^-15, 0x10021268=-1.0"
  },
  "speculative": [
    "16k/32k band MODE values not yet determined (need simulation)",
    "obj[8]=2*cfg[1] likely band output sample count (640 for 32k) - INFERENCE"
  ]
}