{
  "deliverable": "specs/DriftFrames.md (new) - root cause, evidence tables, exact rule, minimal patch, validation, closed/unclosed statement. UpperBands.md unchanged (still CLOSED).",
  "root_cause": "The 8 kHz LTP tap window is a CYCLIC read of the `lag` samples ending just before the current sub-block - the DLL never reads the current (cleared) sub-block. RING[k]=buf[w0+k] if k<=lag else buf[w0+1+((k-1)%lag)], w0=p-(lag+1); out[i]=g2*RING[i]+g1*RING[i+1]+g0*RING[i+2]. For lag>=41 the ring does not wrap within the 42 taps used, hence identical to the current 3-tap form - which is exactly why only lag<=40 sub-frames drifted.",
  "evidence": {
    "provenance": "DLL's own 120-float LTP tap scratch at 0x3000e0a4 (arg10 of the FUN_10006bb0 call at 0x10009c0d), read at the call return; window 0 == port buffer b[w0+k] for k<=lag and == b[w0+1+((k-1)%lag)] for k>lag (frame 118 sf1 lag=20: k=21 -> 173.39688 == b[w0+1] while the port has -272.98111).",
    "fir_verification": "port ring-LTP vs DLL LTP rebuilt from its own scratch window, all 40 samples: max abs diff 0.014 (1e-4 relative, float32 order).",
    "stage_table": "lsf/lpc/tilt = corr 1.000000 on EVERY frame (incl. 118-130, 170-179); excitation, then LPC state, then sig8 diverge (118: exc 0.9744 state 0.9686 sig8 0.9589). CB1/CB2 exact in every sub-frame (rms identical); only the LTP wrong.",
    "per_subframe": "lag 144/60/109/43/108 -> port 1.000000; lag 20 -> port 0.705 vs ring 0.991; lag 32 -> 0.924 vs 1.000; lag 21 (f119 sf1) 0.692 vs 1.000; lag 39 -> 0.996 vs 1.000; lag 21 (f121 sf0) 0.561 vs 1.000.",
    "ruled_out": "lsf_interp weights, stabiliser margin, VQ ramp re-seeding, LSF history reset, LPC state init/layout, band-expansion path (all exact); pre-clear/stale taps, live in-place taps, tap-base offsets +-160 (all worse: 0.02-0.85, scan peaks at offset 0)."
  },
  "patch": "specs/DriftFrames.md section 4: replace Codec210.ltp (same signature) with the lag-periodic ring version.",
  "end_to_end": {
    "before": "0..299 corr 0.997496, ratio 0.9910",
    "after": "0..299 corr 0.999648, ratio 1.0010",
    "windows": "all non-silent 10-frame windows >=0.999 except 120-129 = 0.9958 (and 160-169 = 0.9996); 170-179 now exactly 1.000000; frames 37..299: only 14 frames <0.999, min 0.9924 (94-97/123-129/68)",
    "closed": "root cause CLOSED; the 120-129 window (0.9958) residual is float32 ordering in the near-cancelling 3-term sum plus possible exact wrap-boundary (k>lag vs k>=lag+1) - remaining, everything else in that window traces to state accrued before the fix."
  },
  "checks_for_main": "apply specs/DriftFrames.md section 4 to tools/codec210.py and re-run tools/verify_codec.py over frames 0..299 (expect ~0.9996, ratio ~1.001)."
}