{
  "deliverable": "specs/GainLaw.md (409 lines) — exact 8 kHz innovation gain law, measured tables, and a verbatim patch for tools/codec210.py",
  "result_summary": "The fitted law is replaced by the exact one: gain_CB1 = float32(q[b3] * float32(exp(g8/3.5))), gain_CB2 = float32(gain * 0.45454545454545453). Measured on 284 sub-frames (frames 0..70, incl. the requested 30..70) against the real DLL under Unicorn.",
  "exact_law": {
    "C(g8)": "float32(exp(g8/3.5)); divisor 3.5 is the double at VA 0x10023e70 (bytes 0000000000000c40); the exp is the CRT intrinsic reached via the dispatcher VA 0x10011aec and is rounded to float32 at VA 0x100099b1",
    "q_table": "the 8 float32 at VA 0x10023db8 (bytes 73637a3d 9a78273e 74ee9e3e a73fdb3e 9c4e0e3f fd13383f 404e703f 02d7a93f) = 0.06112999841570854, 0.16354599595069885, 0.3104130029678345, 0.4282200038433075, 0.55588698387146, 0.7190549969673157, 0.9386940002441406, 1.326874017715454",
    "index": "b3 = the port's parse_frame[sub8][sf][2] (3-bit) == the decoder's read(3) at VA 0x10009d13; verified equal on 284/284 sub-frames",
    "g8": "the port's parse_frame[energy8] (5-bit) == the decoder's read(5) at VA 0x10009993; constant across the 4 sub-frames of every frame (71/71)",
    "CB2": "gain * double 0x10023ee8 = 0.45454545454545453 (=5/11), applied at VA 0x10009fba then rounded to float32",
    "no_other_factor": "no LPC-tilt/gden term exists on the coded innovation; the 8 kHz mode index is 7 so the mode==1 noise-mix branch in FUN_10009520 is dead",
    "C(g8)_table_0_31": [
      1,
      1.3307121992111206,
      1.7707949876785278,
      2.3564183712005615,
      3.1357147693634033,
      4.172733783721924,
      5.552707672119141,
      7.389056205749512,
      9.832707405090332,
      13.084503173828125,
      17.41170883178711,
      23.169971466064453,
      30.832565307617188,
      41.02927017211914,
      54.598148345947266,
      72.65442657470703,
      96.68212890625,
      128.6560821533203,
      171.2042236328125,
      227.82354736328125,
      303.1675720214844,
      403.4288024902344,
      536.8475952148438,
      714.3896484375,
      950.6470336914062,
      1265.03759765625,
      1683.4010009765625,
      2240.122314453125,
      2980.9580078125,
      3966.797119140625,
      5278.66552734375,
      7024.38427734375
    ]
  },
  "method_notes": [
    "Increments captured with a global UC_HOOK_CODE last-address tracker + UC_HOOK_MEM_WRITE on EXC=0x30012364..+160; the Unicorn write hook fires BEFORE the store, so the value must come from the hook's `val`, not mem_read (this bug silently shifted every captured stage by one write).",
    "LTP output stores are the four unrolled FIR `fstp DWORD` at 0x10006f94/0x10006fb2/0x10006fd4/0x10006ff7 inside FUN_10006bb0 (plus 0x10009c0d depending on the Unicorn TB cache) - whitelisting only 0x10009c0d silently loses the LTP stage and corrupts inc1.",
    "Write sequence per sub-frame: clear(0x10009b6f) -> LTP -> CB1 scale(0x10009d9f)+accumulate(0x10009f3e) -> CB2 scale(0x10009fd5)+accumulate(0x10009ff1); the accumulate sites store dst[i]+=scratch[i] so increments are exact."
  ],
  "acceptance": {
    "worst |model - gain_measured|/gain_measured (CB1, >=0.001 required)": "9.82e-08 (frame 55 sf2, g8=24 b3=6)",
    "worst |model - gain(real stack argument)|/gain": "0.000e+00 (bit-identical float32, all 284)",
    "worst |model*5/11 - gain_measured(CB2)|/gain": "8.0e-08",
    "worst codebook projection residual inc1 / inc2": "1.15e-07 / 2.87e-07"
  },
  "answers_to_task_questions": {
    "g8==0 gated?": "No. X=1.0 and gain=q[b3]>0; frame 0 sf0 (zero LTP history) yields inc1 = 0.310413 * codebook with residual 4.9e-14.",
    "fitted 0.430*1.3305^g8 within 0.1%?": "No, table required. Base exp(1/3.5)=1.3307121992111206 vs 1.3305 => -0.016%/step (fit shape error >0.1% from g8=7, +0.496% at g8=31), and the constant 0.430 is off by 2.3256x (it had absorbed q_true[3]=0.428220).",
    "16k/32k 4-bit fields": "Different machinery, checked once: gain = exp(i4*0.27027027027027023 - 0.15556) * (E_adapt+1.0) / E_codebook (block len 80 branch multiplies the dequantised energy by the double 1.4142 at 0x100242a8), verified <=5e-8 on frame 38 sf0..3; the 4 measured 4-bit values equal the port's sub16[sf][0] for frames 37-40. No 8-entry q table and no g8/3.5, so C(g8)/q must not be reused there. The 32k band's 5-bit ref32 fields belong to its noise branch (ramp double -1.0 at 0x100242f8), not this site."
  },
  "patch_files": [
    "specs/GainLaw.md section 6 contains the verbatim hunk for Codec210.exc_gain (new EXC_Q / CB2_RATIO / _f32 helper) and decode_frame (exact 5/11 CB2 factor, float32 accumulation, delete the dead sump/sumd/gden computation)"
  ],
  "measured_only_constants_for_reference": {
    "0x10023e70": "double 3.5",
    "0x10023ee8": "double 0.45454545454545453",
    "0x10022118": "double 1.0 (eps)",
    "0x100242b0": "double 0.27027027027027023 (16k/32k 4-bit step)",
    "0x100242c0": "double 0.15556",
    "0x100242a8": "double 1.4142 (80-sample block factor)",
    "0x100242f8": "double -1.0",
    "0x10023ddc": "float32 0.7046899795532227, 1.0512700080871582 (read(1) branch, unused)"
  },
  "artifacts": {
    "spec": "specs/GainLaw.md",
    "throwaway_probe": "/tmp/gl_measure.py (usage: /tmp/uv/bin/python /tmp/gl_measure.py 0 70 /tmp/gl_meas.json, ~60s)",
    "raw_records": "/tmp/gl_meas.json (284 records)"
  },
  "verification_for_main": [
    "Apply the section-6 patch, then re-run the port's end-to-end correlation over frames 0..119 and compare with the reference PCM - the 8 kHz excitation should now track the emulator instead of drifting; the remaining gap should be the unported B32/16k branches.",
    "Do not edit tools/codec210.py from this task (not done); the spec is the hand-off."
  ]
}