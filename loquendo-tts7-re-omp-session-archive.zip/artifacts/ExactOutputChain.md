{
  "deliverable": "specs/ExactOutput.md (new file, 333 lines) — final state after incorporating the sibling's LTP counter-example; throwaway harness under /tmp/audit/",
  "acceptance": {
    "actual (my patches + sibling's bit-exact excitation)": "global 0.9999990; 15578/192000 samples differ; 29/30 table rows 1.000000, only frame 10 = 0.999684; max abs 186 localised in frames 294-296 (f295: 627/640)",
    "actual (tools/codec210.py as-is)": "global 0.999648",
    "target": "global 1.000000 + every speech 10-frame row 1.00000",
    "verdict": "NOT met — reported with numbers, no claim made"
  },
  "eighty_bit_emulation": "NONE needed FOR THE THREE OUTPUT-CHAIN STAGES (FUN_100030e0 / FUN_10003960 / FUN_1000c290): plain double and numpy.longdouble both give 0 differing samples. The spec now explicitly scopes this and records that the 8 kHz LTP FUN_10006bb0 DOES need 80-bit (sibling's measurement) so it must not be generalised.",
  "final_patch_set": {
    "3.1": "lpc_synth: t=f32(in+mem[0]) and every state store -> float32",
    "3.2": "band_filter: float32 round after every partial product-sum; s1/s3 accumulate the c1 term before the c3 term",
    "3.3": "combine: out16 clamp lower bound -32768.0 -> -32767.0",
    "4.3": "_cos_apx replaces math.cos in lsf_to_lpc (DLL's own degree-6 cos, bit-exact on 4784 calls)"
  },
  "integration_note_recorded": "apply these on top of the sibling's excitation model (Codec210.ltp + longdouble MAC + EXC_FLOOR + _LD32) and do NOT simplify that model to double; /tmp/audit/mkcombined.py stacks them",
  "open_items": [
    "frame LSF (5-stage VQ output, 0x300128a0) not bit-exact: 198/200 coefficients, max 4.05e-6 (frames 40..60) - now the largest remaining output-side error",
    "FUN_10005080 cascade model: 333/4264 coefficients at exactly 1 float32 ULP (documented, not recommended as a patch)",
    "8 kHz stabilisation margin is 0.002f (0x10023ec0), not 0.05 - latent"
  ],
  "stage_bit_exactness_bit_for_bit": {
    "FUN_100030e0 8k LPC synthesis": "1572 calls / 83840 samples / 0 differ / max 0",
    "FUN_10003960 band_filter": "524 calls / 251520 samples / 0 differ / max 0",
    "FUN_10004af0 cos": "4784 calls / 0 differ",
    "FUN_1000c290 combine": "262 calls / 125760 samples / 0 differ / max 0",
    "8k path with DLL exc8+LPC injected": "sig8 0/20960 differ"
  },
  "untouched": "tools/codec210.py, REPORT.md and all other agents' files were NOT edited."
}