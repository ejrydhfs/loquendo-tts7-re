# Session archive

Generated 2026-10-11T20:03:55.394Z from session `01a12166-5f49-71bc-ae31-5a40789fbbcf`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

64 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (15)

- `APath` — 205 entries, 737014 bytes
- `Codec210` — 1266 entries, 4293677 bytes
- `Codec210/Codec210.LpcChain` — 165 entries, 754612 bytes
- `Codec210/Codec210.MsxCmp` — 161 entries, 973712 bytes
- `Codec210/Codec210.StreamParams` — 215 entries, 927850 bytes
- `Codec210/Codec210.SynthChain` — 191 entries, 1115100 bytes
- `ELQBinContainer` — 407 entries, 1391916 bytes
- `EngineBind` — 396 entries, 1536670 bytes
- `EngineBind/EngineBind.CodecPath` — 273 entries, 750836 bytes
- `EngineBind/EngineBind.VoiceIface` — 153 entries, 1028276 bytes
- `ExactExcitationArith` — 549 entries, 1654313 bytes
- `ExactOutputChain` — 701 entries, 2214876 bytes
- `GainLaw` — 264 entries, 935055 bytes
- `SdeFormat` — 343 entries, 1045746 bytes
- `UpperBands` — 836 entries, 2483014 bytes

## Totals

79 files, 71013685 bytes.
